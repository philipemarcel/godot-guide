# Aula 14 — flash, UV e partículas

Referência: Godot 4.5, Compatibility. Projeto revisado documentalmente, ainda não executado no motor neste ambiente. Importe project.godot e execute oficina.tscn com F6. Os nós e a interface são criados por oficina.gd.

F: flash de 0,4 s; O: alternar amplitude 0/0,05; M: compartilhar/separar material de A e B; P: repetir rajada; R: restaurar shaders e recriar emissor. Os mesmos comandos têm botões. Não exige ações de InputMap. A está em (140,170), B em (330,170), emissor em (520,250).

onda_flash.gdshader é o shader combinado. flash.gdshader é um estudo isolado; não cole GDScript nele. placa.svg tem 160×160 com margem de 32 px e círculo parcialmente transparente; vapor.svg é a textura do emissor.

Emissor: N=24, T=1,5 s, one_shot=true e explosiveness=1. O controlador preserva o nó e usa restart(true); repetir antes do fim limpa as partículas anteriores. finished é contado em one_shot. Para a variação contínua, em uma cópia de emissor.gd, use one_shot=false, explosiveness=0 e emitting=true ao final de _ready; 24/1,5 dá taxa nominal de 16/s. Desligue Emitting no Remote Inspector e observe a vida residual.

O relógio tempo é enviado pelo script; não é o TIME nativo. O modelo de navegador não executa este projeto, não simula GPU nem comprova cores/renderização pixel a pixel. Não há medição de FPS ou promessa de desempenho. Confira APIs e renderizador na aula, valide o projeto no motor e depois no hardware-alvo.
