extends GPUParticles2D

func _ready() -> void:
    emitting = false
    amount = 24
    lifetime = 1.5
    one_shot = true
    explosiveness = 1.0
    randomness = 0.0
    local_coords = true
    fixed_fps = 60
    use_fixed_seed = true
    seed = 14
    texture = preload("res://vapor.svg")
    visibility_rect = Rect2(-150, -220, 300, 260)

    var motion := ParticleProcessMaterial.new()
    motion.particle_flag_disable_z = true
    motion.direction = Vector3(0, -1, 0)
    motion.spread = 20.0
    motion.initial_velocity_min = 50.0
    motion.initial_velocity_max = 80.0
    motion.gravity = Vector3(0, -20, 0)
    motion.scale_min = 2.0
    motion.scale_max = 4.0
    motion.color = Color(0.75, 0.9, 0.95, 0.8)
    var fade := Curve.new()
    fade.add_point(Vector2(0, 1))
    fade.add_point(Vector2(1, 0))
    var fade_texture := CurveTexture.new()
    fade_texture.curve = fade
    motion.alpha_curve = fade_texture
    process_material = motion

