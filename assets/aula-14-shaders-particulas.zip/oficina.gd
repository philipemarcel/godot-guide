extends Node2D

const EFFECT = preload("res://onda_flash.gdshader")
const EMITTER = preload("res://emissor.gd")
var sprite_a: Sprite2D
var sprite_b: Sprite2D
var mat_a: ShaderMaterial
var mat_b: ShaderMaterial
var emitter: GPUParticles2D
var readout: Label
var clock: float = 0.0
var flash_age: float = 0.4
var wave_on: bool = false
var shared: bool = false
var finishes: int = 0

func _draw() -> void:
    draw_rect(Rect2(502, 250, 36, 20), Color("a66b3f"))
    draw_rect(Rect2(502, 250, 36, 20), Color("edc781"), false, 2.0)

func _ready() -> void:
    mat_a = ShaderMaterial.new()
    mat_a.shader = EFFECT
    mat_b = ShaderMaterial.new()
    mat_b.shader = EFFECT
    sprite_a = criar_sprite(Vector2(140, 170), mat_a)
    sprite_b = criar_sprite(Vector2(330, 170), mat_b)
    criar_emissor()
    var layer := CanvasLayer.new()
    add_child(layer)
    var box := VBoxContainer.new()
    box.position = Vector2(16, 310)
    box.custom_minimum_size.x = 608
    layer.add_child(box)
    for spec in [["F · Disparar flash", disparar_flash], ["O · Alternar onda", alternar_onda],
        ["M · Compartilhar / separar materiais", alternar_material],
        ["P · Disparar / repetir rajada", disparar_rajada], ["R · Restaurar oficina", restaurar]]:
        var button := Button.new()
        button.text = spec[0]
        button.pressed.connect(spec[1])
        box.add_child(button)
    readout = Label.new()
    readout.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
    box.add_child(readout)

func criar_sprite(at: Vector2, material_instance: ShaderMaterial) -> Sprite2D:
    var sprite := Sprite2D.new()
    sprite.texture = preload("res://placa.svg")
    sprite.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
    sprite.material = material_instance
    sprite.position = at
    add_child(sprite)
    return sprite

func criar_emissor() -> void:
    emitter = EMITTER.new()
    emitter.position = Vector2(520, 250)
    emitter.finished.connect(func(): finishes += 1)
    add_child(emitter)

func _process(delta: float) -> void:
    clock += delta
    flash_age = minf(0.4, flash_age + delta)
    mat_a.set_shader_parameter("tempo", clock)
    mat_a.set_shader_parameter("intensidade", maxf(0.0, 1.0 - flash_age / 0.4))
    mat_a.set_shader_parameter("amplitude", 0.05 if wave_on else 0.0)
    readout.text = "A à esquerda; B ao centro; vapor à direita.\nMaterial: %s | onda: %s | rajadas concluídas: %d" % [
        "compartilhado" if shared else "independente", str(wave_on), finishes]

func disparar_flash() -> void:
    flash_age = 0.0

func alternar_onda() -> void:
    wave_on = not wave_on

func alternar_material() -> void:
    shared = not shared
    sprite_b.material = mat_a if shared else mat_b

func disparar_rajada() -> void:
    # Limpa partículas anteriores e inicia outro ciclo, inclusive após finished.
    emitter.restart(true)

func restaurar() -> void:
    clock = 0.0
    flash_age = 0.4
    wave_on = false
    shared = false
    finishes = 0
    sprite_b.material = mat_b
    remove_child(emitter)
    emitter.queue_free()
    criar_emissor()

func _unhandled_key_input(event: InputEvent) -> void:
    if not event is InputEventKey or not event.pressed or event.echo:
        return
    if event.ctrl_pressed or event.alt_pressed or event.meta_pressed:
        return
    match event.keycode:
        KEY_F: disparar_flash()
        KEY_O: alternar_onda()
        KEY_M: alternar_material()
        KEY_P: disparar_rajada()
        KEY_R: restaurar()
