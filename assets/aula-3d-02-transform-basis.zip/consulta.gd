extends Node

@export var peca: Node3D

func _ready() -> void:
    # O controlador da raiz instala a pose em _ready depois dos filhos.
    mostrar.call_deferred()

func mostrar() -> void:
    if not is_instance_valid(peca):
        push_warning("Atribua Base/Peca no campo peca do Node extra.")
        return
    var ponto := Vector3(1, 0, 0)
    print("Coluna x no pai: ", peca.transform.basis.x)
    print("Coluna y no pai: ", peca.transform.basis.y)
    print("Coluna z no pai: ", peca.transform.basis.z)
    print("Origem no pai: ", peca.transform.origin)
    print("Ponto no pai: ", peca.transform * ponto)
    print("Ponto no mundo: ", peca.global_transform * ponto)
    print("Apenas vetor, sem translação: ", peca.transform.basis * ponto)
    print("Comprimentos: ", peca.basis.x.length(), ", ", peca.basis.y.length(), ", ", peca.basis.z.length())
