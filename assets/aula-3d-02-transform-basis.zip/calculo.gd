extends RefCounted

# Escala uniforme positiva; somente rotações próprias, sem cisalhamento.
static func transformar(pitch: float, yaw: float, roll: float,
        ordem: EulerOrder, peso: float, escala: float, origem: Vector3) -> Transform3D:
    var angulos := Vector3(deg_to_rad(pitch), deg_to_rad(yaw), deg_to_rad(roll))
    var inicial := Basis.from_euler(angulos, ordem)
    var q_inicial := inicial.get_rotation_quaternion().normalized()
    var q_final := q_inicial.slerp(Quaternion.IDENTITY, clampf(peso, 0.0, 1.0)).normalized()
    # Interpolamos apenas rotação; escala e origem são recompostas à parte.
    var base := Basis(q_final).scaled_local(Vector3.ONE * escala)
    return Transform3D(base, origem)

static func girar_no_referencial(peca: Node3D, no_objeto: bool) -> void:
    # Usar numa peça válida da árvore com escala unitária e pai sem escala.
    # Ambos preservam a origem; rotate_y usa o eixo Y do PAI, não necessariamente mundial.
    if no_objeto:
        peca.rotate_object_local(Vector3.UP, deg_to_rad(30.0))
    else:
        peca.rotate_y(deg_to_rad(30.0))
