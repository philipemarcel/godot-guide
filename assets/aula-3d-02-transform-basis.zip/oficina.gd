extends Node3D

const CALCULO = preload("res://calculo.gd")
@onready var base: Node3D = $Base
@onready var peca: Node3D = $Base/Peca
var valores := {"rx": 20.0, "ry": 40.0, "rz": -10.0, "escala": 1.0, "ox": 2.0, "pai": 0.0, "peso": 0.0}
var sliders: Dictionary = {}
var rotulos: Dictionary = {}
var ordem: OptionButton
var leitura: Label
var ponto_visual: MeshInstance3D

func _ready() -> void:
    var layer := CanvasLayer.new()
    add_child(layer)
    var box := VBoxContainer.new()
    box.position = Vector2(16, 395)
    box.custom_minimum_size.x = 928
    layer.add_child(box)
    var grid := GridContainer.new()
    grid.columns = 4
    box.add_child(grid)
    criar_slider(grid, "rx", "Pitch X", -90, 90, 5)
    criar_slider(grid, "ry", "Yaw Y", -180, 180, 5)
    criar_slider(grid, "rz", "Roll Z", -180, 180, 5)
    criar_slider(grid, "escala", "Escala uniforme", 0.5, 2, 0.5)
    criar_slider(grid, "ox", "origin.x no pai", -2, 3, 0.5)
    criar_slider(grid, "pai", "Pai Y", 0, 90, 15)
    criar_slider(grid, "peso", "Peso SLERP", 0, 1, 0.05)
    ordem = OptionButton.new()
    ordem.add_item("YXZ: Ry * Rx * Rz")
    ordem.add_item("XYZ: Rx * Ry * Rz")
    ordem.item_selected.connect(func(_index: int): aplicar())
    grid.add_child(ordem)
    var row := HBoxContainer.new()
    box.add_child(row)
    for i in range(5):
        var button := Button.new()
        button.text = ["R: restaurar", "P: Y=90", "X=Y=90", "Singular A", "Singular B"][i]
        button.pressed.connect(exemplo.bind(i))
        row.add_child(button)
    leitura = Label.new()
    leitura.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
    box.add_child(leitura)
    var ajuda := Label.new()
    ajuda.text = "A/D yaw, Q/E pitch, Z/C roll: 5 graus por toque; P exemplo; R restaura. Sem movimento automatico."
    ajuda.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
    box.add_child(ajuda)
    ponto_visual = MeshInstance3D.new()
    var esfera := SphereMesh.new()
    esfera.radius = 0.09
    esfera.height = 0.18
    var material := StandardMaterial3D.new()
    material.albedo_color = Color.CYAN
    esfera.material = material
    ponto_visual.mesh = esfera
    add_child(ponto_visual)
    $Camera3D.position = Vector3(10, 8, 10)
    $Camera3D.look_at(Vector3(0, -3, 0), Vector3.UP)
    # Esta bancada usa os parâmetros da interface ao iniciar, não Transform salvo da peça.
    exemplo(0)

func criar_slider(parent: Node, chave: String, texto: String, minimo: float, maximo: float, passo: float) -> void:
    var box := VBoxContainer.new()
    box.custom_minimum_size.x = 220
    parent.add_child(box)
    var label := Label.new()
    box.add_child(label)
    rotulos[chave] = label
    var slider := HSlider.new()
    slider.min_value = minimo
    slider.max_value = maximo
    slider.step = passo
    slider.value = valores[chave]
    slider.set_meta("titulo", texto)
    box.add_child(slider)
    sliders[chave] = slider
    slider.value_changed.connect(ajustar.bind(chave))

func ajustar(valor: float, chave: String) -> void:
    valores[chave] = valor
    aplicar()

func exemplo(tipo: int) -> void:
    valores = {"rx": 20.0, "ry": 40.0, "rz": -10.0, "escala": 1.0, "ox": 2.0, "pai": 0.0, "peso": 0.0}
    ordem.select(0)
    if tipo == 1:
        valores.rx = 0.0
        valores.ry = 90.0
        valores.rz = 0.0
    elif tipo == 2:
        valores.rx = 90.0
        valores.ry = 90.0
        valores.rz = 0.0
    elif tipo == 3 or tipo == 4:
        valores.rx = 90.0
        valores.ry = 30.0 if tipo == 3 else 60.0
        valores.rz = 0.0 if tipo == 3 else 30.0
    aplicar()

func aplicar() -> void:
    for chave in sliders:
        sliders[chave].set_value_no_signal(valores[chave])
        rotulos[chave].text = "%s: %.2f" % [sliders[chave].get_meta("titulo"), valores[chave]]
    base.transform = Transform3D(Basis(Vector3.UP, deg_to_rad(valores.pai)), Vector3.ZERO)
    var ordem_euler := EULER_ORDER_YXZ if ordem.selected == 0 else EULER_ORDER_XYZ
    peca.transform = CALCULO.transformar(valores.rx, valores.ry, valores.rz, ordem_euler, valores.peso, valores.escala, Vector3(valores.ox, 0, 1))
    ponto_visual.global_position = peca.global_transform * Vector3(1, 0, 0)
    var b := peca.basis
    leitura.text = "Basis no pai: x=%s | y=%s | z=%s\norigin=%s | p=(1,0,0) no pai=%s | no mundo=%s\nComprimentos=(%.2f, %.2f, %.2f); peso=%.2f. Escala e origem fora do SLERP." % [b.x, b.y, b.z, peca.position, peca.transform * Vector3(1,0,0), ponto_visual.global_position, b.x.length(), b.y.length(), b.z.length(), valores.peso]

func _unhandled_key_input(event: InputEvent) -> void:
    if not event is InputEventKey or not event.pressed or event.echo:
        return
    if event.ctrl_pressed or event.alt_pressed or event.meta_pressed:
        return
    var teclas := {KEY_A: ["ry", -5], KEY_D: ["ry", 5], KEY_Q: ["rx", -5], KEY_E: ["rx", 5], KEY_Z: ["rz", -5], KEY_C: ["rz", 5]}
    if event.keycode == KEY_R:
        exemplo(0)
    elif event.keycode == KEY_P:
        exemplo(1)
    elif teclas.has(event.keycode):
        var acao: Array = teclas[event.keycode]
        var chave: String = acao[0]
        valores[chave] = clampf(valores[chave] + acao[1], sliders[chave].min_value, sliders[chave].max_value)
        aplicar()
    else:
        return
    get_viewport().set_input_as_handled()
