# Testes na Godot 4.5 — todos pendentes

Registre versão/renderizador, resultados e erros reais. Não aprovar com base no modelo JS.

- [ ] Importar/compilar projeto, scripts e cena sem erros; registrar avisos.
- [ ] F6: cubo, nariz, esfera do ponto, câmera, luz, rótulos e interface legíveis.
- [ ] R instala pose/interface inicial; sem movimento automático.
- [ ] P: colunas x=(0,0,−1), y=(0,1,0), z=(1,0,0), p no pai/mundo=(2,0,0).
- [ ] Escala 2: eixos com comprimento 2, p no pai=(2,0,−1).
- [ ] Só origin.x altera posição sem modificar Basis.
- [ ] P e pai Y=90°: p no pai=(2,0,0), no mundo=(0,0,−2).
- [ ] X=Y=90°: YXZ z=(0,−1,0); XYZ z=(1,0,0).
- [ ] Singular A/B: mesma Basis/ponto com Euler diferentes.
- [ ] P e peso 0,5: Y=45°, p≈(2.707,0,0.293).
- [ ] Peso 1, escala 2: p=(4,0,1), escala preservada, identidade relativa ao pai.
- [ ] Botões/sliders e A/D/Q/E/Z/C/P/R coerentes; repetição/modificadores ignorados.
- [ ] consulta.gd em Node extra com Peca atribuída lê depois da pose inicial; sem referência inválida.
- [ ] Em teste isolado, girar_no_referencial preserva origem e distingue Y do pai/objeto numa peça inclinada com escala 1.
- [ ] Conferir câmera/UI nos extremos e todos os erros/avisos do motor.
