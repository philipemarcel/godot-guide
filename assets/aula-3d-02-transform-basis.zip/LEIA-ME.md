# Aula 3D 2 — Transform3D e Basis

Referência: Godot 4.5, GDScript, Compatibility, desktop. Projeto revisado documentalmente; ainda não compilado/executado no motor neste ambiente. Testes matemáticos JS não homologam GDScript ou cenas.

## Abrir e estudar

Extraia os sete arquivos, importe project.godot e execute oficina.tscn com F6. A cena tem cubo, nariz em −Z, piso, eixos mundiais, câmera e luz. oficina.gd cria controles e uma esfera ciana no ponto local p=(1,0,0) transformado ao mundo. Esfera do ponto e nariz da peça são coisas distintas. Marker3D é referência de editor, não a esfera visível.

A bancada usa os parâmetros da interface ao iniciar e substitui o Transform salvo de Base/Peca. R restaura pitch=20°, yaw=40°, roll=−10°, ordem YXZ, escala 1, origin=(2,0,1), pai Y=0 e peso 0. Não há física nem movimento automático.

- P: exemplo pitch=0°, yaw=90°, roll=0°. Com escala 1, x=(0,0,−1), y=(0,1,0), z=(1,0,0). p no pai=(2,0,0).
- Escala 2 nesse exemplo: colunas medem 2 e p no pai=(2,0,−1).
- P e pai Y=90°: p no pai=(2,0,0), no mundo=(0,0,−2). Base tem origem zero e escala 1.
- X=Y=90: compare ordem YXZ/XYZ com peso 0. A coluna z é (0,−1,0) ou (1,0,0), respectivamente.
- Singular A/B: YXZ e pitch=90°, yaw/roll 30°/0° ou 60°/30°. Mesma orientação, ângulos distintos; dependência dos parâmetros Euler, não trava física.
- P e peso 0,5: rotação Y=45°, p no pai≈(2.707,0,0.293). Peso 1: rotação identidade, p=(3,0,1). Com escala 2 e peso 1: p=(4,0,1).

SLERP interpola apenas rotação por quaternions unitários; origin e escala são recompostas à parte. Peso manual não é tempo nem velocidade angular. Identidade alvo é NO PAI. Uma Basis com escala 2 é ortogonal, mas não ortonormal. orthonormalized devolve uma cópia e remove escala/cisalhamento; não é correção que preserve tudo.

## Controles

Sliders ajustam pose inicial em graus, escala uniforme positiva, origin.x, pai Y e peso. Ordem é YXZ (RY×RX×RZ) ou XYZ (RX×RY×RZ); para vetor-coluna, matriz à direita atua primeiro. As colunas numéricas são no pai. Os rótulos das malhas de eixos são mundiais. O cubo da cena representa a Basis aplicada, não anéis mecânicos.

A/D mudam yaw, Q/E pitch, Z/C roll, por 5°; P exemplo e R restaura. Teclado tratado quando a interface não consome a entrada; repetição/modificadores ignorados. Não exige InputMap. Use botões e sliders se a interface tiver foco. No navegador também há setas e atalhos restritos ao foco da cena.

## Scripts opcionais

calculo.gd (RefCounted) é chamado por preload; não anexar em Node3D. transformar compõe a transformação aplicada. girar_no_referencial é consulta separada, não conectada aos botões; pressupõe nó válido na árvore e escala unitária. rotate_y usa Y do pai, rotate_object_local usa Y da peça; preservam sua origem. transform.rotated é outra operação e pode mover origin.

consulta.gd pode ser anexado em Node extra sob Oficina, atribuindo Base/Peca no campo exportado. mostrar é agendado depois dos _ready para ler a pose instalada pelo controlador; imprime uma vez no Output. Para ler depois de outro ajuste, chamar mostrar novamente ou usar as leituras da bancada. Não substituir oficina.gd.

Sem algoritmos de perseguição/looking_at ou alinhamento a terreno. Sem cisalhamento, reflexão, escala zero/negativa/não uniforme, hierarquia com pai escalado, corpo físico ou garantia de renderização. Câmera/interface e extremos precisam de conferência visual na Godot. Modelo do navegador é Canvas/JS matemático, sem Godot/WebGL/física e sem oclusão real.
