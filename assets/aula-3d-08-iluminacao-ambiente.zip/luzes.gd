extends RefCounted
# Escala ilustrativa de energia; unidades físicas de luz desativadas no projeto.
static func configurar(direcional: DirectionalLight3D, omni: OmniLight3D,
        spot: SpotLight3D, tipo: int, energia: float, alcance: float,
        azimute: float, meia_abertura: float, sombras: bool) -> void:
    direcional.visible = tipo == 2
    omni.visible = tipo == 1
    spot.visible = tipo == 0
    var direcao := Vector3(sin(deg_to_rad(azimute)), -0.6,
            cos(deg_to_rad(azimute))).normalized()
    # look_at orienta o eixo -Z para o alvo. Posição não altera luz direcional.
    direcional.look_at(direcional.global_position + direcao, Vector3.UP)
    spot.look_at(spot.global_position + direcao, Vector3.UP)
    omni.omni_range = alcance
    spot.spot_range = alcance
    spot.spot_angle = meia_abertura # 32 graus = cone total de 64 graus.
    omni.omni_attenuation = 1.0
    spot.spot_attenuation = 1.0
    spot.spot_angle_attenuation = 1.0
    for luz: Light3D in [direcional, omni, spot]:
        luz.light_energy = energia
        luz.shadow_enabled = sombras
        luz.light_volumetric_fog_energy = 1.0
    # O mesmo light_energy não garante igual iluminância entre tipos de luz.
