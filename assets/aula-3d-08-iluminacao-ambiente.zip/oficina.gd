extends Node3D
const LUZES = preload("res://luzes.gd")
const AMBIENTE = preload("res://ambiente.gd")
var sol: DirectionalLight3D
var omni: OmniLight3D
var spot: SpotLight3D
var ambiente: Environment
var painel: VBoxContainer
var leitura: Label
var tipo: OptionButton
var tonemap: OptionButton
var energia: HSlider
var alcance: HSlider
var angulo: HSlider
var abertura: HSlider
var preenchimento: HSlider
var densidade: HSlider
var sombras: CheckButton
var volume: CheckButton
var glow: CheckButton
var ssao: CheckButton

func material(cor: Color) -> StandardMaterial3D:
    var m := StandardMaterial3D.new()
    m.albedo_color = cor
    m.roughness = 0.65
    return m

func peca(nome: String, mesh: Mesh, posicao: Vector3,
        mat: Material) -> MeshInstance3D:
    var instancia := MeshInstance3D.new()
    instancia.name = nome
    instancia.mesh = mesh
    instancia.position = posicao
    instancia.material_override = mat
    add_child(instancia)
    return instancia

func slider(texto: String, minimo: float, maximo: float,
        passo: float, valor: float) -> HSlider:
    var l := Label.new()
    l.text = texto
    painel.add_child(l)
    var s := HSlider.new()
    s.min_value = minimo
    s.max_value = maximo
    s.step = passo
    s.value = valor
    s.custom_minimum_size.x = 320
    painel.add_child(s)
    s.value_changed.connect(func(_v: float): atualizar())
    return s

func chave(texto: String, valor: bool) -> CheckButton:
    var c := CheckButton.new()
    c.text = texto
    c.button_pressed = valor
    painel.add_child(c)
    c.toggled.connect(func(_v: bool): atualizar())
    return c

func _ready() -> void:
    var piso := PlaneMesh.new()
    piso.size = Vector2(12, 14)
    peca("Piso", piso, Vector3(0, 0, 5), material(Color(0.45, 0.27, 0.12)))
    var esfera := SphereMesh.new()
    esfera.radius = 1.0
    esfera.height = 2.0
    peca("Obstaculo", esfera, Vector3(0, 1.1, 4.5), material(Color(0.2, 0.3, 0.32)))
    var caixa := BoxMesh.new()
    caixa.size = Vector3(0.6, 1.4, 0.6)
    for i in range(3):
        peca("Marcador%d" % i, caixa, Vector3(2.7, 0.7, 2 + i * 3),
                material(Color(0.55, 0.55, 0.55)))
    var emissivo := material(Color(0.05, 0.1, 0.12))
    emissivo.emission_enabled = true
    emissivo.emission = Color(0.15, 0.8, 1.0)
    emissivo.emission_energy_multiplier = 4.0
    peca("EmissorSemGI", caixa, Vector3(-2.7, 0.7, 5), emissivo)
    sol = DirectionalLight3D.new()
    sol.name = "Sol"
    sol.sky_mode = DirectionalLight3D.SKY_MODE_LIGHT_AND_SKY
    add_child(sol)
    omni = OmniLight3D.new()
    omni.name = "Lampada"
    omni.position = Vector3(0, 3, 0)
    add_child(omni)
    spot = SpotLight3D.new()
    spot.name = "Holofote"
    spot.position = Vector3(0, 3, 0)
    add_child(spot)
    var world := WorldEnvironment.new()
    world.name = "Mundo"
    ambiente = AMBIENTE.criar()
    world.environment = ambiente
    add_child(world)
    var camera := Camera3D.new()
    camera.position = Vector3(11, 10, 15)
    camera.fov = 60
    add_child(camera)
    camera.look_at(Vector3(0, 0, 4.5), Vector3.UP)
    camera.make_current()
    criar_interface()
    restaurar()

func criar_interface() -> void:
    var layer := CanvasLayer.new()
    add_child(layer)
    var scroll := ScrollContainer.new()
    scroll.position = Vector2(16, 16)
    scroll.size = Vector2(410, 900)
    layer.add_child(scroll)
    var fundo := PanelContainer.new()
    scroll.add_child(fundo)
    painel = VBoxContainer.new()
    painel.add_theme_constant_override("separation", 10)
    fundo.add_child(painel)
    leitura = Label.new()
    leitura.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
    leitura.custom_minimum_size.x = 350
    painel.add_child(leitura)
    tipo = OptionButton.new()
    for nome in ["Spot", "Omni", "Directional"]:
        tipo.add_item(nome)
    painel.add_child(tipo)
    tipo.item_selected.connect(func(_v: int): atualizar())
    energia = slider("Energia normalizada", 0, 5, 0.25, 3)
    alcance = slider("Alcance Omni/Spot (u)", 2, 18, 1, 12)
    angulo = slider("Azimute Spot/Directional (graus)", -60, 60, 5, 0)
    abertura = slider("Meia abertura Spot (graus)", 10, 60, 2, 32)
    preenchimento = slider("Preenchimento ambiente", 0, 0.6, 0.02, 0.12)
    densidade = slider("Densidade da neblina", 0, 0.3, 0.02, 0)
    sombras = chave("Sombras", true)
    volume = chave("Volumetric Fog — requer Forward+", false)
    glow = chave("Glow — observar o emissor ciano", false)
    ssao = chave("SSAO — requer Forward+", false)
    tonemap = OptionButton.new()
    tonemap.add_item("Linear", Environment.TONE_MAPPER_LINEAR)
    tonemap.add_item("ACES", Environment.TONE_MAPPER_ACES)
    if RenderingServer.get_current_rendering_method() != &"mobile":
        tonemap.add_item("AgX", Environment.TONE_MAPPER_AGX)
    painel.add_child(tonemap)
    tonemap.item_selected.connect(func(_v: int): atualizar())
    var botao := Button.new()
    botao.text = "Restaurar parâmetros"
    botao.pressed.connect(restaurar)
    painel.add_child(botao)

func restaurar() -> void:
    tipo.select(0)
    tonemap.select(0)
    energia.set_value_no_signal(3)
    alcance.set_value_no_signal(12)
    angulo.set_value_no_signal(0)
    abertura.set_value_no_signal(32)
    preenchimento.set_value_no_signal(0.12)
    densidade.set_value_no_signal(0)
    sombras.set_pressed_no_signal(true)
    volume.set_pressed_no_signal(false)
    glow.set_pressed_no_signal(false)
    ssao.set_pressed_no_signal(false)
    atualizar()

func atualizar() -> void:
    if not is_instance_valid(ssao):
        return # Interface ainda em montagem.
    var metodo := RenderingServer.get_current_rendering_method()
    var forward := metodo == &"forward_plus"
    volume.disabled = not forward
    ssao.disabled = not forward
    alcance.editable = tipo.selected != 2
    abertura.editable = tipo.selected == 0
    angulo.editable = tipo.selected != 1
    LUZES.configurar(sol, omni, spot, tipo.selected, energia.value,
            alcance.value, angulo.value, abertura.value, sombras.button_pressed)
    AMBIENTE.configurar(ambiente, preenchimento.value, densidade.value,
            volume.button_pressed, glow.button_pressed, ssao.button_pressed,
            tonemap.get_selected_id())
    leitura.text = ("Renderizador: %s\nEnergia %.2f | alcance %.1f u\n"
            + "Azimute %.0f graus | cone total %.0f graus\n"
            + "Ambiente %.2f | densidade %.2f\n"
            + "Céu visível; sem GI/reflexos do céu. Sem colisão/locomoção.\n"
            + "R restaura quando o foco não está num controle.") % [
            metodo, energia.value, alcance.value, angulo.value,
            abertura.value * 2, preenchimento.value, densidade.value]

func _unhandled_key_input(event: InputEvent) -> void:
    if event is InputEventKey and event.pressed and not event.echo:
        if event.ctrl_pressed or event.alt_pressed or event.meta_pressed:
            return
        if event.keycode == KEY_R:
            restaurar()
            get_viewport().set_input_as_handled()
