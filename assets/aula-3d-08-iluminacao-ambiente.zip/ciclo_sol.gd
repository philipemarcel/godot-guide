extends DirectionalLight3D
# Extensão independente: NÃO anexada à cena da bancada controlada.
# Anexar a uma DirectionalLight3D em outra cena, com WorldEnvironment,
# Environment/BG_SKY, Sky e ProceduralSkyMaterial configurados.
@export_range(10.0, 1200.0) var segundos_por_volta := 120.0
@export var energia_dia := 1.2

func _process(delta: float) -> void:
    rotate_x(TAU * delta / segundos_por_volta)
    var direcao := -global_transform.basis.z.normalized()
    var acima_do_horizonte := direcao.y < 0.0
    light_energy = energia_dia if acima_do_horizonte else 0.0
    shadow_enabled = acima_do_horizonte
# A posição do disco solar acompanha a direção. Cores do céu, ambiente,
# exposição e luz noturna exigem decisões próprias: este ciclo não as anima.
