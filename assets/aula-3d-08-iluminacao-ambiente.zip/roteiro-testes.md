# Roteiro de execução pendente — Godot 4.5

Registrar versão, método atual/driver, hardware, resultado esperado/observado e erros/avisos. Não marcar por leitura ou por teste do Canvas.

- [ ] Importar e executar sem erros; conferir árvore Remota, câmera atual e Environment atribuído.
- [ ] Restaurar; conferir valores e fontes mutuamente exclusivas. Alternar Spot/Omni/Directional e repetir.
- [ ] Directional: mover posição manualmente sem mudar resultado; rotacionar e observar direção. Evitar o controlador sobrescrever rotação durante essa comparação.
- [ ] Omni: variar posição/alcance e energia separadamente; rotação não deve mudar a emissão pontual.
- [ ] Spot: comparar meia abertura 10/32/60 (cones totais 20/64/120), azimute e alcance; conferir eixo -Z.
- [ ] Sombras: desligar/ligar, reduzir ambiente a zero, restaurar 0,12. Conferir bloqueio no piso e fontes sem energia; registrar acne/descolamento se ocorrer.
- [ ] Fonte/câmera: céu visível sem reflexos do céu, ambiente por cor; conferir que Camera3D.environment não sobrescreve o WorldEnvironment.
- [ ] Neblina comum: densidade 0/0,04/0,3; distâncias e marcadores. Não esperar resposta de volume aos cones de luz.
- [ ] Compatibility: Volumetric Fog e SSAO indisponíveis, Glow simples disponível. Confirmar estado real, sem supor pelo arquivo de projeto.
- [ ] Forward+: reabrir no método; neblina volumétrica com densidade 0/0,04, luz ativa/energia zero e contribuição volumétrica zero/um. Conferir posição da câmera e sombra no volume. Nenhum cone deve ser imposto como desenho fixo.
- [ ] Mobile, se disponível no hardware: conferir controles e AgX ausente; não declarar teste sem execução.
- [ ] Glow desligado/ligado: observar emissor sem atribuir luz no piso ao pós-processamento. Comparar Linear/ACES/AgX onde disponíveis com mesma exposição.
- [ ] SSAO somente Forward+: comparar com efeito desligado; conferir limites de tela e custo antes de concluir benefício.
- [ ] UI: foco, scroll, valores extremos, cliques repetidos, reset/R, modificadores e ausência de ações involuntárias durante edição.
- [ ] Extensão solar em cena separada: giro dependente de delta, horizonte, energia/sombras e disco procedural; registrar que cores/ambiente/noite não são animados.
- [ ] Corrigir divergências, repetir testes afetados e atualizar relatório/guia/índice de pendências antes de homologar.
