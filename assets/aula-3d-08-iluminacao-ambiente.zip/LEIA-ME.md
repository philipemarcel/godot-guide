# Oficina de iluminação e ambiente

Extraia todos os nove arquivos na mesma pasta, importe `project.godot` na Godot 4.5 e execute `oficina.tscn`. `oficina.gd` monta o cenário e a interface. `luzes.gd` e `ambiente.gd` fornecem operações separadas; não são scripts de nó. Não há física, locomoção nem GI.

O piso, esfera elevada, três marcadores e emissor ciano são referências visuais. As sombras são de renderização. Os marcadores reais não são cartões de radiância idêntica como os do modelo web; sua aparência também depende da luz e da perspectiva. Não exigir igualdade de pixels ou números entre Canvas e Godot.

Compare uma variável por vez. Tipo/energia/alcance/azimute/abertura e sombras pertencem à luz. Preenchimento, neblina, Glow e tonemapper pertencem ao Environment. O céu continua visível quando o preenchimento é zero; isso é deliberado. A câmera não sobrescreve o Environment.

Comece com neblina zero, Glow/SSAO desligados e tonemapper Linear. Na sombra, reduza o ambiente a zero e depois volte a 0,12. Spot usa meia abertura de 32 graus, cone total de 64. O mesmo valor de energia em luzes diferentes não garante a mesma iluminância. Confira sombras sem acrescentar formas físicas.

Ative densidade 0,04 para observar neblina comum. Para comparar a volumétrica, mude o renderizador para Forward+, confirme o método no painel e ative seu controle. A neblina comum é desligada nesse modo para não somar dois efeitos durante a comparação. O efeito depende de densidade, luz, material do meio, sombras e posição de observação; não há feixe garantido para qualquer configuração. Densidade zero remove a contribuição volumétrica mesmo com a opção marcada.

Glow usa o emissor ciano como referência. Alternar Glow não deveria criar iluminação no piso nesta cena sem GI. SSAO é uma aproximação em espaço de tela, não sombra completa nem GI. Nenhum efeito é custo zero; medir antes de criar presets de qualidade. As curvas Linear/ACES/AgX afetam a aparência, sem garantir realismo.

`ciclo_sol.gd` é extensão opcional para outra cena. Não participa da bancada e não anima cores do céu, luz da lua ou exposição. Veja `configuracao.txt` e execute o `roteiro-testes.md`. Scripts e cena ainda não foram compilados/executados na Godot neste ambiente; os testes do Canvas não homologam este projeto.
