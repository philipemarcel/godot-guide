extends RefCounted

static func criar() -> Environment:
    var e := Environment.new()
    e.background_mode = Environment.BG_SKY
    var ceu := Sky.new()
    var material := ProceduralSkyMaterial.new()
    material.sky_top_color = Color(0.08, 0.16, 0.24)
    material.sky_horizon_color = Color(0.45, 0.34, 0.23)
    ceu.sky_material = material
    e.sky = ceu
    # Céu visível separado do preenchimento e de reflexos.
    e.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
    e.ambient_light_color = Color(0.65, 0.72, 0.8)
    e.ambient_light_sky_contribution = 0.0
    e.reflected_light_source = Environment.REFLECTION_SOURCE_DISABLED
    return e

static func configurar(e: Environment, preenchimento: float,
        densidade: float, volume: bool, glow: bool, ssao: bool,
        tonemap: int) -> void:
    var metodo := RenderingServer.get_current_rendering_method()
    var forward := metodo == &"forward_plus"
    e.ambient_light_energy = preenchimento
    e.tonemap_mode = tonemap
    e.tonemap_exposure = 1.0
    e.glow_enabled = glow
    e.glow_intensity = 0.8
    e.glow_hdr_threshold = 1.0
    e.fog_enabled = densidade > 0.0 and not (volume and forward)
    e.fog_mode = Environment.FOG_MODE_EXPONENTIAL
    e.fog_density = densidade
    e.fog_light_color = Color(0.35, 0.45, 0.5)
    e.fog_light_energy = 1.0
    e.volumetric_fog_enabled = volume and forward
    e.volumetric_fog_density = densidade
    e.volumetric_fog_albedo = Color(0.9, 0.9, 0.9)
    e.volumetric_fog_emission = Color.BLACK
    e.ssao_enabled = ssao and forward
    # Glow existe em Compatibility 4.5, com implementação simplificada.
    # Volumetric Fog/SSAO não são habilitados fora do Forward+.
