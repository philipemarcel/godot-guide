extends RefCounted

static func osso(s: Skeleton3D, nome: String, pai: int, origem: Vector3) -> int:
    var id := s.add_bone(nome)
    if pai >= 0:
        s.set_bone_parent(id, pai)
    s.set_bone_rest(id, Transform3D(Basis.IDENTITY, origem))
    return id

static func peca(s: Skeleton3D, nome_osso: String, tamanho: Vector3,
        offset: Vector3, cor: Color) -> BoneAttachment3D:
    var anexo := BoneAttachment3D.new()
    anexo.name = "Anexo_" + nome_osso
    s.add_child(anexo)
    anexo.bone_name = nome_osso
    anexo.override_pose = false
    var mesh := BoxMesh.new()
    mesh.size = tamanho
    var instancia := MeshInstance3D.new()
    instancia.mesh = mesh
    instancia.position = offset
    var mat := StandardMaterial3D.new()
    mat.albedo_color = cor
    mat.roughness = 0.6
    instancia.material_override = mat
    anexo.add_child(instancia)
    return anexo

static func criar(pai: Node3D) -> Dictionary:
    var s := Skeleton3D.new()
    s.name = "Skeleton3D"
    pai.add_child(s)
    var raiz := osso(s, "Raiz", -1, Vector3.ZERO)
    var tronco := osso(s, "Tronco", raiz, Vector3(0, 1.1, 0))
    var braco := osso(s, "Braco_R", tronco, Vector3(0.35, 0.35, 0))
    osso(s, "Mao_R", braco, Vector3(0.7, 0, 0))
    osso(s, "Perna_L", raiz, Vector3(-0.2, 1.1, 0))
    osso(s, "Perna_R", raiz, Vector3(0.2, 1.1, 0))
    s.reset_bone_poses()
    peca(s, "Tronco", Vector3(0.6, 0.75, 0.3), Vector3(0, 0.35, 0), Color(0.6, 0.4, 0.16))
    peca(s, "Braco_R", Vector3(0.7, 0.12, 0.15), Vector3(0.35, 0, 0), Color(0.1, 0.7, 0.75))
    peca(s, "Perna_L", Vector3(0.15, 1, 0.18), Vector3(0, -0.5, 0), Color(0.6, 0.4, 0.16))
    peca(s, "Perna_R", Vector3(0.15, 1, 0.18), Vector3(0, -0.5, 0), Color(0.6, 0.4, 0.16))
    var mao := BoneAttachment3D.new()
    mao.name = "SuporteMao"
    s.add_child(mao)
    mao.bone_name = "Mao_R"
    mao.override_pose = false
    var encaixe := Node3D.new()
    encaixe.name = "EncaixeLocal"
    mao.add_child(encaixe)
    var ferramenta := MeshInstance3D.new()
    ferramenta.name = "FerramentaRigida"
    var mesh := BoxMesh.new()
    mesh.size = Vector3(0.7, 0.08, 0.12)
    ferramenta.mesh = mesh
    ferramenta.position.x = 0.35
    encaixe.add_child(ferramenta)
    # Sem Skin ou pesos: cada peça inteira acompanha um anexo.
    return {"skeleton": s, "encaixe": encaixe}
