# Poses, filtro e encaixe

Extraia os nove arquivos, importe `project.godot` na Godot 4.5 e execute `oficina.tscn`. A cena é criada por código para não depender de um personagem licenciado ou de importação externa. O manequim é mecânico: seis ossos e peças rígidas em BoneAttachment3D. Não há Skin, pesos, deformação de vértices ou ciclos de caminhada.

Primeiro compare Parado, Passo e Lateral. São poses constantes com pistas completas para as duas pernas e o braço direito. O BlendSpace2D usa só um triângulo, sem triangulação automática. Pedidos fora de X+Y≤1 são divididos pela soma antes do envio. Essa é nossa política de entrada; não é uma afirmação sobre o algoritmo nativo fora dos triângulos.

O OneShot recebe a mistura na porta in e Acao na shot. O filtro seleciona a pista `Skeleton3D:Braco_R`; Mao_R acompanha a transformação herdada, sem pista própria. Ao desabilitar filtro, as pistas zeradas das pernas no clipe Acao também podem substituir a base. Não usar AnimationPlayer.play ao mesmo tempo para controlar essas pistas.

Nada avança sozinho. F dispara/reinicia; T avança 0,1 segundo da árvore; C cancela; R restaura. O cancelamento é processado com advance(0) antes de FIRE. Confirmar isso e os fades na execução real; não homologar apenas por ler o código. O contador manual do apoio conta comandos T desde F/C/R, enquanto a leitura active vem da árvore; não é medição de tempo de parede.

A ferramenta é filha de um EncaixeLocal dentro do anexo de Mao_R, com offset ajustável. O pivô do recurso, suas dimensões e orientação determinam o encaixe. Posição local zero não garante a palma em um modelo diferente. Para trocar equipamento em um jogo, valide a cena/raiz nova antes de retirar o antigo; não é implementado um inventário de armas aqui.

Para transferir ao personagem real, importar malha com esqueleto/Skin e clipes compatíveis, conferir rest pose, nomes, escalas, trilhas e loops. Trocar as poses constantes pelos ciclos necessários e completar a triangulação para as direções desejadas. A velocidade local pode alimentar o parâmetro, mas animar a pose não chama move_and_slide nem resolve deslocamento/colisão. Esse fluxo de importação/retarget é aprofundamento separado, ainda não executado.

No navegador, há uma aproximação angular em plano 2D com tempo manual. As fórmulas permitem conferir pesos e herança do offset, mas não reproduzem o misturador de quaternions, fades, Skin ou processamento interno da Godot. Não exigir igualdade pixel a pixel. O gráfico não tem arraste: sliders e teclas são as entradas disponíveis.
