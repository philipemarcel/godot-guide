extends RefCounted

static func animacao(nome: StringName) -> AnimationNodeAnimation:
    var a := AnimationNodeAnimation.new()
    a.animation = nome
    return a

static func criar() -> AnimationNodeBlendTree:
    var raiz := AnimationNodeBlendTree.new()
    var mistura := AnimationNodeBlendSpace2D.new()
    mistura.auto_triangles = false
    mistura.min_space = Vector2.ZERO
    mistura.max_space = Vector2.ONE
    mistura.blend_mode = AnimationNodeBlendSpace2D.BLEND_MODE_INTERPOLATED
    mistura.add_blend_point(animacao("Parado"), Vector2.ZERO)
    mistura.add_blend_point(animacao("Passo"), Vector2(1, 0))
    mistura.add_blend_point(animacao("Lateral"), Vector2(0, 1))
    mistura.add_triangle(0, 1, 2)
    var acao := AnimationNodeOneShot.new()
    acao.autorestart = false
    acao.fadein_time = 0.1
    acao.fadeout_time = 0.1
    acao.mix_mode = AnimationNodeOneShot.MIX_MODE_BLEND
    acao.filter_enabled = true
    acao.set_filter_path(NodePath("Skeleton3D:Braco_R"), true)
    raiz.add_node("Mistura", mistura, Vector2(0, 0))
    raiz.add_node("ClipeAcao", animacao("Acao"), Vector2(0, 180))
    raiz.add_node("Acao", acao, Vector2(250, 0))
    raiz.connect_node("Acao", 0, "Mistura")
    raiz.connect_node("Acao", 1, "ClipeAcao")
    raiz.connect_node("output", 0, "Acao")
    return raiz

static func limitar(pedido: Vector2) -> Vector2:
    var p := pedido.clamp(Vector2.ZERO, Vector2.ONE)
    return p / maxf(1.0, p.x + p.y)
    # Política radial desta bancada, aplicada ANTES de enviar ao BlendSpace.
