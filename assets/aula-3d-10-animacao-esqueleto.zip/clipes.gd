extends RefCounted
const OSSOS = ["Perna_L", "Perna_R", "Braco_R"]

static func pista(a: Animation, osso: String, tempos: Array, angulos: Array) -> void:
    var i := a.add_track(Animation.TYPE_ROTATION_3D)
    a.track_set_path(i, NodePath("Skeleton3D:" + osso))
    for k in range(tempos.size()):
        a.rotation_track_insert_key(i, tempos[k], Quaternion(Vector3.FORWARD, -angulos[k]))
    # FORWARD é -Z; sinal negativo equivale a giro positivo em +Z.

static func pose(angulos: Array) -> Animation:
    var a := Animation.new()
    a.length = 1.0
    a.loop_mode = Animation.LOOP_LINEAR
    for i in range(OSSOS.size()):
        pista(a, OSSOS[i], [0.0, 1.0], [angulos[i], angulos[i]])
    return a

static func criar(player: AnimationPlayer) -> void:
    var biblioteca := AnimationLibrary.new()
    biblioteca.add_animation("Parado", pose([0.0, 0.0, 0.0]))
    biblioteca.add_animation("Passo", pose([-0.35, 0.35, 0.1]))
    biblioteca.add_animation("Lateral", pose([0.45, 0.45, -0.25]))
    var reset := pose([0.0, 0.0, 0.0])
    reset.loop_mode = Animation.LOOP_NONE
    biblioteca.add_animation("RESET", reset)
    var acao := Animation.new()
    acao.length = 1.0
    acao.loop_mode = Animation.LOOP_NONE
    pista(acao, "Braco_R", [0.0, 0.5, 1.0], [0.0, 1.2, 0.0])
    pista(acao, "Perna_L", [0.0, 1.0], [0.0, 0.0])
    pista(acao, "Perna_R", [0.0, 1.0], [0.0, 0.0])
    biblioteca.add_animation("Acao", acao)
    player.add_animation_library("", biblioteca)
    # Três POSES constantes para isolar pesos, não três ciclos de caminhada.
