extends Node3D
const RIG = preload("res://rig.gd")
const CLIPES = preload("res://clipes.gd")
const GRAFO = preload("res://grafo.gd")
var arvore: AnimationTree
var encaixe: Node3D
var painel: VBoxContainer
var leitura: Label
var x: HSlider
var y: HSlider
var offset: HSlider
var filtro: CheckButton
var tempo := 0.0

func slider(texto: String, minimo: float, maximo: float, passo: float, valor: float) -> HSlider:
    var l := Label.new()
    l.text = texto
    painel.add_child(l)
    var s := HSlider.new()
    s.min_value = minimo
    s.max_value = maximo
    s.step = passo
    s.value = valor
    s.custom_minimum_size.x = 340
    painel.add_child(s)
    s.value_changed.connect(func(_v: float): atualizar())
    return s

func botao(texto: String, acao: Callable) -> void:
    var b := Button.new()
    b.text = texto
    painel.add_child(b)
    b.pressed.connect(acao)

func _ready() -> void:
    var dados := RIG.criar(self)
    encaixe = dados["encaixe"]
    var player := AnimationPlayer.new()
    player.name = "AnimationPlayer"
    player.root_node = NodePath("..")
    add_child(player)
    CLIPES.criar(player)
    arvore = AnimationTree.new()
    arvore.name = "AnimationTree"
    add_child(arvore)
    arvore.anim_player = NodePath("../AnimationPlayer")
    arvore.root_node = NodePath("..")
    arvore.tree_root = GRAFO.criar()
    arvore.callback_mode_process = AnimationMixer.ANIMATION_CALLBACK_MODE_PROCESS_MANUAL
    arvore.active = true
    var camera := Camera3D.new()
    camera.position = Vector3(3.5, 2.8, 5)
    add_child(camera)
    camera.look_at(Vector3(0.5, 1.3, 0), Vector3.UP)
    camera.make_current()
    var luz := DirectionalLight3D.new()
    luz.rotation_degrees = Vector3(-45, -30, 0)
    add_child(luz)
    var mundo := WorldEnvironment.new()
    var e := Environment.new()
    e.background_mode = Environment.BG_COLOR
    e.background_color = Color(0.04, 0.03, 0.02)
    e.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
    e.ambient_light_color = Color.WHITE
    e.ambient_light_energy = 0.3
    e.ambient_light_sky_contribution = 0.0
    mundo.environment = e
    add_child(mundo)
    criar_interface()
    restaurar()

func criar_interface() -> void:
    var layer := CanvasLayer.new()
    add_child(layer)
    var fundo := PanelContainer.new()
    fundo.position = Vector2(16, 16)
    layer.add_child(fundo)
    painel = VBoxContainer.new()
    painel.add_theme_constant_override("separation", 10)
    fundo.add_child(painel)
    leitura = Label.new()
    leitura.custom_minimum_size.x = 380
    leitura.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
    painel.add_child(leitura)
    x = slider("Pedido X — pose Passo", 0, 1, 0.05, 0)
    y = slider("Pedido Y — pose Lateral", 0, 1, 0.05, 0)
    offset = slider("Offset local da ferramenta (u)", 0, 0.5, 0.05, 0.2)
    filtro = CheckButton.new()
    filtro.text = "Filtrar somente Braco_R"
    filtro.button_pressed = true
    painel.add_child(filtro)
    filtro.toggled.connect(func(_v: bool): atualizar())
    botao("Disparar / repetir — F", disparar)
    botao("Avançar 0,1 s — T", avancar)
    botao("Cancelar ação — C", cancelar)
    botao("Restaurar — R", restaurar)

func atualizar() -> void:
    if not is_instance_valid(filtro):
        return
    var p := GRAFO.limitar(Vector2(x.value, y.value))
    arvore.set("parameters/Mistura/blend_position", p)
    var raiz := arvore.tree_root as AnimationNodeBlendTree
    var acao := raiz.get_node("Acao") as AnimationNodeOneShot
    acao.filter_enabled = filtro.button_pressed
    encaixe.position = Vector3(offset.value, 0, 0)
    arvore.advance(0.0)
    leitura.text = ("Tempo MANUAL %.1f s\nPedido (%.2f, %.2f) → aplicado %s\n"
            + "Pesos previstos: %.3f / %.3f / %.3f\nOneShot ativo: %s\n"
            + "Peças rígidas, sem Skin ou locomoção.\nX/Y não são posição no mundo.") % [
            tempo, x.value, y.value, p, 1.0 - p.x - p.y, p.x, p.y,
            arvore.get("parameters/Acao/active")]

func cancelar() -> void:
    arvore.set("parameters/Acao/request", AnimationNodeOneShot.ONE_SHOT_REQUEST_ABORT)
    arvore.advance(0.0) # Consumir o cancelamento antes de possível FIRE.
    tempo = 0.0
    atualizar()

func disparar() -> void:
    cancelar()
    arvore.set("parameters/Acao/request", AnimationNodeOneShot.ONE_SHOT_REQUEST_FIRE)
    arvore.advance(0.0)
    atualizar()

func avancar() -> void:
    tempo = snappedf(tempo + 0.1, 0.1)
    arvore.advance(0.1)
    atualizar()

func restaurar() -> void:
    x.set_value_no_signal(0)
    y.set_value_no_signal(0)
    offset.set_value_no_signal(0.2)
    filtro.set_pressed_no_signal(true)
    cancelar()

func _unhandled_key_input(event: InputEvent) -> void:
    if not event is InputEventKey or not event.pressed or event.echo:
        return
    if event.ctrl_pressed or event.alt_pressed or event.meta_pressed:
        return
    match event.keycode:
        KEY_F: disparar()
        KEY_T: avancar()
        KEY_C: cancelar()
        KEY_R: restaurar()
        _: return
    get_viewport().set_input_as_handled()
