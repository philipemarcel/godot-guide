# Roteiro pendente — Godot 4.5

Registrar versão, renderizador, resultado esperado/observado e erros/avisos.

- [ ] Importar, compilar e executar; conferir os quatro scripts, cena e referências.
- [ ] Conferir hierarquia dos seis ossos, rest transforms e poses iniciais; peças rígidas e anexo de Mao_R, override_pose=false.
- [ ] Conferir AnimationLibrary com Parado, Passo, Lateral, Acao e RESET; caminhos Skeleton3D:osso resolvidos em relação à raiz correta.
- [ ] Conferir conexões/portas do BlendTree e um triângulo explícito sem auto_triangles.
- [ ] Pedido(0,0): pesos1/0/0; (0,4;0,2):0,4/0,4/0,2; (1,1): aplicado(0,5;0,5), pesos0/0,5/0,5. Conferir pose nativa, sem exigir que sua mistura de rotações seja igual à aproximação angular web.
- [ ] Sem T, nada avança automaticamente. F e depois cinco T: aproximadamente metade da ação. Conferir fades0,1 e final após cerca de1s da árvore.
- [ ] F durante ação e após término: ABORT consumido antes de FIRE; confirmar reinício e active real. C/R durante ação, depois novos T: sem ação antiga reaparecendo.
- [ ] Filtro ligado: pernas mantêm sua base. Desligado: clipe Acao pode afetar as pistas das pernas. Conferir paths exatos e braço/mão herdada.
- [ ] Offset0/0,2/0,5 em diferentes poses/instantes; ferramenta deve acompanhar orientação local da mão, sem presumir que zero encaixa qualquer asset.
- [ ] Extremos, chamadas repetidas, foco/teclas/modificadores e reset de sliders/filtro/offset.
- [ ] Se adotar importação: GLB/Skin/pesos, rest pose, nomes, escala, clipes/loops e anexo no recurso real; não considerar o rig procedural prova dessa importação.
- [ ] Se ampliar para locomoção: adicionar direções/clipes, triangulação, velocidade local e controlador físico separadamente; observar foot sliding e root motion quando aplicáveis.
- [ ] Corrigir divergências e atualizar relatório/guia/índice antes de homologar.
