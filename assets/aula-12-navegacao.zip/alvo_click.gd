extends Node2D
# alvo_click.gd: em CenarioMalha; o Marker2D Alvo é filho direto.
func _unhandled_input(event: InputEvent) -> void:
    if event is InputEventMouseButton and event.pressed and event.button_index == MOUSE_BUTTON_LEFT:
        $Alvo.global_position = get_global_mouse_position()
