extends CharacterBody2D
# sentinela.gd: no corpo Sentinela; export Target recebe o Marker2D Alvo.
@export var target: Node2D
@export var status: Label
@export var speed: float = 80.0
@export var use_avoidance: bool = false
@onready var agent: NavigationAgent2D = $NavigationAgent2D
var assigned: bool = false
var last_goal := Vector2.ZERO

func _ready() -> void:
    motion_mode = CharacterBody2D.MOTION_MODE_FLOATING
    agent.max_speed = speed
    agent.avoidance_enabled = use_avoidance
    agent.velocity_computed.connect(_safe_velocity)

func _physics_process(delta: float) -> void:
    if not is_instance_valid(target):
        velocity = Vector2.ZERO
        return
    # Aguarda a primeira sincronização deste mapa. Não é um prazo fixo.
    if NavigationServer2D.map_get_iteration_id(agent.get_navigation_map()) == 0:
        if status != null:
            status.text = "Mapa aguardando sincronização"
        return
    if not assigned or last_goal.distance_to(target.global_position) > 4.0:
        last_goal = target.global_position
        agent.target_position = last_goal
        assigned = true
    var desired := Vector2.ZERO
    if not agent.is_navigation_finished():
        var next := agent.get_next_path_position()
        # Reduz sobrepassagem ao se aproximar do próximo ponto.
        desired = global_position.direction_to(next) * minf(speed, global_position.distance_to(next) / delta)
    if status != null:
        status.text = "Alvo alcançado" if agent.is_target_reached() else ("Fim do caminho; alvo não alcançado" if agent.is_navigation_finished() else "Seguindo caminho")
    if agent.avoidance_enabled:
        agent.velocity = desired
    else:
        _move(desired)

func _safe_velocity(safe: Vector2) -> void:
    if agent.avoidance_enabled and is_instance_valid(target):
        _move(safe)

func _move(value: Vector2) -> void:
    velocity = value
    move_and_slide()
