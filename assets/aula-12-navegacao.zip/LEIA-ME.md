# Aula 12 — navegação 2D

Referência: Godot 4.5. Scripts revisados documentalmente, ainda sem execução no motor neste ambiente.

Cena principal: um Node2D Grade com grade.gd. Janela 640 × 360. Esquerdo: destino; direito: parede. Setas selecionam célula; Enter define destino; Espaço alterna parede; R reinicia. As instruções e os resultados estão na aula.

Extensão em outra cena: CenarioMalha recebe alvo_click.gd. Sentinela é CharacterBody2D, recebe sentinela.gd e tem NavigationAgent2D filho. Configure export Target, Status, fontes do bake, formas e camadas conforme o roteiro. distancia.gd é apenas um monitor Label para dois agentes.

Não é um projeto pronto. A grade não precisa de texturas; na extensão, use Polygon2D para arte simples. Planejamento, colisão e avoidance são sistemas separados.
