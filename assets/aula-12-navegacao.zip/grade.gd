extends Node2D
# grade.gd: cena principal Grade (Node2D), sem outros nós obrigatórios.
const SIZE := Vector2i(12, 7)
const CELL := 32.0
const ORIGIN := Vector2(16, 16)
var grid := AStarGrid2D.new()
var start := Vector2i(1, 3)
var goal := Vector2i(10, 3)
var cursor := Vector2i(1, 3)
var ids: Array[Vector2i] = []
var points := PackedVector2Array()
var actor := Vector2.ZERO
var next_index: int = 1
var message: String = ""

func _ready() -> void:
    grid.region = Rect2i(Vector2i.ZERO, SIZE)
    grid.cell_size = Vector2(CELL, CELL)
    grid.offset = ORIGIN + Vector2(CELL, CELL) * 0.5
    grid.diagonal_mode = AStarGrid2D.DIAGONAL_MODE_NEVER
    grid.default_compute_heuristic = AStarGrid2D.HEURISTIC_MANHATTAN
    grid.default_estimate_heuristic = AStarGrid2D.HEURISTIC_MANHATTAN
    grid.update()
    for y in range(1, 6):
        grid.set_point_solid(Vector2i(5, y), true)
    replan()

func center(cell: Vector2i) -> Vector2:
    return ORIGIN + (Vector2(cell) + Vector2(0.5, 0.5)) * CELL

func replan() -> void:
    ids = grid.get_id_path(start, goal)
    points = grid.get_point_path(start, goal)
    actor = center(start)
    next_index = 1
    message = "Sem rota" if ids.is_empty() else "%d passos / %d pontos" % [ids.size() - 1, ids.size()]
    queue_redraw()

func apply(cell: Vector2i, wall: bool) -> void:
    if not grid.region.has_point(cell):
        return
    if wall:
        if cell == start or cell == goal:
            return
        grid.set_point_solid(cell, not grid.is_point_solid(cell))
        # Não chame update(): ele apagaria solidez/pesos dos pontos.
    else:
        if grid.is_point_solid(cell):
            message = "Destino bloqueado: escolha uma célula livre"
            queue_redraw()
            return
        goal = cell
    replan()

func _unhandled_input(event: InputEvent) -> void:
    if event is InputEventMouseButton and event.pressed:
        var local := to_local(get_global_mouse_position())
        var cell := Vector2i(((local - ORIGIN) / CELL).floor())
        if event.button_index == MOUSE_BUTTON_LEFT:
            apply(cell, false)
        elif event.button_index == MOUSE_BUTTON_RIGHT:
            apply(cell, true)
    if event is InputEventKey and event.pressed and not event.echo:
        match event.physical_keycode:
            KEY_LEFT: cursor.x = maxi(0, cursor.x - 1)
            KEY_RIGHT: cursor.x = mini(SIZE.x - 1, cursor.x + 1)
            KEY_UP: cursor.y = maxi(0, cursor.y - 1)
            KEY_DOWN: cursor.y = mini(SIZE.y - 1, cursor.y + 1)
            KEY_ENTER: apply(cursor, false)
            KEY_SPACE: apply(cursor, true)
            KEY_R: replan()
        queue_redraw()

func _physics_process(delta: float) -> void:
    var budget := 64.0 * delta
    while next_index < points.size() and budget > 0.0:
        var distance := actor.distance_to(points[next_index])
        if distance <= budget:
            actor = points[next_index]
            budget -= distance
            next_index += 1
        else:
            actor = actor.move_toward(points[next_index], budget)
            budget = 0.0
    queue_redraw()

func _draw() -> void:
    for y in range(SIZE.y):
        for x in range(SIZE.x):
            var cell := Vector2i(x, y)
            var color := Color("6c4526") if grid.is_point_solid(cell) else Color("21190e")
            if ids.has(cell):
                color = Color("235654")
            draw_rect(Rect2(ORIGIN + Vector2(cell) * CELL, Vector2(CELL - 1, CELL - 1)), color)
    if points.size() > 1:
        draw_polyline(points, Color("edc578"), 2.0)
    draw_circle(center(start), 7.0, Color("d4a359"))
    draw_circle(center(goal), 9.0, Color("5ce1e6"))
    draw_circle(actor, 5.0, Color.WHITE)
    draw_rect(Rect2(ORIGIN + Vector2(cursor) * CELL, Vector2(CELL, CELL)), Color.WHITE, false, 2.0)
    var font := ThemeDB.fallback_font
    var phase := " | chegou" if not points.is_empty() and next_index >= points.size() else (" | seguindo" if not points.is_empty() else "")
    draw_string(font, Vector2(16, 264), message + phase, HORIZONTAL_ALIGNMENT_LEFT, -1, 16)
    draw_string(font, Vector2(16, 288), "Clique: destino | direito: parede | setas + Enter/Espaco | R: reiniciar", HORIZONTAL_ALIGNMENT_LEFT, -1, 14)
