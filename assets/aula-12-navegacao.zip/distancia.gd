extends Label
# distancia.gd: em um Label extra, somente na extensão com duas sentinelas.
@export var first: Node2D
@export var second: Node2D

func _process(_delta: float) -> void:
    if is_instance_valid(first) and is_instance_valid(second):
        text = "Distância entre centros: %.1f px" % first.global_position.distance_to(second.global_position)
