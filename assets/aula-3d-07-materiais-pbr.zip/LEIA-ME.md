# Materiais PBR — prática controlada
Extraia os sete arquivos e importe project.godot na Godot4.5. Execute oficina.tscn. Oficina monta a cena/UI em runtime; materiais.gd contém fábricas e mapas gerados. Não há downloads externos ou InputMap. Scripts/cena revisados documentalmente; compilação/execução no motor pendentes.

A é editável, B é referência. A luz afeta ambas. Compartilhar aplica a mesma referência; descompartilhar duplica A e restaura B ao material base. Duplicação rasa mantém texturas compartilhadas, sem editá-las. Uma superfície por esfera, material_override tem precedência consistente.

Compare metallic0/1 e roughness0,2/0,8 sob as mesmas luzes. Cor dourada não basta para calibrar latão físico. Normal altera iluminação sem silhueta; mapas ORM são dados didáticos e multiplicam escalares. A alternativa ORMMaterial3D está na biblioteca, não é uma troca automática pela UI.

Desligue luz direta e céu para isolar emissão: a peça continua visível ao emitir, mas não há GI/Glow para iluminar o piso ou produzir halo. Cor emissiva é ciano independente do albedo. O Canvas usa outro shader analítico, com luz direta e sem reflexo de céu; não exija imagens idênticas.

F ou botão aplica overlay só em A por0,35s. Um único Timer reinicia na repetição. R interrompe o flash e restaura tudo. Esc libera foco da UI. Sem vidro, refração, locomoção ou ShaderMaterial por instância. Execute roteiro-testes.md para homologar.
