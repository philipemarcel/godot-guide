extends RefCounted
## Cores e números ilustrativos, não medições de materiais reais.
static func base() -> StandardMaterial3D:
    var m := StandardMaterial3D.new()
    m.albedo_color = Color("d4a359")
    m.metallic = 1.0
    m.roughness = 0.2
    m.metallic_specular = 0.5
    m.emission_enabled = true
    m.emission = Color("5ce1e6")
    m.emission_energy_multiplier = 0.0
    return m

static func tornar_unico(peca: MeshInstance3D) -> StandardMaterial3D:
    # Prática com UMA superfície. material_override tem precedência sobre slots.
    if peca.mesh == null or peca.mesh.get_surface_count() == 0:
        push_error("Malha sem superfície")
        return null
    var original := peca.get_active_material(0) as StandardMaterial3D
    if original == null:
        push_error("Esta prática exige StandardMaterial3D")
        return null
    var copia := original.duplicate() as StandardMaterial3D
    peca.material_override = copia
    # Cópia rasa: texturas permanecem compartilhadas; aqui elas não são editadas.
    return copia

static func mapa_normal() -> ImageTexture:
    var image := Image.create(64,64,false,Image.FORMAT_RGBA8)
    for y in range(64):
        for x in range(64):
            var n := Vector3(-0.5 * cos(TAU * 8.0 * x / 64.0),0,1).normalized()
            image.set_pixel(x,y,Color(n.x * 0.5 + 0.5,n.y * 0.5 + 0.5,n.z * 0.5 + 0.5,1))
    return ImageTexture.create_from_image(image)

static func mapa_orm() -> ImageTexture:
    # Dados lineares didáticos: R=AO, G=roughness, B=metallic. Não é bake real.
    var image := Image.create(64,64,false,Image.FORMAT_RGBA8)
    for y in range(64):
        for x in range(64):
            image.set_pixel(x,y,Color(0.6 + 0.4 * x / 63.0,0.25 + 0.5 * y / 63.0,1.0 if x < 32 else 0.0,1))
    return ImageTexture.create_from_image(image)

static func aplicar_mapas(m: StandardMaterial3D, normal: Texture2D, orm: Texture2D, usar_normal: bool, usar_orm: bool) -> void:
    m.normal_enabled = usar_normal
    m.normal_texture = normal if usar_normal else null
    m.ao_enabled = usar_orm
    m.ao_texture = orm if usar_orm else null
    m.ao_texture_channel = BaseMaterial3D.TEXTURE_CHANNEL_RED
    m.roughness_texture = orm if usar_orm else null
    m.roughness_texture_channel = BaseMaterial3D.TEXTURE_CHANNEL_GREEN
    m.metallic_texture = orm if usar_orm else null
    m.metallic_texture_channel = BaseMaterial3D.TEXTURE_CHANNEL_BLUE

static func exemplo_orm() -> ORMMaterial3D:
    # Alternativa ao Standard, para estudar fora da UI; não aplicada automaticamente.
    var m := ORMMaterial3D.new()
    m.orm_texture = mapa_orm()
    m.ao_enabled = true
    m.metallic = 1.0
    m.roughness = 1.0
    return m
