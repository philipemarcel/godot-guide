extends Node3D
const MATERIAIS = preload("res://materiais.gd")
var a: MeshInstance3D
var b: MeshInstance3D
var mat_a: StandardMaterial3D
var mat_b: StandardMaterial3D
var normal: Texture2D
var orm: Texture2D
var luz: DirectionalLight3D
var ambiente: Environment
var painel: VBoxContainer
var leitura: Label
var metallic: HSlider
var roughness: HSlider
var emission: HSlider
var angulo: HSlider
var cor: OptionButton
var compartilhar: CheckButton
var usar_normal: CheckButton
var usar_orm: CheckButton
var luz_direta: CheckButton
var usar_ceu: CheckButton
var timer: Timer
var flash: StandardMaterial3D
var overlay_anterior: Material
var piscando := false

func esfera(nome: String, x: float) -> MeshInstance3D:
    var p := MeshInstance3D.new()
    p.name = nome
    var mesh := SphereMesh.new()
    mesh.radius = 1.0
    mesh.height = 2.0
    p.mesh = mesh
    p.position = Vector3(x,1,0)
    add_child(p)
    return p

func botao(texto: String, acao: Callable) -> void:
    var btn := Button.new()
    btn.text = texto
    btn.pressed.connect(acao)
    painel.add_child(btn)

func deslizador(texto: String, minimo: float, maximo: float, passo: float, valor: float, acao: Callable) -> HSlider:
    var l := Label.new()
    l.text = texto
    painel.add_child(l)
    var s := HSlider.new()
    s.min_value=minimo
    s.max_value=maximo
    s.step=passo
    s.value=valor
    s.value_changed.connect(acao)
    painel.add_child(s)
    return s

func chave(texto: String, valor: bool, acao: Callable) -> CheckButton:
    var c := CheckButton.new()
    c.text=texto
    c.button_pressed=valor
    c.toggled.connect(acao)
    painel.add_child(c)
    return c

func _ready() -> void:
    a=esfera("A_Editavel",-1.5)
    b=esfera("B_Referencia",1.5)
    mat_a=MATERIAIS.base()
    mat_b=MATERIAIS.base()
    a.material_override=mat_a
    b.material_override=mat_b
    normal=MATERIAIS.mapa_normal()
    orm=MATERIAIS.mapa_orm()
    var piso := MeshInstance3D.new()
    var plane := PlaneMesh.new()
    plane.size=Vector2(12,12)
    piso.mesh=plane
    var material_piso := StandardMaterial3D.new()
    material_piso.albedo_color=Color("413526")
    material_piso.roughness=0.9
    piso.material_override=material_piso
    add_child(piso)
    var camera := Camera3D.new()
    camera.position=Vector3(0,3.2,8.5)
    add_child(camera)
    camera.look_at(Vector3(0,1,0),Vector3.UP)
    camera.make_current()
    luz=DirectionalLight3D.new()
    luz.light_energy=3
    luz.rotation_degrees=Vector3(-40,-35,0)
    add_child(luz)
    ambiente=Environment.new()
    ambiente.background_mode=Environment.BG_COLOR
    ambiente.background_color=Color("1d1812")
    var ceu := Sky.new()
    var ceu_mat := ProceduralSkyMaterial.new()
    ceu_mat.sky_top_color=Color("8b9aa9")
    ceu_mat.sky_horizon_color=Color("ddd1b8")
    ceu_mat.ground_bottom_color=Color("3b2c1b")
    ceu.sky_material=ceu_mat
    ambiente.sky=ceu
    ambiente.glow_enabled=false
    definir_ceu(true)
    var world := WorldEnvironment.new()
    world.environment=ambiente
    add_child(world)
    flash=StandardMaterial3D.new()
    flash.shading_mode=BaseMaterial3D.SHADING_MODE_UNSHADED
    flash.transparency=BaseMaterial3D.TRANSPARENCY_ALPHA
    flash.albedo_color=Color(1,0.85,0.35,0.35)
    timer=Timer.new()
    timer.one_shot=true
    timer.wait_time=0.35
    timer.timeout.connect(encerrar_flash)
    add_child(timer)
    var layer := CanvasLayer.new()
    add_child(layer)
    var fundo := PanelContainer.new()
    fundo.position=Vector2(12,12)
    fundo.custom_minimum_size.x=360
    layer.add_child(fundo)
    painel=VBoxContainer.new()
    fundo.add_child(painel)
    leitura=Label.new()
    leitura.custom_minimum_size.x=360
    leitura.autowrap_mode=TextServer.AUTOWRAP_WORD_SMART
    painel.add_child(leitura)
    metallic=deslizador("Metallic de A",0,1,0.05,1,func(v): mat_a.metallic=v)
    roughness=deslizador("Roughness de A",0,1,0.05,0.2,func(v): mat_a.roughness=v)
    emission=deslizador("Emissão ciano de A",0,3,0.25,0,func(v): mat_a.emission_energy_multiplier=v)
    angulo=deslizador("Yaw da luz direta",-75,75,5,-35,func(v): luz.rotation_degrees.y=v)
    cor=OptionButton.new()
    for nome in ["Dourado ilustrativo","Cobre ilustrativo","Revestimento ciano"]:
        cor.add_item(nome)
    cor.item_selected.connect(func(i): mat_a.albedo_color=Color(["d4a359","c86438","5ce1e6"][i]))
    painel.add_child(cor)
    compartilhar=chave("A e B compartilham recurso",false,definir_compartilhamento)
    usar_normal=chave("Normal procedural (não muda silhueta)",false,func(_v): atualizar_mapas())
    usar_orm=chave("Mapa empacotado R/G/B didático",false,func(_v): atualizar_mapas())
    luz_direta=chave("Luz direta",true,func(v): luz.visible=v)
    usar_ceu=chave("Luz ambiente e reflexos do céu",true,definir_ceu)
    botao("Flash em A · F (repete/reinicia0,35s)",piscar)
    botao("Restaurar tudo · R",restaurar)

func atualizar_mapas() -> void:
    MATERIAIS.aplicar_mapas(mat_a,normal,orm,usar_normal.button_pressed,usar_orm.button_pressed)

func definir_ceu(ativo: bool) -> void:
    ambiente.ambient_light_source=Environment.AMBIENT_SOURCE_SKY if ativo else Environment.AMBIENT_SOURCE_DISABLED
    ambiente.reflected_light_source=Environment.REFLECTION_SOURCE_SKY if ativo else Environment.REFLECTION_SOURCE_DISABLED

func definir_compartilhamento(ativo: bool) -> void:
    if ativo:
        mat_b=mat_a
    else:
        mat_a=MATERIAIS.tornar_unico(a)
        mat_b=MATERIAIS.base()
    a.material_override=mat_a
    b.material_override=mat_b

func piscar() -> void:
    if not piscando:
        overlay_anterior=a.material_overlay
    piscando=true
    a.material_overlay=flash
    timer.start() # um único timer; repetição prorroga em vez de criar corridas de awaits

func encerrar_flash() -> void:
    a.material_overlay=overlay_anterior
    overlay_anterior=null
    piscando=false

func restaurar() -> void:
    timer.stop()
    encerrar_flash()
    mat_a=MATERIAIS.base()
    mat_b=MATERIAIS.base()
    a.material_override=mat_a
    b.material_override=mat_b
    metallic.set_value_no_signal(1)
    roughness.set_value_no_signal(0.2)
    emission.set_value_no_signal(0)
    angulo.set_value_no_signal(-35)
    cor.select(0)
    compartilhar.set_pressed_no_signal(false)
    usar_normal.set_pressed_no_signal(false)
    usar_orm.set_pressed_no_signal(false)
    luz_direta.set_pressed_no_signal(true)
    usar_ceu.set_pressed_no_signal(true)
    luz.visible=true
    luz.rotation_degrees.y=-35
    definir_ceu(true)

func _input(event: InputEvent) -> void:
    if event is InputEventKey and event.pressed and not event.echo and event.keycode==KEY_ESCAPE:
        var foco:=get_viewport().gui_get_focus_owner()
        if foco!=null:
            foco.release_focus()
        get_viewport().set_input_as_handled()

func _unhandled_key_input(event: InputEvent) -> void:
    if not event is InputEventKey or not event.pressed or event.echo:
        return
    if event.ctrl_pressed or event.alt_pressed or event.meta_pressed or get_viewport().gui_get_focus_owner()!=null:
        return
    if event.physical_keycode==KEY_F:
        piscar()
    elif event.physical_keycode==KEY_R:
        restaurar()
    else:
        return
    get_viewport().set_input_as_handled()

func _process(_delta: float) -> void:
    leitura.text=("A editável (esquerda) / B referência (direita)\nMesmo recurso: %s | A M%.2f R%.2f E%.2f\nB M%.2f R%.2f E%.2f | flash %s\nEmissão não ilumina piso nesta cena sem GI.\nMapas multiplicam escalares; UVs da esfera.\nSem transparência de vidro ou Glow." % [
        mat_a==mat_b,mat_a.metallic,mat_a.roughness,mat_a.emission_energy_multiplier,
        mat_b.metallic,mat_b.roughness,mat_b.emission_energy_multiplier,piscando])
