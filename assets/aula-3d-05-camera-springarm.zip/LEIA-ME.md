# Camera3D e SpringArm3D
Projeto de apoio da aula 3D5. Extraia todos os arquivos numa pasta e importe project.godot na Godot4.5. O controlador de câmera é camera_rig.gd; oficina.gd cria geometria, hierarquia e UI em runtime. Não há dependências externas nem InputMap.

O alvo fica parado para isolar rotação, projeção e colisão do braço. Movimento do personagem permanece na aula3D4; este projeto não integra os dois controladores. Em FPS a câmera ocupa o pivot, o corpo visual some e o braço não decide sua posição. Uma câmera atual por Viewport.

Comece com parede3, comprimento4,5, FOV75, yaw/pitch0. A câmera orbital olha−Z e o braço estende+Z. M captura; Esc libera; WASD/setas giram por toque, F alterna, R reinicia. Sliders com foco suspendem atalhos até Esc. Não há suavização temporal ou custo de renderização medido.

Forma vazia usa a pirâmide da Camera filha direta; esfera0,25 substitui essa forma. Não garante cobrir todo frustum/near plane. Desligar consulta à parede pode colocar a câmera dentro/atrás dela. Recolher o braço não resolve colisão inicial nem qualquer geometria.

O laboratório web calcula esfera versus plano perpendicular, independente da Godot. Não compare seus números diretamente com get_hit_length. Leia roteiro-testes.md: scripts e cena revisados documentalmente, sem compilação/execução neste ambiente.
