extends Node3D
var rig
var parede: StaticBody3D
var leitura: Label
var controles: VBoxContainer
var distancia: HSlider
var comprimento: HSlider
var fov: HSlider
var mascara: CheckButton
var esfera: CheckButton

func caixa(nome: String, centro: Vector3, tamanho: Vector3, cor: Color) -> StaticBody3D:
    var corpo := StaticBody3D.new()
    corpo.name = nome
    corpo.position = centro
    corpo.collision_layer = 1
    corpo.collision_mask = 0
    var forma := BoxShape3D.new()
    forma.size = tamanho
    var colisao := CollisionShape3D.new()
    colisao.shape = forma
    corpo.add_child(colisao)
    var malha := MeshInstance3D.new()
    var mesh := BoxMesh.new()
    mesh.size = tamanho
    malha.mesh = mesh
    var material := StandardMaterial3D.new()
    material.albedo_color = cor
    malha.material_override = material
    corpo.add_child(malha)
    add_child(corpo)
    return corpo

func botao(texto: String, acao: Callable) -> void:
    var b := Button.new()
    b.text = texto
    b.pressed.connect(acao)
    controles.add_child(b)

func deslizador(texto: String, minimo: float, maximo: float, passo: float, valor: float, acao: Callable) -> HSlider:
    var l := Label.new()
    l.text = texto
    controles.add_child(l)
    var s := HSlider.new()
    s.min_value = minimo
    s.max_value = maximo
    s.step = passo
    s.value = valor
    s.value_changed.connect(acao)
    controles.add_child(s)
    return s

func _ready() -> void:
    caixa("Piso", Vector3(0,-0.15,0), Vector3(20,0.3,20), Color("43301d"))
    parede = caixa("Parede", Vector3(0,2,3.1), Vector3(8,4,0.2), Color("976237"))
    caixa("ReferenciaFrontal", Vector3(0,1,-4), Vector3(1,2,1), Color("39969b"))
    rig = Node3D.new()
    rig.name = "Rig"
    var alvo := StaticBody3D.new()
    alvo.name = "Alvo"
    alvo.collision_layer = 2
    alvo.collision_mask = 0
    var col := CollisionShape3D.new()
    var capsula := CapsuleShape3D.new()
    capsula.radius = 0.3
    capsula.height = 1.8
    col.shape = capsula
    col.position.y = 0.9
    alvo.add_child(col)
    var visual := MeshInstance3D.new()
    visual.name = "Visual"
    var mesh := CapsuleMesh.new()
    mesh.radius = 0.3
    mesh.height = 1.8
    visual.mesh = mesh
    visual.position.y = 0.9
    alvo.add_child(visual)
    rig.add_child(alvo)
    var yaw := Node3D.new()
    yaw.name = "Yaw"
    yaw.position.y = 1.3
    rig.add_child(yaw)
    var pitch := Node3D.new()
    pitch.name = "Pitch"
    yaw.add_child(pitch)
    var braco := SpringArm3D.new()
    braco.name = "Braco"
    pitch.add_child(braco)
    var orbital := Camera3D.new()
    orbital.name = "Orbital"
    orbital.keep_aspect = Camera3D.KEEP_HEIGHT
    braco.add_child(orbital)
    var fps := Camera3D.new()
    fps.name = "FPS"
    fps.keep_aspect = Camera3D.KEEP_HEIGHT
    pitch.add_child(fps)
    rig.set_script(preload("res://camera_rig.gd"))
    add_child(rig)
    var luz := DirectionalLight3D.new()
    luz.rotation_degrees = Vector3(-50,-25,0)
    add_child(luz)
    var ambiente := WorldEnvironment.new()
    ambiente.environment = Environment.new()
    ambiente.environment.background_mode = Environment.BG_COLOR
    ambiente.environment.background_color = Color("211b16")
    ambiente.environment.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
    ambiente.environment.ambient_light_color = Color("d2bd9d")
    ambiente.environment.ambient_light_energy = 0.6
    add_child(ambiente)
    var camada := CanvasLayer.new()
    add_child(camada)
    var painel := PanelContainer.new()
    painel.position = Vector2(12,12)
    painel.custom_minimum_size = Vector2(360,0)
    camada.add_child(painel)
    controles = VBoxContainer.new()
    painel.add_child(controles)
    leitura = Label.new()
    controles.add_child(leitura)
    botao("Capturar mouse · M / Esc libera", rig.capturar)
    botao("Alternar orbital / FPS · F", rig.alternar)
    botao("Yaw +5°", func(): rig.girar(deg_to_rad(5),0))
    botao("Yaw −5°", func(): rig.girar(deg_to_rad(-5),0))
    botao("Pitch +5°", func(): rig.girar(0,deg_to_rad(5)))
    botao("Pitch −5°", func(): rig.girar(0,deg_to_rad(-5)))
    comprimento = deslizador("Comprimento desejado (u)",1,6,0.25,4.5,func(v): rig.braco.spring_length=v)
    distancia = deslizador("Face da parede em +Z (u)",1,7,0.25,3,func(v): parede.position.z=v+0.1)
    fov = deslizador("FOV vertical (graus), KEEP_HEIGHT",45,100,1,75,rig.definir_fov)
    mascara = CheckButton.new()
    mascara.text = "Consultar parede (camada física 1)"
    mascara.button_pressed = true
    mascara.toggled.connect(func(ativo): rig.braco.collision_mask = 3 if ativo else 2)
    controles.add_child(mascara)
    esfera = CheckButton.new()
    esfera.text = "Forma explícita: esfera raio 0,25"
    esfera.toggled.connect(func(ativo):
        if ativo:
            var forma := SphereShape3D.new()
            forma.radius = 0.25
            rig.braco.shape = forma
        else:
            rig.braco.shape = null)
    controles.add_child(esfera)
    botao("Restaurar tudo · R", restaurar_tudo)

func restaurar_tudo() -> void:
    rig.restaurar()
    parede.position.z = 3.1
    comprimento.set_value_no_signal(4.5)
    distancia.set_value_no_signal(3)
    fov.set_value_no_signal(75)
    mascara.set_pressed_no_signal(true)
    esfera.set_pressed_no_signal(false)

func _process(_delta: float) -> void:
    leitura.text = ("BANCADA DE CÂMERA · alvo fixo\n%s | desejado %.2f / hit %.2f u\nFOV vertical %.0f° | yaw %.0f° / pitch %.0f°\nWASD/setas: giro por toque; Esc: foco/mouse" % [
        "FPS (sem braço)" if rig.primeira_pessoa else "Orbital",
        rig.braco.spring_length,rig.braco.get_hit_length(),rig.orbital.fov,
        rig.yaw.rotation_degrees.y,rig.pitch.rotation_degrees.x])
