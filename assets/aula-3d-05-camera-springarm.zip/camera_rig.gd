extends Node3D
## Bancada de câmera, sem controlador de locomoção.
@export var sensibilidade: float = 0.0025 # radianos por pixel da tela
@onready var yaw: Node3D = $Yaw
@onready var pitch: Node3D = $Yaw/Pitch
@onready var braco: SpringArm3D = $Yaw/Pitch/Braco
@onready var orbital: Camera3D = $Yaw/Pitch/Braco/Orbital
@onready var fps: Camera3D = $Yaw/Pitch/FPS
@onready var alvo: StaticBody3D = $Alvo
var primeira_pessoa := false
var modo_anterior: Input.MouseMode

func _ready() -> void:
    modo_anterior = Input.mouse_mode
    braco.add_excluded_object(alvo.get_rid())
    restaurar()

func girar(horizontal: float, vertical: float) -> void:
    yaw.rotation.y = wrapf(yaw.rotation.y + horizontal, -PI, PI)
    # Limite de design configurável, não limite anatômico universal.
    pitch.rotation.x = clampf(pitch.rotation.x + vertical, deg_to_rad(-65), deg_to_rad(65))

func capturar() -> void:
    var foco := get_viewport().gui_get_focus_owner()
    if foco != null:
        foco.release_focus()
    Input.mouse_mode = Input.MOUSE_MODE_CAPTURED

func liberar() -> void:
    Input.mouse_mode = Input.MOUSE_MODE_VISIBLE

func alternar() -> void:
    primeira_pessoa = not primeira_pessoa
    aplicar_modo()

func aplicar_modo() -> void:
    $Alvo/Visual.visible = not primeira_pessoa
    if primeira_pessoa:
        fps.make_current()
    else:
        orbital.make_current()

func definir_fov(valor: float) -> void:
    orbital.fov = valor
    fps.fov = valor

func restaurar() -> void:
    liberar()
    yaw.rotation = Vector3.ZERO
    pitch.rotation = Vector3.ZERO
    braco.spring_length = 4.5
    braco.margin = 0.05
    braco.collision_mask = 3 # paredes/piso: camada 1; alvo: camada 2, excluído por RID
    braco.shape = null # Camera filha direta: pirâmide do near plane
    definir_fov(75)
    primeira_pessoa = false
    aplicar_modo()

func _input(event: InputEvent) -> void:
    if event is InputEventKey and event.pressed and not event.echo and event.keycode == KEY_ESCAPE:
        liberar()
        var foco := get_viewport().gui_get_focus_owner()
        if foco != null:
            foco.release_focus()
        get_viewport().set_input_as_handled()

func _unhandled_input(event: InputEvent) -> void:
    if event is InputEventMouseMotion and Input.mouse_mode == Input.MOUSE_MODE_CAPTURED:
        girar(-event.screen_relative.x * sensibilidade, -event.screen_relative.y * sensibilidade)
        get_viewport().set_input_as_handled()
    if event is InputEventKey and event.pressed and not event.echo:
        if event.ctrl_pressed or event.alt_pressed or event.meta_pressed:
            return
        # Com UI em foco, suas teclas não comandam a bancada.
        if get_viewport().gui_get_focus_owner() != null:
            return
        var passo := deg_to_rad(5)
        match event.physical_keycode:
            KEY_A, KEY_LEFT: girar(passo, 0)
            KEY_D, KEY_RIGHT: girar(-passo, 0)
            KEY_W, KEY_UP: girar(0, passo)
            KEY_S, KEY_DOWN: girar(0, -passo)
            KEY_F: alternar()
            KEY_M: capturar()
            KEY_R: get_parent().restaurar_tudo()
            _: return
        get_viewport().set_input_as_handled()

func _notification(what: int) -> void:
    if what == NOTIFICATION_APPLICATION_FOCUS_OUT:
        liberar()

func _exit_tree() -> void:
    Input.mouse_mode = modo_anterior
