extends SceneTree
func _initialize() -> void:
    call_deferred("conferir")
func conferir() -> void:
    var s = load("res://som.gd").new()
    root.add_child(s)
    assert(s.aplicar("SFX", 0.0))
    assert(AudioServer.is_bus_mute(AudioServer.get_bus_index("SFX")))
    assert(not s.aplicar("SFX", NAN))
    s.queue_free()
    await process_frame
    print("Áudio: zero e validação aprovados")
    quit()
