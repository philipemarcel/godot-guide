extends Node

const ARQUIVO := "user://aether_audio.cfg"
var volumes: Dictionary = {"Master": 0.6, "Music": 0.4, "SFX": 0.6}
var mudo: bool = false
var efeito: AudioStreamPlayer
var musica: AudioStreamPlayer
var disparos: int = 0

func _ready() -> void:
    for nome in ["Music", "SFX"]:
        if AudioServer.get_bus_index(nome) == -1:
            AudioServer.add_bus()
            AudioServer.set_bus_name(AudioServer.bus_count - 1, nome)
        AudioServer.set_bus_send(AudioServer.get_bus_index(nome), "Master")
    efeito = AudioStreamPlayer.new()
    efeito.bus = &"SFX"
    efeito.stream = load("res://sons/acao.wav")
    add_child(efeito)
    musica = AudioStreamPlayer.new()
    musica.bus = &"Music"
    musica.stream = load("res://sons/musica.wav")
    add_child(musica)
    carregar()

func aplicar(nome: String, linear: float) -> bool:
    if not volumes.has(nome) or not is_finite(linear):
        return false
    volumes[nome] = clampf(linear, 0.0, 1.0)
    var indice := AudioServer.get_bus_index(nome)
    AudioServer.set_bus_volume_db(indice, linear_to_db(maxf(volumes[nome], 0.0001)))
    AudioServer.set_bus_mute(indice, volumes[nome] == 0.0 or (nome == "Master" and mudo))
    return true

func silenciar(valor: bool) -> void:
    mudo = valor
    aplicar("Master", volumes["Master"])

func tocar_acao() -> void:
    disparos += 1
    efeito.play() # Uma chamada reinicia este único player, sem empilhar nós.

func alternar_musica() -> void:
    if musica.playing:
        musica.stop()
    else:
        musica.play()

func salvar(caminho: String = ARQUIVO) -> Error:
    var cfg := ConfigFile.new()
    for nome in volumes:
        cfg.set_value("audio", nome, volumes[nome])
    cfg.set_value("audio", "mudo", mudo)
    return cfg.save(caminho)

func carregar(caminho: String = ARQUIVO) -> Error:
    var cfg := ConfigFile.new()
    var erro := cfg.load(caminho)
    var padroes := {"Master": 0.6, "Music": 0.4, "SFX": 0.6}
    for nome in padroes:
        var valor: Variant = cfg.get_value("audio", nome, padroes[nome]) if erro == OK else padroes[nome]
        if not (valor is int or valor is float) or not is_finite(float(valor)) or float(valor) < 0.0 or float(valor) > 1.0:
            valor = padroes[nome]
        aplicar(nome, float(valor))
    var valor_mudo: Variant = cfg.get_value("audio", "mudo", false) if erro == OK else false
    silenciar(valor_mudo if valor_mudo is bool else false)
    return erro
