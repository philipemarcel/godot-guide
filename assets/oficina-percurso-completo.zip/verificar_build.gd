extends RefCounted
# Diagnóstico opcional da distribuição: executa os mesmos botões e encerra.
var total:=0
var falhas:=0
func conferir(ok: bool,descricao: String) -> void:
    total+=1
    print(("PASS: " if ok else "FAIL: ")+descricao)
    if not ok:falhas+=1
func clicar(ui: Control,titulo: String) -> void:
    for botao in ui.corpo.find_children("*","Button",true,false):
        if botao.text==titulo:
            botao.pressed.emit()
            return
    conferir(false,"Botão não encontrado: "+titulo)
func executar(ui: Control) -> void:
    var arvore:=ui.get_tree()
    await arvore.process_frame
    conferir(not OS.has_feature("editor"),"Runtime exportado, sem editor")
    conferir(ui.partida.fase=="menu","Início")
    ui.controles.restaurar()
    ui.mostrar(4)
    clicar(ui,"Iniciar / reiniciar partida")
    await arvore.process_frame
    await arvore.process_frame
    ui.foco_jogo.grab_focus()
    for pressionada in [true,false]:
        var tecla:=InputEventKey.new()
        tecla.physical_keycode=KEY_D
        tecla.keycode=KEY_D
        tecla.pressed=pressionada
        arvore.root.push_input(tecla,true)
    conferir(ui.partida.posicao==1,"Teclado da build")
    var atalho:=InputEventKey.new()
    atalho.keycode=KEY_D;atalho.physical_keycode=KEY_D;atalho.ctrl_pressed=true;atalho.pressed=true
    arvore.root.push_input(atalho,true)
    atalho.pressed=false;arvore.root.push_input(atalho,true)
    atalho=null
    conferir(ui.partida.posicao==1,"Atalho com Ctrl não move na build")
    clicar(ui,"Pausar / retomar")
    clicar(ui,"→ Direita")
    conferir(ui.partida.pausada and ui.partida.posicao==1,"Pausa bloqueia")
    clicar(ui,"Pausar / retomar")
    conferir(ui.partida.salvar("user://qa-build-partida.cfg")==OK,"Save real da build")
    clicar(ui,"Iniciar / reiniciar partida")
    conferir(ui.partida.carregar("user://qa-build-partida.cfg")==OK and ui.partida.posicao==1,"Load real da build")
    ui.mostrar(2)
    ui.som.silenciar(true)
    clicar(ui,"Tocar ação · SFX")
    conferir(ui.som.disparos>0 and ui.aviso.text.contains("AÇÃO"),"Áudio tem confirmação visual no mute")
    conferir(ui.som.salvar("user://qa-build-audio.cfg")==OK,"Áudio salva na build")
    ui.som.silenciar(false)
    ui.som.carregar("user://qa-build-audio.cfg")
    conferir(ui.som.mudo,"Ajuste restaurado na build")
    ui.mostrar(3)
    conferir(ui.controles.remapear("of_esquerda",KEY_J)=="Mapeamento aplicado","Remapeamento na build")
    conferir(ui.controles.salvar("user://qa-build-controles.cfg")==OK,"Controles salvos")
    ui.controles.restaurar()
    ui.controles.carregar("user://qa-build-controles.cfg")
    conferir(ui.controles.teclas.of_esquerda==KEY_J,"Controles restaurados")
    ui.mostrar(4)
    clicar(ui,"Iniciar / reiniciar partida")
    for titulo in ["↓ Baixo","↓ Baixo","↑ Cima","↑ Cima","→ Direita","→ Direita","→ Direita","→ Direita","→ Direita","↓ Baixo","↓ Baixo","↓ Baixo","← Esquerda","→ Direita"]:clicar(ui,titulo)
    conferir(ui.partida.fase=="vitoria" and ui.partida.passos==14,"Vitória pelo ciclo da build")
    await arvore.process_frame
    await RenderingServer.frame_post_draw
    var args:=OS.get_cmdline_user_args()
    var indice:=args.find("--verificar-build")
    if args.size()>indice+1:
        var imagem:=arvore.root.get_texture().get_image()
        conferir(imagem.save_png(args[indice+1].path_join("lacunas-build-vitoria.png"))==OK,"Imagem do executável exportado")
    clicar(ui,"Iniciar / reiniciar partida")
    for i in range(16):clicar(ui,"→ Direita");clicar(ui,"← Esquerda")
    conferir(ui.partida.fase=="derrota","Derrota na build")
    clicar(ui,"Iniciar / reiniciar partida")
    conferir(ui.partida.fase=="jogando" and ui.partida.passos==0,"Reinício na build")
    clicar(ui,"Voltar ao início")
    conferir(ui.partida.fase=="menu","Retorno ao início")
    # Permitir que remoções adiadas e callbacks de foco terminem antes do shutdown.
    await arvore.process_frame
    await arvore.process_frame
    print("BUILD: %d conferências; %d falhas; %s" % [total,falhas,Engine.get_version_info().string])
    arvore.quit(0 if falhas==0 else 1)
