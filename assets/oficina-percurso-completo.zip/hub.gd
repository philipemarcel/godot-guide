extends Control

const Estoque = preload("res://estoque.gd")
const Contador = preload("res://contador.gd")
const Som = preload("res://som.gd")
const Controles = preload("res://controles.gd")
const Partida = preload("res://partida.gd")
var estoque := Estoque.new()
var contador := Contador.new()
var som := Som.new()
var controles := Controles.new()
var partida := Partida.new()
var corpo: VBoxContainer
var aviso: Label
var menu: HFlowContainer
var tabuleiro: GridContainer
var pagina: int = 0
var capturador: Button
var foco_jogo: Button
var pulso: Tween
var diagnostico: RefCounted
var revisao_pagina: int = 0

func _ready() -> void:
    process_mode = Node.PROCESS_MODE_ALWAYS
    som.name = "Som"
    controles.name = "Controles"
    add_child(som)
    add_child(controles)
    var tema := Theme.new()
    tema.default_font_size = 18
    var foco := StyleBoxFlat.new()
    foco.bg_color = Color(0, 0, 0, 0)
    foco.border_color = Color("f4d088")
    foco.set_border_width_all(3)
    tema.set_stylebox("focus", "Button", foco)
    theme = tema
    var rolagem := ScrollContainer.new()
    rolagem.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    add_child(rolagem)
    var margem := MarginContainer.new()
    margem.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    for lado in ["left", "right", "top", "bottom"]:
        margem.add_theme_constant_override("margin_" + lado, 20)
    rolagem.add_child(margem)
    var coluna := VBoxContainer.new()
    coluna.add_theme_constant_override("separation", 12)
    margem.add_child(coluna)
    texto(coluna, "OFICINA AETHER · percurso completo", 26)
    menu = HFlowContainer.new()
    coluna.add_child(menu)
    var nomes := ["1 · Dados", "2 · Depuração", "3 · Áudio", "4 · Controles", "5 · Jogo"]
    for i in range(nomes.size()):
        botao(menu, nomes[i], mostrar.bind(i))
    aviso = texto(coluna, "Escolha uma oficina. Tab navega; Enter ativa.")
    aviso.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
    corpo = VBoxContainer.new()
    corpo.add_theme_constant_override("separation", 10)
    coluna.add_child(corpo)
    mostrar(0)
    if "--verificar-build" in OS.get_cmdline_user_args():
        diagnostico = load("res://verificar_build.gd").new()
        diagnostico.executar.call_deferred(self)

func texto(pai: Node, valor: String, tamanho: int = 0) -> Label:
    var label := Label.new()
    label.text = valor
    if tamanho > 0:label.add_theme_font_size_override("font_size", tamanho)
    pai.add_child(label)
    return label

func botao(pai: Node, titulo: String, acao: Callable) -> Button:
    var b := Button.new()
    b.text = titulo
    b.custom_minimum_size.y = 42
    b.pressed.connect(acao)
    pai.add_child(b)
    return b

func informar(mensagem: String) -> void:
    aviso.text = mensagem
    if pulso and pulso.is_valid():
        pulso.kill()
    aviso.modulate = Color.WHITE
    if not controles.movimento_reduzido:
        aviso.modulate = Color("f4d088")
        pulso = create_tween()
        pulso.tween_property(aviso, "modulate", Color.WHITE, 0.2)

func mostrar(indice: int) -> void:
    revisao_pagina += 1
    controles.capturando = ""
    for acao in controles.teclas:
        Input.action_release(acao)
    pagina = indice
    for filho in corpo.get_children():
        corpo.remove_child(filho)
        filho.queue_free()
    theme.default_font_size = 22 if controles.texto_grande else 18
    if indice == 0:
        var lista := texto(corpo, "Saldos atuais: " + str(estoque.saldos))
        var ids := OptionButton.new()
        for id in ["engrenagem", "valvula", "mola", "inexistente"]:
            ids.add_item(id)
        corpo.add_child(ids)
        var qtd := SpinBox.new()
        qtd.min_value = -1
        qtd.max_value = 5
        qtd.value = 1
        corpo.add_child(qtd)
        botao(corpo, "Consumir peça", func():
            var resultado := estoque.consumir(ids.get_item_text(ids.selected), int(qtd.value))
            lista.text = "Saldos atuais: " + str(estoque.saldos)
            if resultado.ok:
                informar("Peça consumida · saldo %d" % resultado.saldo)
            else:
                informar("Operação rejeitada: " + resultado.motivo))
        botao(corpo, "Restaurar estoque", func():estoque = Estoque.new();mostrar(0))
    elif indice == 1:
        texto(corpo, "Um clique deveria somar 1. Defeito intencional: soma 2.")
        botao(corpo, "Acionar contador", func():informar("Total: %d · defeito ativo: %s" % [contador.acionar(), contador.defeito_ativo]))
        botao(corpo, "Aplicar correção e zerar", func():contador.corrigir();informar("Corrigido. Clique duas vezes: espere 1, depois 2."))
        botao(corpo, "Reproduzir defeito novamente", func():contador = Contador.new();informar("Defeito intencional restaurado."))
    elif indice == 2:
        texto(corpo, "Sem reprodução automática. Sons sintetizados próprios incluídos.")
        botao(corpo, "Tocar ação · SFX", func():som.tocar_acao();informar("AÇÃO confirmada · disparos: %d" % som.disparos))
        botao(corpo, "Iniciar/parar música", som.alternar_musica)
        for nome in som.volumes:
            var linha := HBoxContainer.new()
            corpo.add_child(linha)
            var valor := texto(linha, "%s: %.0f%%" % [nome, som.volumes[nome] * 100])
            valor.custom_minimum_size.x = 160
            var slider := HSlider.new()
            slider.max_value = 1.0
            slider.step = 0.01
            slider.value = som.volumes[nome]
            slider.size_flags_horizontal = Control.SIZE_EXPAND_FILL
            linha.add_child(slider)
            slider.value_changed.connect(func(v: float):som.aplicar(nome, v);valor.text = "%s: %.0f%%" % [nome, v * 100])
        var mute := CheckButton.new()
        mute.text = "Silenciar Master"
        mute.button_pressed = som.mudo
        mute.toggled.connect(som.silenciar)
        corpo.add_child(mute)
        botao(corpo, "Salvar áudio", func():informar("Salvar áudio: " + error_string(som.salvar())))
        botao(corpo, "Recarregar áudio", func():informar("Carregar áudio: " + error_string(som.carregar()));mostrar(2))
    elif indice == 3:
        texto(corpo, "Escolha uma ação e pressione letra/seta. Escape cancela; conflitos são rejeitados.")
        for acao in controles.teclas:
            var b := botao(corpo, acao + ": " + OS.get_keycode_string(controles.teclas[acao]), iniciar_captura.bind(acao))
            b.name = acao
        var reduzido := CheckButton.new()
        reduzido.text = "Movimento reduzido · sem pulso de confirmação"
        reduzido.button_pressed = controles.movimento_reduzido
        reduzido.toggled.connect(func(v: bool):controles.movimento_reduzido = v;informar("Preferência aplicada"))
        corpo.add_child(reduzido)
        var grande := CheckButton.new()
        grande.text = "Texto ampliado"
        grande.button_pressed = controles.texto_grande
        grande.toggled.connect(func(v: bool):controles.texto_grande = v;mostrar(3))
        corpo.add_child(grande)
        botao(corpo, "Salvar controles", func():informar("Salvar controles: " + error_string(controles.salvar())))
        botao(corpo, "Restaurar e salvar padrões", func():controles.restaurar();informar("Padrões: " + error_string(controles.salvar()));mostrar(3))
    else:
        texto(corpo, "Recolha as 3 peças e chegue à saída em até 32 passos. # bloqueia; P marca peças.")
        texto(corpo, "Teclado: foque o tabuleiro. WASD padrão ou teclas remapeadas; Escape pausa.")
        botao(corpo, "Iniciar / reiniciar partida", func():partida.iniciar();informar("Nova partida");mostrar(4))
        foco_jogo = botao(corpo, "Focar tabuleiro · mover pelo teclado", func():foco_jogo.grab_focus())
        foco_jogo.gui_input.connect(entrada_jogo)
        tabuleiro = GridContainer.new()
        tabuleiro.columns = 6
        corpo.add_child(tabuleiro)
        var linha := HFlowContainer.new()
        corpo.add_child(linha)
        botao(linha, "← Esquerda", mover.bind(-1, 0))
        botao(linha, "↑ Cima", mover.bind(0, -1))
        botao(linha, "↓ Baixo", mover.bind(0, 1))
        botao(linha, "→ Direita", mover.bind(1, 0))
        botao(corpo, "Pausar / retomar", pausar)
        botao(corpo, "Salvar partida", func():informar("Salvar: " + error_string(partida.salvar())))
        botao(corpo, "Carregar partida", func():informar("Carregar: " + error_string(partida.carregar()));atualizar_tabuleiro())
        botao(corpo, "Voltar ao início", func():partida.fase = "menu";partida.pausada = false;atualizar_tabuleiro();informar("Início. Use Iniciar para jogar ou Carregar para continuar."))
        atualizar_tabuleiro()
    # A reconstrução nunca deixa o foco preso em um controle removido.
    focar_primeiro.call_deferred(revisao_pagina)

func focar_primeiro(revisao: int) -> void:
    if revisao != revisao_pagina or not is_inside_tree():
        return
    var primeiro := corpo.find_children("*", "Button", true, false)
    if not primeiro.is_empty() and primeiro[0].is_inside_tree():
        (primeiro[0] as Button).grab_focus()

func iniciar_captura(acao: String) -> void:
    controles.capturando = acao
    capturador = corpo.get_node(acao)
    informar("Pressione uma letra/seta para " + acao + "; Escape cancela.")

func _input(evento: InputEvent) -> void:
    if controles.capturando.is_empty() or not evento is InputEventKey or not evento.pressed or evento.echo:
        return
    get_viewport().set_input_as_handled()
    if evento.keycode == KEY_ESCAPE:
        controles.capturando = ""
        informar("Captura cancelada; mapeamento preservado.")
    elif evento.ctrl_pressed or evento.alt_pressed or evento.meta_pressed or evento.shift_pressed:
        informar("Use uma tecla sem modificadores; Escape cancela.")
    else:
        var codigo: int = evento.physical_keycode if evento.physical_keycode != 0 else evento.keycode
        var acao := controles.capturando
        if not controles.codigo_valido(codigo):
            informar("Tecla reservada. Use letra/seta; Escape cancela.")
            return
        informar(controles.remapear(acao, codigo))
        controles.capturando = ""
        capturador.text = acao + ": " + OS.get_keycode_string(controles.teclas[acao])
    if controles.capturando.is_empty():capturador.grab_focus()

func entrada_jogo(evento: InputEvent) -> void:
    if not evento is InputEventKey or not evento.pressed or evento.echo:
        return
    if evento.ctrl_pressed or evento.alt_pressed or evento.meta_pressed or evento.shift_pressed:
        return
    if evento.keycode == KEY_ESCAPE:
        pausar()
        foco_jogo.accept_event()
        return
    var direcoes := {"of_esquerda": Vector2i.LEFT, "of_direita": Vector2i.RIGHT, "of_cima": Vector2i.UP, "of_baixo": Vector2i.DOWN}
    for acao in direcoes:
        if InputMap.event_is_action(evento, acao):
            var direcao: Vector2i = direcoes[acao]
            mover(direcao.x, direcao.y)
            foco_jogo.accept_event()
            return

func mover(dx: int, dy: int) -> void:
    var antes := partida.coletadas.size()
    informar(partida.mover(dx, dy))
    if partida.coletadas.size() > antes:
        som.tocar_acao()
    atualizar_tabuleiro()

func pausar() -> void:
    if partida.fase == "jogando":
        partida.pausada = not partida.pausada
    informar("Pausada" if partida.pausada else "Retomada")
    atualizar_tabuleiro()

func atualizar_tabuleiro() -> void:
    if pagina != 4 or not is_instance_valid(tabuleiro) or not tabuleiro.is_inside_tree():
        return
    for filho in tabuleiro.get_children():
        tabuleiro.remove_child(filho)
        filho.queue_free()
    for i in range(24):
        var simbolo := "#" if i in partida.PAREDES else "P" if i in partida.PECAS and not i in partida.coletadas else "SAÍDA" if i == 23 else "·"
        var celula := texto(tabuleiro, "[%s]" % ("VOCÊ" if i == partida.posicao else simbolo))
        celula.custom_minimum_size = Vector2(90, 36)
    foco_jogo.text = "Tabuleiro · %s%s · peças %d/3 · passos %d/32" % [partida.fase, " · PAUSA" if partida.pausada else "", partida.coletadas.size(), partida.passos]

func _notification(what: int) -> void:
    if what == NOTIFICATION_APPLICATION_FOCUS_OUT:
        controles.capturando = ""
        if partida.fase == "jogando":partida.pausada = true
        for acao in controles.teclas:Input.action_release(acao)
        if pagina == 4 and is_instance_valid(tabuleiro):
            atualizar_tabuleiro.call_deferred()
