# Academia Aether — percurso completo

Projeto-fonte para os complementos 3A, 5A, 13A, 13B e projeto 18. Godot 4.5+ Compatibility; execução desta implementação conferida na 4.7.2.stable.steam.ed1daf0bf. Sem plugins externos. Abra project.godot, importe os WAVs, abra oficina.tscn e use F6; F5 usa a mesma cena principal.

## As cinco oficinas

1. **Dados:** estoque.gd é RefCounted. hub.gd possui o objeto e apresenta o retorno. Tente consumir uma engrenagem, ID inexistente, zero e quantidade maior que o saldo. Instâncias diferentes mantêm saldos independentes.
2. **Depuração:** contador.gd contém uma falha intencional (+2). Marque breakpoint na segunda soma, observe total mudar de 1 para 2 e continue a execução. A correção didática desliga essa soma e zera. Não copie a chave de defeito para o jogo final. testar_antes.gd retorna código 1 por contrato quebrado; testar.gd reproduz antes e verifica depois.
3. **Áudio:** som.gd cria buses Music/SFX enviados a Master e dois players. Sem autoplay. Arquivos WAV sintetizados próprios, com licença em sons/LICENCA.txt. Música usa loop forward no import; efeito não repete. Ação tem confirmação visual. Salvar áudio escreve user://aether_audio.cfg; sliders alteram a sessão antes de salvar.
4. **Controles:** controles.gd mapeia ações of_* por physical_keycode. Captura aceita A–Z/setas; Escape cancela. Tab/Enter/Space e modificadores são recusados sem encerrar a espera; fora da captura, navegam o menu normalmente. Conflitos são rejeitados e encerram a tentativa com o mapa preservado. Foco volta ao botão. Texto ampliado e movimento reduzido são aplicados e salvos em user://aether_controles.cfg. Movimento reduzido desliga o pulso de cor da confirmação. Não inclui controle de jogo.
5. **Jogo:** partida.gd mantém o ciclo, hub.gd apresenta. Menu → jogando → vitória/derrota → reinício. Foque o botão Tabuleiro para WASD/remapeado, sem Ctrl/Alt/Shift/Meta; Tab sai e Escape pausa. Botões oferecem os mesmos passos. A perda de foco da janela pausa e libera ações; retome explicitamente. Salvar/carregar usa user://aether_partida.cfg. Arquivo inválido preserva a sessão corrente. Save validado não é sistema antifraude.

Rota de vitória a partir do início: baixo×2, cima×2, direita×5, baixo×3, esquerda, direita. Resultado: três peças, 14 passos, vitória. Alternar direita/esquerda 16 vezes causa derrota no passo32. Paredes 8/9/15 bloqueiam sem gastar passos. Células numeradas em linhas de seis; peças2/12/22, saída23.

## Repetir testes

Na pasta do projeto, substitua godot pelo caminho do executável, se necessário. Rode cada linha separadamente:

```
godot --headless --editor --import --path .
godot --headless --path . --audio-driver Dummy --script res://testar_antes.gd
godot --headless --path . --audio-driver Dummy --script res://testar.gd
```

A segunda linha falha intencionalmente (exit1); a terceira deve terminar com zero falhas (exit0). Os arquivos *-conferencia.gd são os testes curtos de cada aula, executados com --script do mesmo modo. O teste de interface é testar_render.gd; exige renderização disponível e pasta de saída existente:

```
godot --path . --script res://testar_render.gd --fixed-fps 60 --windowed --resolution 960x900 --audio-driver Dummy -- C:/caminho/absoluto/saidas
```

Dummy confirma estado/recursos/roteamento, não audição. Os testes gráficos usam eventos sintéticos no viewport; mouse/teclado físicos, volume/clipping, debugger por interface e validação com alunos exigem conferência manual. Não confunda estes testes com homologação de todo o curso.

## Exercício Git em uma cópia

Git precisa estar instalado. Extraia outra cópia do ZIP para praticar e revise a pasta antes de inicializar. Comandos independentes, nessa pasta:

```
git init
git status
git add .
git diff --cached
git commit -m "Base da oficina"
```

Se faltar identidade, configure user.name/user.email localmente com seus próprios dados, sem --global. .gitignore exclui .godot, traduções geradas e build. Versione scripts, cenas, sons e metadados .uid; não remova .uid de propósito. .gitattributes mantém LF. Ajustes user:// ficam fora do projeto.

Edite só exercicio.txt, veja a diferença e depois descarte apenas essa edição de ensaio:

```
git diff -- exercicio.txt
git restore --source=HEAD -- exercicio.txt
git status
```

restore substitui o arquivo pela versão do commit e perde sua alteração não commitada. Faça cópia do texto se quiser guardá-lo; não execute sobre outros arquivos do seu trabalho. Depois corrija o defeito real, repita os testes, revise diff e crie outro commit. Nenhum comando configura remoto ou publica dados.

## Exportação local Windows x86_64

O preset export_presets.cfg está incluído. A versão 1.1.0 foi exportada com os templates oficiais 4.7.2 já instalados pelo Steam. Uma cópia da pasta da build Windows foi executada fora do editor, com 18 verificações do ciclo e zero falhas. A audição e os dispositivos físicos continuam exigindo conferência. Para repetir em sua máquina, siga a prática e registre seu resultado:

1. Confira a versão do editor. Instale os export templates correspondentes via Editor > Manage Export Templates.
2. Em Project > Export, confira Windows Desktop, x86_64, Compatibility e cena principal oficina.tscn.
3. Crie build/. Exporte release para build/OficinaAether.exe; preserve o .pck externo ao lado. Opcional CLI: `godot --headless --path . --export-release "Windows Desktop" build/OficinaAether.exe`.
4. Feche o editor e abra o executável. Repita a rota de vitória, derrota, pausa, ajustes, reabertura, save/load e reinício. Teste uma cópia da pasta completa num diretório limpo.
5. Registre versão, sistema, resolução, áudio, controles e erros conhecidos. Inclua sons/LICENCA.txt, versão do jogo e instruções na distribuição; não inclua .godot, credenciais ou dados pessoais de user://.

Não chame um ZIP de fontes ou um PCK rodado pelo editor de build release comprovada. Publicação externa, assinatura e outros destinos não fazem parte desta prática local. Adaptação 3D é uma extensão: mantenha os serviços/ciclo e substitua a grade por CharacterBody3D/câmera/colisão; valide posição de reaparecimento, renderizador e exportação novamente.

A distribuição possui diagnóstico opcional: `OficinaAether.exe --audio-driver Dummy -- --verificar-build C:/pasta/de/saidas`. A pasta deve existir. O diagnóstico aciona a interface, percorre início/jogo/pausa/ajustes/save/load/vitória/derrota/reinício e encerra; arquivos qa-build-*.cfg são separados dos saves normais. O código de diagnóstico usa verificações explícitas, pois assert pode ser removido em release. Sem esse argumento, a aplicação funciona normalmente.
