extends RefCounted

# Defeito intencional da oficina de depuração. Não usar no jogo final.
var defeito_ativo: bool = true
var total: int = 0

func acionar() -> int:
    total += 1
    if defeito_ativo:
        total += 1 # Coloque um breakpoint aqui e observe total.
    return total

func corrigir() -> void:
    defeito_ativo = false
    total = 0
