extends SceneTree
func _initialize() -> void:
    call_deferred("conferir")
func conferir() -> void:
    var k = load("res://controles.gd").new()
    root.add_child(k)
    k.restaurar()
    assert(k.remapear("of_esquerda", KEY_J) == "Mapeamento aplicado")
    assert(k.remapear("of_direita", KEY_J).begins_with("Conflito"))
    assert(k.teclas.of_direita == KEY_D)
    k.queue_free()
    await process_frame
    print("Controles: conflito preserva estado")
    quit()
