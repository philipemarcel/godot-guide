extends RefCounted

const ARQUIVO := "user://aether_partida.cfg"
const PECAS := [2, 12, 22]
const PAREDES := [8, 9, 15]
var fase: String = "menu"
var posicao: int = 0
var passos: int = 0
var coletadas: Array[int] = []
var pausada: bool = false

func iniciar() -> void:
    fase = "jogando"
    posicao = 0
    passos = 0
    coletadas.clear()
    pausada = false

func mover(dx: int, dy: int) -> String:
    if fase != "jogando" or pausada:
        return "Movimento bloqueado"
    if absi(dx) + absi(dy) != 1:
        return "Um passo ortogonal por ação"
    var x := posicao % 6 + dx
    var y := posicao / 6 + dy
    if x < 0 or x >= 6 or y < 0 or y >= 4 or y * 6 + x in PAREDES:
        return "Parede ou limite: nenhum passo gasto"
    posicao = y * 6 + x
    passos += 1
    if posicao in PECAS and not posicao in coletadas:
        coletadas.append(posicao)
    if posicao == 23 and coletadas.size() == 3:
        fase = "vitoria"
    elif passos >= 32:
        fase = "derrota"
    return "Peças %d/3 · passos %d/32 · %s" % [coletadas.size(), passos, fase]

func salvar(caminho: String = ARQUIVO) -> Error:
    if fase != "jogando":
        return ERR_UNAVAILABLE
    var cfg := ConfigFile.new()
    cfg.set_value("partida", "versao", 1)
    cfg.set_value("partida", "posicao", posicao)
    cfg.set_value("partida", "passos", passos)
    cfg.set_value("partida", "coletadas", coletadas)
    return cfg.save(caminho)

func carregar(caminho: String = ARQUIVO) -> Error:
    var cfg := ConfigFile.new()
    var erro := cfg.load(caminho)
    if erro != OK:
        return erro
    for chave in ["versao", "posicao", "passos", "coletadas"]:
        if not cfg.has_section_key("partida", chave):
            return ERR_INVALID_DATA
    var versao: Variant = cfg.get_value("partida", "versao", null)
    var p: Variant = cfg.get_value("partida", "posicao", null)
    var n: Variant = cfg.get_value("partida", "passos", null)
    var lista: Variant = cfg.get_value("partida", "coletadas", null)
    if not versao is int or versao != 1 or not p is int or not n is int or not lista is Array:
        return ERR_INVALID_DATA
    if p < 0 or p >= 24 or p in PAREDES or n < 0 or n >= 32:
        return ERR_INVALID_DATA
    var copia: Array[int] = []
    for item in lista:
        if not item is int or not item in PECAS or item in copia:
            return ERR_INVALID_DATA
        copia.append(item)
    if copia.size() > n or (p in PECAS and not p in copia) or (p == 23 and copia.size() == 3):
        return ERR_INVALID_DATA
    # Commit só depois de validar todos os campos: falha preserva a sessão.
    posicao = p
    passos = n
    coletadas = copia
    fase = "jogando"
    pausada = false
    return OK
