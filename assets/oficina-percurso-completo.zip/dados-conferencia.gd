extends SceneTree
func _initialize() -> void:
    call_deferred("conferir")
func conferir() -> void:
    var e = load("res://estoque.gd").new()
    assert(e.consumir("engrenagem", 1).saldo == 2)
    assert(not e.consumir("engrenagem", 0).ok)
    assert(not e.consumir("inexistente", 1).ok)
    var outro = load("res://estoque.gd").new()
    assert(outro.saldos.engrenagem == 3)
    print("Dados: conferência aprovada")
    quit()
