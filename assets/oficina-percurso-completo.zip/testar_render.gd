extends SceneTree
var total:=0
var falhas:=0
var saida:=""
func _initialize() -> void:call_deferred("executar")
func check(ok: bool,text: String) -> void:
    total+=1
    if not ok:falhas+=1
    print(("PASS: " if ok else "FAIL: ")+text)
func frames(n: int) -> void:
    for i in range(n):await process_frame
func tecla(codigo: int,ctrl: bool=false) -> void:
    for estado in [true,false]:
        var evento:=InputEventKey.new()
        evento.keycode=codigo
        evento.physical_keycode=codigo
        evento.pressed=estado
        evento.ctrl_pressed=ctrl
        root.push_input(evento,true)
    await frames(2)
func executar() -> void:
    saida=OS.get_cmdline_user_args()[0]
    var cena: PackedScene=load("res://oficina.tscn")
    var ui:=cena.instantiate()
    root.add_child(ui)
    await frames(3)
    for i in range(5):
        ui.mostrar(i)
        await frames(3)
        await RenderingServer.frame_post_draw
        var img:=root.get_texture().get_image()
        check(img.get_size()==Vector2i(960,900),"Viewport nativo960x900")
        check(img.save_png(saida.path_join("lacunas-oficina%d.png" % (i+1)))==OK,"Captura página%d" % i)
        var botoes: Array[Node]=ui.corpo.find_children("*","Button",true,false)
        check(not botoes.is_empty(),"Controles interativos presentes")
    ui.mostrar(3)
    await frames(3)
    ui.iniciar_captura("of_esquerda")
    await tecla(KEY_ENTER)
    check(ui.controles.capturando=="of_esquerda","Tecla reservada preserva captura e mapeamento")
    await tecla(KEY_ESCAPE)
    ui.iniciar_captura("of_esquerda")
    await tecla(KEY_J)
    check(ui.controles.teclas.of_esquerda==KEY_J and ui.controles.capturando.is_empty(),"Captura real pelo viewport")
    ui.iniciar_captura("of_direita")
    await tecla(KEY_J)
    check(ui.controles.teclas.of_direita==KEY_D,"Conflito não altera mapa")
    ui.iniciar_captura("of_esquerda")
    await tecla(KEY_ESCAPE)
    check(ui.controles.capturando.is_empty() and ui.controles.teclas.of_esquerda==KEY_J,"Escape cancela")
    check(root.gui_get_focus_owner()==ui.capturador,"Foco retornou ao botão")
    ui.controles.texto_grande=true
    ui.controles.movimento_reduzido=true
    ui.mostrar(4)
    ui.partida.iniciar()
    await frames(3)
    ui.foco_jogo.grab_focus()
    await frames(1)
    await tecla(KEY_D)
    check(ui.partida.posicao==1,"GUI move com tecla padrão")
    await tecla(KEY_J)
    check(ui.partida.posicao==0,"GUI usa tecla remapeada")
    await tecla(KEY_D,true)
    check(ui.partida.posicao==0,"Ctrl+D não é passo de jogo")
    ui.partida.iniciar()
    ui.controles.remapear("of_esquerda",KEY_LEFT)
    await tecla(KEY_D)
    await tecla(KEY_LEFT)
    check(ui.partida.posicao==0 and root.gui_get_focus_owner()==ui.foco_jogo,"Seta remapeada move e preserva foco")
    await tecla(KEY_ESCAPE)
    await tecla(KEY_D)
    check(ui.partida.pausada and ui.partida.posicao==0,"Pausa bloqueia teclado")
    await tecla(KEY_TAB)
    check(root.gui_get_focus_owner()!=ui.foco_jogo,"Tab sai da vista do jogo")
    ui.informar("Feedback sem animação")
    check(ui.pulso==null or not ui.pulso.is_running(),"Movimento reduzido não inicia pulso")
    check(ui.corpo.get_child(0).get_theme_font_size("font_size")==22,"Texto ampliado aplicado ao conteúdo")
    await frames(3)
    await RenderingServer.frame_post_draw
    root.get_texture().get_image().save_png(saida.path_join("lacunas-acessibilidade-jogo.png"))
    ui.queue_free()
    await frames(2)
    print("RESULTADO RENDER: %d conferências; %d falhas" % [total,falhas])
    quit(0 if falhas==0 else 1)
