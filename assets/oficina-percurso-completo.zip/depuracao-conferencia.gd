extends SceneTree
func _initialize() -> void:
    call_deferred("conferir")
func conferir() -> void:
    var c = load("res://contador.gd").new()
    assert(c.acionar() == 2) # Reprodução conhecida do defeito.
    c.corrigir()
    assert(c.acionar() == 1)
    assert(c.acionar() == 2)
    print("Depuração: antes reproduzido, depois aprovado")
    quit()
