extends SceneTree
func _initialize() -> void:
    call_deferred("conferir")
func conferir() -> void:
    var g = load("res://partida.gd").new()
    g.iniciar()
    g.mover(1, 0)
    g.pausada = true
    g.mover(1, 0)
    assert(g.posicao == 1 and g.passos == 1)
    g.iniciar()
    assert(g.posicao == 0 and g.coletadas.is_empty())
    print("Integração: pausa e reinício aprovados")
    quit()
