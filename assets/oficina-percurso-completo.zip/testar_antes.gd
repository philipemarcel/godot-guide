extends SceneTree
func _initialize() -> void:
    var contador = load("res://contador.gd").new()
    var observado: int = contador.acionar()
    print("REGRESSÃO ANTES: esperado1; observado%d; falha intencional" % observado)
    quit(0 if observado == 1 else 1)
