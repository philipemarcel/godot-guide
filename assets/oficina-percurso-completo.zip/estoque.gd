extends RefCounted

# Configuração é copiada; cada instância mantém seu próprio estado.
const CATALOGO: Array[Dictionary] = [
    {"id": "engrenagem", "quantidade": 3},
    {"id": "valvula", "quantidade": 2},
    {"id": "mola", "quantidade": 1}
]
var saldos: Dictionary = {}

func _init() -> void:
    for peca in CATALOGO:
        saldos[peca["id"]] = int(peca["quantidade"])

func consumir(id: String, quantidade: int) -> Dictionary:
    if not saldos.has(id):
        return {"ok": false, "motivo": "ID desconhecido"}
    if quantidade <= 0 or quantidade > int(saldos[id]):
        return {"ok": false, "motivo": "Quantidade inválida"}
    saldos[id] = int(saldos[id]) - quantidade
    return {"ok": true, "motivo": "Peça consumida", "saldo": saldos[id]}
