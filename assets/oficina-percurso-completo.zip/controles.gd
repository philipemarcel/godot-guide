extends Node

const ARQUIVO := "user://aether_controles.cfg"
const PADROES := {"of_esquerda": KEY_A, "of_direita": KEY_D, "of_cima": KEY_W, "of_baixo": KEY_S}
# ui_* permanece separado: Tab/Enter/Space/Escape continuam navegando o menu.
var teclas: Dictionary = PADROES.duplicate()
var capturando: String = ""
var movimento_reduzido: bool = false
var texto_grande: bool = false

func _ready() -> void:
    carregar()

func codigo_valido(codigo: int) -> bool:
    return (codigo >= KEY_A and codigo <= KEY_Z) or codigo in [KEY_LEFT, KEY_RIGHT, KEY_UP, KEY_DOWN]

func aplicar() -> void:
    for acao in teclas:
        if not InputMap.has_action(acao):
            InputMap.add_action(acao)
        Input.action_release(acao)
        InputMap.action_erase_events(acao)
        var evento := InputEventKey.new()
        evento.physical_keycode = teclas[acao]
        InputMap.action_add_event(acao, evento)

func remapear(acao: String, codigo: int) -> String:
    if not teclas.has(acao) or not codigo_valido(codigo):
        return "Use letras A–Z ou setas; teclas de menu são reservadas."
    for outra in teclas:
        if outra != acao and teclas[outra] == codigo:
            return "Conflito com " + outra + "; nada foi alterado."
    teclas[acao] = codigo
    aplicar()
    return "Mapeamento aplicado"

func restaurar() -> void:
    teclas = PADROES.duplicate()
    capturando = ""
    movimento_reduzido = false
    texto_grande = false
    aplicar()

func salvar(caminho: String = ARQUIVO) -> Error:
    var cfg := ConfigFile.new()
    for acao in teclas:
        cfg.set_value("teclas", acao, teclas[acao])
    cfg.set_value("acesso", "movimento_reduzido", movimento_reduzido)
    cfg.set_value("acesso", "texto_grande", texto_grande)
    return cfg.save(caminho)

func carregar(caminho: String = ARQUIVO) -> Error:
    var cfg := ConfigFile.new()
    var erro := cfg.load(caminho)
    var candidato := PADROES.duplicate()
    var usados: Array[int] = []
    var valido := erro == OK
    for acao in candidato:
        var codigo: Variant = cfg.get_value("teclas", acao, PADROES[acao])
        if not codigo is int or not codigo_valido(int(codigo)) or codigo in usados:
            valido = false
        else:
            candidato[acao] = codigo
            usados.append(codigo)
    teclas = candidato if valido else PADROES.duplicate()
    var reduzido: Variant = cfg.get_value("acesso", "movimento_reduzido", false)
    var grande: Variant = cfg.get_value("acesso", "texto_grande", false)
    movimento_reduzido = reduzido if erro == OK and reduzido is bool else false
    texto_grande = grande if erro == OK and grande is bool else false
    capturando = ""
    aplicar()
    return erro
