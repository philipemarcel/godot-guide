extends Node3D
## Camera e RayCast são montados por oficina.gd antes de entrar na árvore.
@onready var camera: Camera3D = $Camera3D
@onready var raio: RayCast3D = $Camera3D/Mira
@onready var marcador: Node3D = $Marcador
var corpo: AnimatableBody3D
var sensor: Area3D
var alvo: Area3D
var alcance := 20.0
var mascara := 13 # bits das camadas 1, 3 e 4: parede, alvo e piso
var incluir_areas := true
var incluir_corpos := true
var pedido := false
var pixel := Vector2.ZERO
var acionar := false
var deslocamento_pendente := 0.0
var ultimo := "Sem consulta por comando"
var previa := "Aguardando física"

func _ready() -> void:
    raio.add_exception(corpo)
    restaurar()

func pedir_centro() -> void:
    pixel = get_viewport().get_visible_rect().size * 0.5
    pedido = true
    acionar = true

func mover_corpo(delta_x: float) -> void:
    deslocamento_pendente += delta_x

func restaurar() -> void:
    alcance = 20.0
    mascara = 13
    incluir_areas = true
    incluir_corpos = true
    pedido = false
    acionar = false
    deslocamento_pendente = 0.0
    marcador.visible = false
    ultimo = "Sem consulta por comando"
    previa = "Aguardando física"

func _unhandled_input(event: InputEvent) -> void:
    # UI consome seus próprios cliques; aqui só chegam cliques não tratados.
    if event is InputEventMouseButton and event.pressed and event.button_index == MOUSE_BUTTON_LEFT:
        pixel = event.position
        pedido = true # no máximo o último clique antes do próximo tick
        acionar = false # selecionar não implica acionar um mecanismo
        get_viewport().set_input_as_handled()
    if event is InputEventKey and event.pressed and not event.echo:
        if event.ctrl_pressed or event.alt_pressed or event.meta_pressed:
            return
        if get_viewport().gui_get_focus_owner() != null:
            return
        match event.physical_keycode:
            KEY_A, KEY_LEFT: mover_corpo(-0.25)
            KEY_D, KEY_RIGHT: mover_corpo(0.25)
            KEY_E: pedir_centro()
            KEY_R: get_parent().restaurar_tudo()
            _: return
        get_viewport().set_input_as_handled()

func _input(event: InputEvent) -> void:
    if event is InputEventKey and event.pressed and not event.echo and event.keycode == KEY_ESCAPE:
        var foco := get_viewport().gui_get_focus_owner()
        if foco != null:
            foco.release_focus()
        get_viewport().set_input_as_handled()

func _physics_process(_delta: float) -> void:
    if deslocamento_pendente != 0.0:
        corpo.position.x = clampf(corpo.position.x + deslocamento_pendente, -7.0, -1.0)
        deslocamento_pendente = 0.0
    raio.target_position = Vector3(0, 0, -alcance) # coordenadas LOCAIS do RayCast
    raio.collision_mask = mascara
    raio.collide_with_areas = incluir_areas
    raio.collide_with_bodies = incluir_corpos
    raio.force_raycast_update() # parâmetros alteráveis; leitura imediata neste tick
    previa = "Sem colisão na mira"
    if raio.is_colliding():
        previa = "Mira: %s; distância %.2f u" % [(raio.get_collider() as Node).name, camera.global_position.distance_to(raio.get_collision_point())]
    if not pedido:
        return
    pedido = false
    var resultado: Dictionary = {}
    if acionar:
        if raio.is_colliding():
            resultado = {"position": raio.get_collision_point(), "normal": raio.get_collision_normal(), "collider": raio.get_collider()}
    else:
        # Não consulte direct_space_state dentro de _input: o espaço pode estar bloqueado.
        var origem := camera.project_ray_origin(pixel)
        var fim := origem + camera.project_ray_normal(pixel) * alcance
        var query := PhysicsRayQueryParameters3D.create(origem, fim, mascara, [corpo.get_rid()])
        query.collide_with_areas = incluir_areas
        query.collide_with_bodies = incluir_corpos
        resultado = get_world_3d().direct_space_state.intersect_ray(query)
    registrar(resultado, acionar)
    acionar = false

func registrar(resultado: Dictionary, tentar_acao: bool) -> void:
    if resultado.is_empty():
        marcador.visible = false
        ultimo = "Sem resultado; nenhum ponto válido selecionado"
        return # Vector3.ZERO poderia ser um ponto válido; não é sentinela.
    var ponto: Vector3 = resultado["position"]
    var normal: Vector3 = resultado["normal"]
    var objeto: Object = resultado["collider"]
    marcador.visible = true
    marcador.global_position = ponto
    marcador.get_child(0).visible = normal.length_squared() > 0.000001
    if normal.length_squared() > 0.000001:
        # A haste do marcador aponta em -Z local. Normal paralela a UP precisa de outro up.
        var cima := Vector3.RIGHT if absf(normal.normalized().dot(Vector3.UP)) > 0.99 else Vector3.UP
        marcador.look_at(ponto + normal, cima)
    ultimo = "%s; ponto=%s; normal=%s" % [objeto.get("name"), ponto, normal]
    if tentar_acao:
        if is_instance_valid(objeto) and objeto.has_method("interagir"):
            objeto.call("interagir")
            ultimo += "; mecanismo acionado uma vez"
        else:
            ultimo += "; primeiro objeto não é interagível"
