extends Area3D
@export var corpo: PhysicsBody3D
var entradas := 0
var saidas := 0
var estabilizar := 3
var ultimo := "Aguardando física"

func _ready() -> void:
    body_entered.connect(ao_entrar)
    body_exited.connect(ao_sair)

func reiniciar_contagem() -> void:
    entradas = 0
    saidas = 0
    estabilizar = 3
    ultimo = "Nova linha de base; aguarde física"

func _physics_process(_delta: float) -> void:
    if estabilizar > 0:
        estabilizar -= 1
        if estabilizar == 0:
            ultimo = "Pronto; mova o corpo por comando"

func ao_entrar(body: Node3D) -> void:
    if estabilizar == 0 and body == corpo:
        entradas += 1
        ultimo = "body_entered"

func ao_sair(body: Node3D) -> void:
    if estabilizar == 0 and body == corpo:
        saidas += 1
        ultimo = "body_exited"

func detectado() -> bool:
    # A lista é atualizada pelo passo físico, não imediatamente após mover.
    return monitoring and corpo in get_overlapping_bodies()
