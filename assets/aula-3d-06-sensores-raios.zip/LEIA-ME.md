# Sensores, raios e seleção
Extraia os nove arquivos juntos e importe project.godot na Godot4.5. A cena de entrada é mínima; oficina.gd constrói a bancada em runtime. Não há dependências externas nem InputMap. Código revisado documentalmente; compilação/execução no motor pendentes.

Há dois ensaios independentes: corpo móvel/sensor à esquerda e mira/mecanismo/parede no centro. A/D deslocam o corpo de ensaio em passos sem gravidade nem resolução de movimento. A área usa sinais e lista física, atualizada pelo motor. Mudar monitoring/máscara reinicia a contagem e espera3 ticks, evitando interpretar a reconfiguração como trajeto do corpo.

E ou botão consulta a mira central e tenta acionar somente o primeiro resultado que implementar interagir. A parede consultada bloqueia o mecanismo. Máscara12 ignora parede, máscara4 consulta só mecanismo e8 só piso. Clique no mundo seleciona com raio projetado; não aciona. Os pedidos são consumidos na física; o último clique antes do tick substitui o anterior. Não é click-to-move nem sistema de dano.

O marcador mostra o último resultado, não segue nova mira. Normal quase paralela aUP usaRIGHT como up de look_at; normal zero não orienta. A haste foi modelada em−Z. Não é Decal nem partícula com tempo de vida.

R restaura e aguarda nova física. UI com foco suspende teclas; Esc libera foco. O Canvas da aula é outro modelo: seção z0, esfera/plano finito, sem Godot nem projeção de Camera3D. Não iguale os números dos dois. Siga roteiro-testes.md para homologar o apoio.
