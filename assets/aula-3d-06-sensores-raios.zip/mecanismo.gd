extends Area3D
var acionamentos := 0

func interagir() -> void:
    acionamentos += 1

func restaurar() -> void:
    acionamentos = 0
