extends Node3D
var consultas
var sensor
var alvo
var corpo: AnimatableBody3D
var leitura: Label
var painel: VBoxContainer
var alcance: HSlider
var mascara: OptionButton
var areas: CheckButton
var corpos: CheckButton
var monitoring: CheckButton
var filtro_sensor: CheckButton

func material(cor: Color) -> StandardMaterial3D:
    var m := StandardMaterial3D.new()
    m.albedo_color = cor
    return m

func esfera(no: Node3D, raio: float, cor: Color) -> void:
    var forma := SphereShape3D.new()
    forma.radius = raio
    var colisao := CollisionShape3D.new()
    colisao.shape = forma
    no.add_child(colisao)
    var visual := MeshInstance3D.new()
    var mesh := SphereMesh.new()
    mesh.radius = raio
    mesh.height = 2.0 * raio
    visual.mesh = mesh
    visual.material_override = material(cor)
    no.add_child(visual)

func caixa(nome: String, pos: Vector3, tamanho: Vector3, camada: int, cor: Color) -> void:
    var b := StaticBody3D.new()
    b.name = nome
    b.position = pos
    b.collision_layer = camada
    b.collision_mask = 0
    var c := CollisionShape3D.new()
    var forma := BoxShape3D.new()
    forma.size = tamanho
    c.shape = forma
    b.add_child(c)
    var v := MeshInstance3D.new()
    var mesh := BoxMesh.new()
    mesh.size = tamanho
    v.mesh = mesh
    v.material_override = material(cor)
    b.add_child(v)
    add_child(b)

func botao(texto: String, acao: Callable) -> void:
    var b := Button.new()
    b.text = texto
    b.pressed.connect(acao)
    painel.add_child(b)

func chave(texto: String, acao: Callable) -> CheckButton:
    var c := CheckButton.new()
    c.text = texto
    c.button_pressed = true
    c.toggled.connect(acao)
    painel.add_child(c)
    return c

func _ready() -> void:
    caixa("Piso",Vector3(0,-0.15,0),Vector3(20,0.3,20),8,Color("48341f"))
    caixa("Parede",Vector3(0,3,3),Vector3(3,6,0.2),1,Color("8e5d34"))
    corpo = AnimatableBody3D.new()
    corpo.name = "CorpoEnsaio"
    corpo.sync_to_physics = false
    corpo.collision_layer = 2
    corpo.collision_mask = 0
    corpo.position = Vector3(-7,0.5,0)
    esfera(corpo,0.3,Color("56cfd5"))
    add_child(corpo)
    sensor = Area3D.new()
    sensor.name = "Sensor"
    sensor.position = Vector3(-4,0.5,0)
    sensor.collision_layer = 0
    sensor.collision_mask = 2
    esfera(sensor,1.5,Color(0.65,0.5,0.2,0.25))
    sensor.get_child(1).material_override.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
    sensor.set_script(preload("res://sensor.gd"))
    sensor.corpo = corpo
    add_child(sensor)
    alvo = Area3D.new()
    alvo.name = "Mecanismo"
    alvo.position = Vector3(0,1,0)
    alvo.collision_layer = 4
    alvo.collision_mask = 0
    esfera(alvo,0.7,Color("d4a359"))
    alvo.set_script(preload("res://mecanismo.gd"))
    add_child(alvo)
    consultas = Node3D.new()
    consultas.name = "Consultas"
    var camera := Camera3D.new()
    camera.name = "Camera3D"
    camera.position = Vector3(0,10,14)
    consultas.add_child(camera)
    var raio := RayCast3D.new()
    raio.name = "Mira"
    camera.add_child(raio)
    var marcador := Node3D.new()
    marcador.name = "Marcador"
    var haste := MeshInstance3D.new()
    var mesh_haste := BoxMesh.new()
    mesh_haste.size = Vector3(0.06,0.06,0.5)
    haste.mesh = mesh_haste
    haste.position.z = -0.25
    haste.material_override = material(Color("59e0a6"))
    marcador.add_child(haste)
    consultas.add_child(marcador)
    consultas.set_script(preload("res://consultas.gd"))
    consultas.corpo = corpo
    consultas.sensor = sensor
    consultas.alvo = alvo
    add_child(consultas)
    camera.look_at(alvo.global_position,Vector3.UP)
    camera.make_current()
    var luz := DirectionalLight3D.new()
    luz.rotation_degrees = Vector3(-55,-30,0)
    add_child(luz)
    var ambiente := WorldEnvironment.new()
    ambiente.environment = Environment.new()
    ambiente.environment.background_mode = Environment.BG_COLOR
    ambiente.environment.background_color = Color("1b1711")
    ambiente.environment.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
    ambiente.environment.ambient_light_color = Color("cdbd9b")
    ambiente.environment.ambient_light_energy = 0.7
    add_child(ambiente)
    var layer := CanvasLayer.new()
    add_child(layer)
    var fundo := PanelContainer.new()
    fundo.position = Vector2(12,12)
    fundo.custom_minimum_size.x = 370
    layer.add_child(fundo)
    painel = VBoxContainer.new()
    fundo.add_child(painel)
    leitura = Label.new()
    leitura.custom_minimum_size.x = 370
    leitura.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
    painel.add_child(leitura)
    botao("Consultar e acionar no centro · E",consultas.pedir_centro)
    botao("Corpo −0,25 u · A",func(): consultas.mover_corpo(-0.25))
    botao("Corpo +0,25 u · D",func(): consultas.mover_corpo(0.25))
    var l := Label.new()
    l.text = "Alcance (u); clique no mundo seleciona"
    painel.add_child(l)
    alcance = HSlider.new()
    alcance.min_value = 5
    alcance.max_value = 30
    alcance.step = 1
    alcance.value = 20
    alcance.value_changed.connect(func(v): consultas.alcance=v)
    painel.add_child(alcance)
    mascara = OptionButton.new()
    for texto in ["13: parede + alvo + piso","12: alvo + piso (atravessa parede)","4: só alvo","8: só piso"]:
        mascara.add_item(texto)
    mascara.item_selected.connect(func(i): consultas.mascara=[13,12,4,8][i])
    painel.add_child(mascara)
    areas = chave("Raio consulta áreas",func(v): consultas.incluir_areas=v)
    corpos = chave("Raio consulta corpos",func(v): consultas.incluir_corpos=v)
    monitoring = chave("Sensor monitoring",func(v):
        sensor.set_deferred("monitoring",v)
        sensor.reiniciar_contagem())
    filtro_sensor = chave("Sensor consulta camada 2",func(v):
        sensor.set_deferred("collision_mask",2 if v else 0)
        sensor.reiniciar_contagem())
    botao("Restaurar tudo · R",restaurar_tudo)

func restaurar_tudo() -> void:
    consultas.restaurar()
    corpo.position = Vector3(-7,0.5,0)
    sensor.set_deferred("monitoring",true)
    sensor.set_deferred("collision_mask",2)
    sensor.reiniciar_contagem()
    alvo.restaurar()
    alcance.set_value_no_signal(20)
    mascara.select(0)
    for c in [areas,corpos,monitoring,filtro_sensor]:
        c.set_pressed_no_signal(true)

func _process(_delta: float) -> void:
    leitura.text = ("SENSOR / RAIO / CLIQUE\nCorpo X=%.2f; detectado=%s\nEntradas%d / saídas%d; %s\n%s\nÚltimo: %s\nAcionamentos%d | alcance%.0f | máscara%d\nA/D movem só o corpo do sensor; E consulta centro.\nClique seleciona; Esc libera foco; R restaura." % [
        corpo.position.x,sensor.detectado(),sensor.entradas,sensor.saidas,sensor.ultimo,
        consultas.previa,consultas.ultimo,alvo.acionamentos,consultas.alcance,consultas.mascara])
