# Oficina — iluminação indireta e reflexos

Referência Godot4.5/Forward+/desktop. Nove arquivos locais, sem assets externos. **Não há cenas assadas ou execução homologada fornecidas.** O gerador precisa do editor e de unwrap; o roteiro inclui importação, UV2, bake e observação real.

1. Importe project.godot. F5 abre uma tela de instruções, não a comparação.
2. Abra gerar_cenas.gd no editor de scripts e use Arquivo → Executar (Ctrl+Shift+X). Observe erros/saída. Devem surgir três cenas em cenas/.
3. Abra lightmap.tscn, selecione LightmapGI e faça Bake Lightmaps. Escolha um destino dentro do projeto para os dados e salve a cena. As malhas estáticas são ArrayMesh com UV2; bake de PrimitiveMesh puro não é o fluxo fornecido. Confira probes para a esfera dinâmica. directional fica false nesta oficina.
4. Abra voxel.tscn, selecione VoxelGI e faça Bake. Salve VoxelGIData externamente em .res e salve a cena. Não confunda o bake geométrico inicial com luzes dinâmicas em runtime.
5. Em sdfgi.tscn não há bake manual desse tipo; execute e espere atualizar/convergir. Geometria que contribui é estática. Não espere oclusão/emissão dinâmica de qualquer objeto móvel.
6. Execute cada cena atual com F6. Mantenha energia1 e câmera/materiais iguais. G alterna GI; P alterna sonda; R restaura e recria sonda. Há controles equivalentes.
7. Compare Once/Always após mudar a luz. Once pode conservar a captura antiga; use Recapturar para uma nova. Always aumenta frequência/custo. Nenhum modo corrige automaticamente todas as limitações de cubemap/paralaxe.

O gerador recusa executar se qualquer cena de destino já existir. Para regenerar, guarde cópia das cenas/dados e renomeie conscientemente os destinos antes de repetir. Esse passo não roda sozinho no início do jogo.

O slider nativo altera luz direta, não o ganho web de um único rebatimento. Lightmap com BAKEDYNAMIC preserva direto em runtime, mas seu indireto permanece o do bake. VoxelGI/SDFGI também podem fornecer componente especular; desligar a sonda nativa não garante metal sem reflexo. O browser isola propositalmente componentes para ensinar suas diferenças.

Lightmap exige UV2/armazenamento e bake no editor com hardware/renderizador compatíveis; reprodução e plataforma de bake são decisões separadas. VoxelGI/SDFGI exigem Forward+ na referência. Não há benchmark, promessa de custo zero ou garantia de GPU dedicada como requisito absoluto de execução.
