extends RefCounted

static func anexar(raiz: Node3D, no: Node) -> void:
    raiz.add_child(no)
    no.owner = raiz

static func malha(raiz: Node3D, nome: String, origem: PrimitiveMesh, pos: Vector3, cor: Color, metal: bool = false) -> MeshInstance3D:
    var mesh := ArrayMesh.new()
    mesh.add_surface_from_arrays(Mesh.PRIMITIVE_TRIANGLES, origem.surface_get_arrays(0))
    if not metal:
        var erro := mesh.lightmap_unwrap(Transform3D.IDENTITY, 0.15)
        if erro != OK:
            push_error("Falha de UV2 em %s: %s" % [nome, error_string(erro)])
            return null
    var material := StandardMaterial3D.new()
    material.albedo_color = cor
    material.metallic = 1.0 if metal else 0.0
    material.roughness = 0.12 if metal else 0.8
    mesh.surface_set_material(0, material)
    var no := MeshInstance3D.new()
    no.name = nome
    no.mesh = mesh
    no.position = pos
    no.gi_mode = GeometryInstance3D.GI_MODE_DYNAMIC if metal else GeometryInstance3D.GI_MODE_STATIC
    no.layers = 2 if metal else 1 # Sonda captura layer1 e exclui a própria esfera metálica.
    anexar(raiz, no)
    return no

static func criar(tipo: String) -> Node3D:
    var raiz := Node3D.new()
    raiz.name = "Sala"
    raiz.set_meta("tecnica", tipo)
    raiz.set_script(preload("res://controle.gd"))
    var branco := Color(0.72, 0.70, 0.64)
    var partes := [
        ["Piso", Vector3(4.4, 0.2, 3.4), Vector3(0, -0.1, -0.5), branco],
        ["ParedeVermelha", Vector3(0.2, 3.2, 3.4), Vector3(-2.1, 1.5, -0.5), Color(0.75, 0.035, 0.018)],
        ["ParedeDireita", Vector3(0.2, 3.2, 3.4), Vector3(2.1, 1.5, -0.5), branco],
        ["Fundo", Vector3(4.4, 3.2, 0.2), Vector3(0, 1.5, -2.1), branco],
        ["Teto", Vector3(4.4, 0.2, 3.4), Vector3(0, 3.1, -0.5), branco],
        ["Bloco", Vector3(0.38, 1.18, 0.62), Vector3(0.11, 0.59, -1.41), branco]
    ]
    for parte in partes:
        var box := BoxMesh.new()
        box.size = parte[1]
        if malha(raiz, parte[0], box, parte[2], parte[3]) == null:
            raiz.free()
            return null
    for i in range(2):
        var esfera := SphereMesh.new()
        esfera.radius = 0.57 if i == 0 else 0.62
        esfera.height = esfera.radius * 2.0
        esfera.radial_segments = 24
        esfera.rings = 12
        var pos := Vector3(-0.78, 0.57, -0.45) if i == 0 else Vector3(0.8, 0.62, -0.8)
        if malha(raiz, "Fosca" if i == 0 else "Metal", esfera, pos, branco if i == 0 else Color(0.95, 0.76, 0.4), i == 1) == null:
            raiz.free()
            return null
    var luz := OmniLight3D.new()
    luz.name = "LuzDireta"
    luz.position = Vector3(0.2, 2.8, 0.25)
    luz.omni_range = 10.0
    luz.light_energy = 1.0
    luz.light_bake_mode = Light3D.BAKE_DYNAMIC
    luz.shadow_enabled = true
    anexar(raiz, luz)
    var mundo := WorldEnvironment.new()
    mundo.name = "Mundo"
    var e := Environment.new()
    e.background_mode = Environment.BG_COLOR
    e.background_color = Color.BLACK
    e.ambient_light_source = Environment.AMBIENT_SOURCE_DISABLED
    e.reflected_light_source = Environment.REFLECTION_SOURCE_BG
    e.tonemap_mode = Environment.TONE_MAPPER_FILMIC
    e.sdfgi_enabled = tipo == "sdfgi"
    e.sdfgi_read_sky_light = false
    e.sdfgi_use_occlusion = true
    mundo.environment = e
    anexar(raiz, mundo)
    var sonda := ReflectionProbe.new()
    sonda.name = "Sonda"
    sonda.position = Vector3(0, 1.5, -0.5)
    sonda.size = Vector3(4.6, 3.4, 4.0)
    sonda.interior = true
    sonda.box_projection = true
    sonda.ambient_mode = ReflectionProbe.AMBIENT_DISABLED
    sonda.cull_mask = 1
    sonda.enable_shadows = true
    sonda.update_mode = ReflectionProbe.UPDATE_ONCE
    anexar(raiz, sonda)
    if tipo == "lightmap":
        var lm := LightmapGI.new()
        lm.name = "LightmapGI"
        lm.interior = true
        lm.directional = false
        lm.generate_probes_subdiv = LightmapGI.GENERATE_PROBES_SUBDIV_8
        anexar(raiz, lm)
    elif tipo == "voxel":
        var voxel := VoxelGI.new()
        voxel.name = "VoxelGI"
        voxel.position = Vector3(0, 1.5, -0.5)
        voxel.size = Vector3(5, 4, 4)
        voxel.subdiv = VoxelGI.SUBDIV_128
        anexar(raiz, voxel)
    var camera := Camera3D.new()
    camera.name = "Camera"
    camera.position = Vector3(0, 1.45, 5.6)
    camera.rotation_degrees.x = -2.0
    camera.current = true
    anexar(raiz, camera)
    return raiz
