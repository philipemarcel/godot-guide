extends Node3D
@onready var luz: OmniLight3D = $LuzDireta
@onready var ambiente: Environment = $Mundo.environment
@onready var sonda: ReflectionProbe = $Sonda
var lm: LightmapGI
var voxel: VoxelGI
var dados: LightmapGIData
var gi: CheckButton
var reflexo: CheckButton
var sempre: CheckButton
var energia: HSlider
var leitura: Label

func _ready() -> void:
    lm = get_node_or_null("LightmapGI") as LightmapGI
    voxel = get_node_or_null("VoxelGI") as VoxelGI
    if lm != null:
        dados = lm.light_data
    var layer := CanvasLayer.new()
    add_child(layer)
    var fundo := PanelContainer.new()
    fundo.position = Vector2(20, 650)
    layer.add_child(fundo)
    var painel := VBoxContainer.new()
    painel.custom_minimum_size.x = 600
    fundo.add_child(painel)
    gi = CheckButton.new()
    gi.text = "GI da cena ativa · G"
    gi.button_pressed = true
    painel.add_child(gi)
    gi.toggled.connect(func(_v: bool): atualizar())
    reflexo = CheckButton.new()
    reflexo.text = "Sonda local ativa · P"
    reflexo.button_pressed = true
    painel.add_child(reflexo)
    reflexo.toggled.connect(func(_v: bool): atualizar())
    sempre = CheckButton.new()
    sempre.text = "Sonda Always; mais capturas/custo"
    painel.add_child(sempre)
    sempre.toggled.connect(func(_v: bool): atualizar())
    energia = HSlider.new()
    energia.min_value = 0.5
    energia.max_value = 2.0
    energia.step = 0.1
    energia.value = 1.0
    painel.add_child(energia)
    energia.value_changed.connect(func(_v: float): atualizar())
    for item in [["Recapturar sonda Once", recapturar], ["Restaurar referência · R", restaurar]]:
        var b := Button.new()
        b.text = item[0]
        painel.add_child(b)
        b.pressed.connect(item[1])
    leitura = Label.new()
    leitura.custom_minimum_size.x = 600
    leitura.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
    painel.add_child(leitura)
    atualizar()

func atualizar() -> void:
    if leitura == null:
        return
    luz.light_energy = energia.value
    sonda.visible = reflexo.button_pressed
    sonda.update_mode = ReflectionProbe.UPDATE_ALWAYS if sempre.button_pressed else ReflectionProbe.UPDATE_ONCE
    if lm != null:
        lm.light_data = dados if gi.button_pressed else null
    elif voxel != null:
        voxel.visible = gi.button_pressed
    else:
        ambiente.sdfgi_enabled = gi.button_pressed
    var aviso := "Aguarde convergência/captura; o teste nativo não separa componentes como o Canvas."
    if lm != null and dados == null:
        aviso = "SEM LIGHTMAP: faça Bake Lightmaps no editor antes de avaliar GI."
    elif voxel != null and voxel.data == null:
        aviso = "SEM VOXEL DATA: faça Bake e salve o recurso antes de avaliar GI."
    leitura.text = "%s | energia direta %.1f\n%s\nA energia da luz muda o direto; indireto pré-assado não acompanha automaticamente.\nAmbiente difuso da sonda desativado; parede e materiais fixos." % [get_meta("tecnica"), energia.value, aviso]

func recapturar() -> void:
    var nova := sonda.duplicate() as ReflectionProbe
    add_child(nova)
    sonda.free()
    sonda = nova
    atualizar()

func restaurar() -> void:
    gi.set_pressed_no_signal(true)
    reflexo.set_pressed_no_signal(true)
    sempre.set_pressed_no_signal(false)
    energia.set_value_no_signal(1.0)
    atualizar()
    recapturar()

func _unhandled_key_input(event: InputEvent) -> void:
    if event is InputEventKey and event.pressed and not event.echo and not event.ctrl_pressed and not event.alt_pressed and not event.meta_pressed:
        if event.keycode == KEY_G:
            gi.button_pressed = not gi.button_pressed
        elif event.keycode == KEY_P:
            reflexo.button_pressed = not reflexo.button_pressed
        elif event.keycode == KEY_R:
            restaurar()
