@tool
extends EditorScript
const SALA = preload("res://sala.gd")
func _run() -> void:
    for tipo in ["lightmap", "voxel", "sdfgi"]:
        if FileAccess.file_exists("res://cenas/%s.tscn" % tipo):
            push_error("Cena já existe: %s. Guarde cópia e escolha conscientemente como regenerar; nada será sobrescrito." % tipo)
            return
    var erro := DirAccess.make_dir_recursive_absolute("res://cenas")
    if erro != OK:
        push_error(error_string(erro))
        return
    for tipo in ["lightmap", "voxel", "sdfgi"]:
        var raiz := SALA.criar(tipo)
        if raiz == null:
            push_error("Geração interrompida; confira os erros de UV2.")
            return
        var cena := PackedScene.new()
        erro = cena.pack(raiz)
        if erro == OK:
            erro = ResourceSaver.save(cena, "res://cenas/%s.tscn" % tipo)
        raiz.free()
        if erro != OK:
            push_error("Falha ao salvar %s: %s" % [tipo, error_string(erro)])
            return
    get_editor_interface().get_resource_filesystem().scan()
    print("Três cenas geradas. Abra uma, faça o bake indicado e execute com F6. O gerador recusa sobrescrever cenas existentes.")
