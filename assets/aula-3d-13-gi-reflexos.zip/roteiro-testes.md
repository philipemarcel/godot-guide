# Homologação real pendente

Registrar versão/renderizador, esperado/observado e evidência por caso. Não marcar sem executar.

- [ ] Importar/compilar os quatro scripts; tela inicial instrui corretamente.
- [ ] Executar EditorScript: converter malhas, unwrap sem erro e salvar três cenas com owner/hierarquia completos.
- [ ] Confirmar UV2, lightmap_size_hint e malhas estáticas ArrayMesh; não assar PrimitiveMesh sem conversão.
- [ ] Lightmap: bake, recursos salvos, probes na região do metal, direto dinâmico/indireto estático.
- [ ] Voxel: tamanho/subdivisão, bake e .res persistidos; dados presentes após fechar/reabrir.
- [ ] SDFGI: Forward+, gi_mode dos contribuintes, convergência e paredes espessas; oclusores móveis não suportados como estáticos instantâneos.
- [ ] Mesma câmera, luz1, ambiente preto e materiais nas três cenas; sem sistemas GI extras.
- [ ] GI off/on e sonda off/on; ambiente difuso da sonda desativado e máscara captura layer1/exclui metal layer2.
- [ ] Metal mantém brilho direto quando sem captura; reflexos GI/sky/SSR reconhecidos quando disponíveis.
- [ ] Once versus Always após alterar luz; recriar sonda recaptura sem recurso antigo reaparecer.
- [ ] R/G/P repetidos, foco, botões e interface; alteração de controles não reexecuta gerador/bakes.
- [ ] Investigar vazamentos, probes mal posicionados, resolução, AABB e box_projection sem prometer correção universal.
- [ ] Medir custo de GI, memória dos bakes e recaptura de sonda no hardware alvo.

Depois do currículo integral: avaliar aprofundamentos em lightmap directional/probes, streaming de GI, SSR e objetos fora de tela, invalidação/atualização de capturas e orçamento por plataforma. Não são funcionalidades implementadas neste apoio.
