extends Control
func _ready() -> void:
    var texto := Label.new()
    texto.position = Vector2(40, 40)
    texto.text = "OFICINA DE ILUMINAÇÃO — GODOT 4.5 / FORWARD+\n\n1. No editor, abra gerar_cenas.gd.\n2. Use Arquivo > Executar no editor de scripts (Ctrl+Shift+X).\n3. Confira a saída: três cenas devem ser geradas em res://cenas.\n4. Abra uma cena gerada. Faça o bake indicado em LEIA-ME.md.\n5. Execute a cena atual com F6; não use esta tela para avaliar GI.\n\nO gerador prepara ArrayMesh/UV2; não entrega iluminação pré-assada.\nImportação, unwrap, bake e execução ainda precisam de validação no motor."
    add_child(texto)
