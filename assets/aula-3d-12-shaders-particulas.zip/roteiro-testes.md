# Validação real pendente — registrar versão, renderizador e evidência

- [ ] Importar os nove arquivos e compilar onda.gdshader, borda.gdshader e os dois scripts sem erros.
- [ ] Ver três bancadas e interface inteira; ajustar janela/layout se houver cortes.
- [ ] PlaneMesh4×4:2/8/32células correspondem a subdivide1/7/31; conferir vértices e amostragem.
- [ ] T/slider/R: uniform tempo próprio, amplitude0 plana, fase0 congelada; normal coerente e margem de culling suficiente nos extremos.
- [ ] Confirmar que deformação visual não altera colisão física; não há corpo físico ondulante no apoio.
- [ ] Esfera: expoente0,5/3/6; borda estreita com expoente alto; transparência/additive e ordenação no renderizador.
- [ ] F após início/meio/fim: restart limpa/reinicia sem depender de recarregar a cena; finished observado, sem usá-lo como sinal de impacto.
- [ ] R durante emissão e após final: novo emissor parado, sem partículas antigas; repetir dez vezes.
- [ ] Colisor ativo/off: piso visual não muda; box size/topo, layers/cull_mask e material COLLISION_RIGID corretos.
- [ ] Conferir collision_base_size como diâmetro, visibility_aabb e enquadramento; colisão/atração só na área coberta.
- [ ] Acompanhar lifecycle de2s e diferença de tempo: onda manual, partículas reais contínuas após F.
- [ ] Teclas não capturam sliders/menus e têm botões equivalentes; janela estreita/foco.
- [ ] Medir desempenho com quantidade/resolução/transparência reais antes de estabelecer orçamento.

Após revisar currículo integral, avaliar aprofundamentos: tangentes com normal map, transparência/ordenação, reflexos/refração físicos, partículas contínuas/trilhas, culling/curvas/LOD e migração de renderizador. Não são funcionalidades prontas deste apoio.
