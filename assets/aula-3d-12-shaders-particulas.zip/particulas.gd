extends RefCounted

static func criar(pai: Node3D) -> GPUParticles3D:
    var p := GPUParticles3D.new()
    p.name = "Faiscas"
    p.position = Vector3(4, 1.6, 0)
    p.emitting = false
    p.one_shot = true
    p.amount = 48
    p.lifetime = 2.0
    p.explosiveness = 1.0
    p.use_fixed_seed = true
    p.seed = 29
    p.local_coords = false
    p.layers = 1
    p.collision_base_size = 0.12 # Diâmetro de colisão, não raio.
    p.visibility_aabb = AABB(Vector3(-5, -20, -5), Vector3(10, 26, 10))
    var processo := ParticleProcessMaterial.new()
    processo.direction = Vector3.UP
    processo.spread = 30.0
    processo.initial_velocity_min = 2.0
    processo.initial_velocity_max = 3.0
    processo.gravity = Vector3(0, -9.8, 0)
    processo.collision_mode = ParticleProcessMaterial.COLLISION_RIGID
    processo.collision_bounce = 0.6
    processo.collision_friction = 0.2
    p.process_material = processo
    var esfera := SphereMesh.new()
    esfera.radius = 0.06
    esfera.height = 0.12
    var desenho := StandardMaterial3D.new()
    desenho.albedo_color = Color(1.0, 0.55, 0.15)
    desenho.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
    esfera.material = desenho
    p.draw_pass_1 = esfera
    pai.add_child(p)
    return p
