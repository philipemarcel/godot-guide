# Onda, borda e partículas

Referência: Godot4.5/Forward+/desktop. Importar project.godot e executar oficina.tscn. Projeto procedural sem assets externos; nós aparecem na árvore Remote. **Compilação dos scripts/shaders e execução no motor ainda pendentes.**

Da esquerda para direita: plano ondulado, esfera com borda e piso de partículas. Use sliders, escolha2/8/32células e compare. T avança somente o uniform tempo da onda0,1s; o shader não depende de TIME. F dispara/reinicia48partículas em tempo real; R zera a onda e recria o emissor parado, mantendo as opções. Há botões equivalentes. Não é simulação física de água ou vidro.

O piso visual permanece quando desliga o colisor GPU. Faíscas devem atravessá-lo sem o colisor, pois uma mesh/StaticBody comum não fornece esse teste às partículas GPU. O colisor usa size na Godot4.5; tutoriais de outras versões podem mostrar extents. Sua máscara filtra camadas visuais do sistema de partículas, não collision_layer física.

O laboratório web é um modelo matemático próprio. Não é screenshot do projeto nem compilador de shader. A esfera ideal mostra máscara angular; não rasteriza a cena. Oito pontos e um plano infinito não reproduzem48partículas com box/atrito/colisão esférica e frame discreto da GPU. O mesmo número de bounce não exige trajetórias idênticas.

Ler roteiro-testes.md; confirmar recursos no hardware/renderizador escolhido antes de adaptar para outra plataforma. Não há benchmark, garantia de custo zero, SDF, atração, turbulência, colisão de gameplay, refração ou deformação física entregues.
