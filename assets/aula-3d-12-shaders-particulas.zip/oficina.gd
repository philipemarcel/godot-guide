extends Node3D
const PARTICULAS = preload("res://particulas.gd")
var plano: MeshInstance3D
var onda: ShaderMaterial
var borda: ShaderMaterial
var faiscas: GPUParticles3D
var colisor: GPUParticlesCollisionBox3D
var painel: VBoxContainer
var leitura: Label
var amplitude: HSlider
var velocidade: HSlider
var expoente: HSlider
var celulas: OptionButton
var colisao: CheckButton
var tempo := 0.0
var estado := "Emissor parado; F dispara/reinicia."

func slider(texto: String, minimo: float, maximo: float, passo: float, valor: float) -> HSlider:
    var l := Label.new()
    l.text = texto
    painel.add_child(l)
    var s := HSlider.new()
    s.min_value = minimo
    s.max_value = maximo
    s.step = passo
    s.value = valor
    painel.add_child(s)
    s.value_changed.connect(func(_v: float): atualizar())
    return s

func botao(texto: String, acao: Callable) -> void:
    var b := Button.new()
    b.text = texto
    painel.add_child(b)
    b.pressed.connect(acao)

func objeto(nome: String, mesh: Mesh, pos: Vector3) -> MeshInstance3D:
    var m := MeshInstance3D.new()
    m.name = nome
    m.mesh = mesh
    m.position = pos
    add_child(m)
    return m

func _ready() -> void:
    plano = objeto("PlanoOndulado", PlaneMesh.new(), Vector3(-4, 0, 0))
    plano.extra_cull_margin = 0.8
    onda = ShaderMaterial.new()
    onda.shader = preload("res://onda.gdshader")
    plano.material_override = onda
    var esfera := SphereMesh.new()
    esfera.radius = 1.0
    esfera.height = 2.0
    var escudo := objeto("Escudo", esfera, Vector3(0, 1, 0))
    borda = ShaderMaterial.new()
    borda.shader = preload("res://borda.gdshader")
    escudo.material_override = borda
    var caixa := BoxMesh.new()
    caixa.size = Vector3(5, 0.2, 5)
    objeto("PisoVisual", caixa, Vector3(4, -0.1, 0))
    colisor = GPUParticlesCollisionBox3D.new()
    colisor.name = "ColisorGPU"
    colisor.position = Vector3(4, -0.1, 0)
    colisor.size = Vector3(5, 0.2, 5)
    colisor.cull_mask = 1
    add_child(colisor)
    criar_emissor()
    var camera := Camera3D.new()
    camera.position = Vector3(9, 8, 14)
    add_child(camera)
    camera.look_at(Vector3(0, 0.7, 0))
    camera.make_current()
    var luz := DirectionalLight3D.new()
    luz.rotation_degrees = Vector3(-50, -30, 0)
    add_child(luz)
    var mundo := WorldEnvironment.new()
    var ambiente := Environment.new()
    ambiente.background_mode = Environment.BG_COLOR
    ambiente.background_color = Color(0.035, 0.025, 0.015)
    ambiente.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
    ambiente.ambient_light_color = Color.WHITE
    ambiente.ambient_light_energy = 0.35
    mundo.environment = ambiente
    add_child(mundo)
    interface()
    atualizar()

func criar_emissor() -> void:
    faiscas = PARTICULAS.criar(self)
    faiscas.finished.connect(func(): estado = "Ciclo GPU terminado; F permite repetir.")

func interface() -> void:
    var layer := CanvasLayer.new()
    add_child(layer)
    var fundo := PanelContainer.new()
    fundo.position = Vector2(20, 550)
    layer.add_child(fundo)
    painel = VBoxContainer.new()
    painel.custom_minimum_size.x = 490
    fundo.add_child(painel)
    amplitude = slider("Amplitude local", 0, 0.8, 0.1, 0.3)
    velocidade = slider("Velocidade de fase rad/s", 0, 3, 0.25, 1)
    expoente = slider("Expoente da borda", 0.5, 6, 0.5, 3)
    celulas = OptionButton.new()
    for n in [2, 8, 32]:
        celulas.add_item("%d células/lado" % n, n)
    celulas.select(1)
    painel.add_child(celulas)
    celulas.item_selected.connect(func(_i: int): atualizar())
    colisao = CheckButton.new()
    colisao.text = "Colisor GPU ativo; piso visual independente"
    colisao.button_pressed = true
    painel.add_child(colisao)
    colisao.toggled.connect(func(_v: bool): atualizar())
    botao("T: avançar onda0,1s · partículas usam tempo real", passo)
    botao("F: disparar/repetir ciclo GPU", disparar)
    botao("R: zerar onda e limpar partículas", restaurar)
    leitura = Label.new()
    painel.add_child(leitura)

func atualizar() -> void:
    if leitura == null:
        return
    var n := celulas.get_selected_id()
    var malha := PlaneMesh.new()
    malha.size = Vector2(4, 4)
    malha.subdivide_width = n - 1
    malha.subdivide_depth = n - 1
    plano.mesh = malha
    onda.set_shader_parameter("amplitude", amplitude.value)
    onda.set_shader_parameter("velocidade", velocidade.value)
    onda.set_shader_parameter("tempo", tempo)
    borda.set_shader_parameter("expoente", expoente.value)
    colisor.visible = colisao.button_pressed

func passo() -> void:
    tempo = snappedf(tempo + 0.1, 0.1)
    onda.set_shader_parameter("tempo", tempo)

func disparar() -> void:
    faiscas.restart(true)
    faiscas.emitting = true
    estado = "Ciclo GPU em tempo real; restart limpa o anterior."

func restaurar() -> void:
    tempo = 0.0
    onda.set_shader_parameter("tempo", tempo)
    faiscas.free()
    criar_emissor() # Novo nó parado: nenhuma partícula antiga precisa desaparecer por timer.
    estado = "Tempo zerado e emissor recriado parado."

func _process(_delta: float) -> void:
    if leitura != null:
        leitura.text = "Onda:%.1fs | A=%.1f | fase=%.2f | expoente=%.1f\n%s" % [tempo, amplitude.value, velocidade.value, expoente.value, estado]

func _unhandled_key_input(event: InputEvent) -> void:
    if event is InputEventKey and event.pressed and not event.echo and not event.ctrl_pressed and not event.alt_pressed and not event.meta_pressed:
        if event.keycode == KEY_T:
            passo()
        elif event.keycode == KEY_F:
            disparar()
        elif event.keycode == KEY_R:
            restaurar()
