extends MeshInstance3D

func _ready() -> void:
    var st := SurfaceTool.new()
    st.begin(Mesh.PRIMITIVE_TRIANGLES)
    st.set_normal(Vector3.UP)
    # Ordem horária vista de cima (+Y), conforme convenção de faces da Godot.
    st.set_uv(Vector2(0, 1))
    st.add_vertex(Vector3(-1, 0, 0))
    st.set_uv(Vector2(0.5, 0))
    st.add_vertex(Vector3(0, 0, -2))
    st.set_uv(Vector2(1, 1))
    st.add_vertex(Vector3(1, 0, 0))
    mesh = st.commit()
    # Geometria visual; nenhuma colisão foi criada.
