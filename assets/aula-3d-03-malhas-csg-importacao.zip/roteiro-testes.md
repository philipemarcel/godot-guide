# Testes Godot 4.5 — pendentes

Registrar versão/renderizador e evidências reais. Não aprovar com base no diagrama JS.

- [ ] Importar/compilar scripts e cenas; registrar todos os erros/avisos.
- [ ] MeshInstance3D e BoxMesh distintos; duplicação compartilha recurso até torná-lo único.
- [ ] A/B na mesma raiz e ordem; dimensões e profundidade do recorte corretas.
- [ ] R e F6 instalam subtração/B.x=0/colisão false; interface e câmera legíveis.
- [ ] Três operações usam as mesmas entradas; B.x=0,1.5,4 produzem geometria prevista na seção.
- [ ] Sem colisão: V não atinge CSG. Com colisão/sub central: centro passa, X=1.5,Y=0 atinge faixa sólida.
- [ ] X=-5,Y=0: cubo visual sem corpo não produz contato.
- [ ] Mudança durante espera do raio exige nova consulta; sem leitura antiga tratada como atual.
- [ ] Atalhos A/D/1/2/3/C/P/R/V e interface, repetição/modificadores, limites e reset.
- [ ] Importar exemplos.glb com sufixos ativos; conferir quatro nós, escala e material.
- [ ] -col triangular estático; -convcol convexo sem RigidBody automático; -colonly sem visual.
- [ ] Instanciar em cena própria com câmera/luz e conferir colisões no modo de depuração.
- [ ] Em cópia, Bake Mesh Instance e Bake Collision Shape; corpo/Transform corretos.
- [ ] Original oculto E use_collision=false, sem duplicação visual/física; testar passagem novamente.
- [ ] Mudar fonte e refazer bake quando necessário; não presumir atualização automática.
- [ ] triangulo.tscn: _ready executa, face visível por cima e atributos/normais coerentes; sem colisão.
- [ ] Opcional Blender: exportar seu .glb e inspecionar reimportação; fixture não valida exportador.
- [ ] Câmera/UI/extremos, filtros e testes acima homologados antes de aprovar a aula.
