# Aula 3D 3 — malhas, CSG e importação

Referência Godot 4.5, GDScript, Compatibility, desktop. Revisado documentalmente; projeto não compilado/executado no motor neste ambiente. Importação, colisão física e bake continuam pendentes. O diagrama JS não valida esses processos.

## Começar

Importe project.godot e abra oficina.tscn. VisualSemColisao é MeshInstance3D com BoxMesh de aresta 1 em X=-5: desenho sem corpo. Piso também é apenas visual. Combinacao é CSGCombiner3D com A e B como filhos diretos, nessa ordem. A tem size=(4,3,1), B=(2,2,1.4), ambos em Y=Z=0. B atravessa a profundidade de A. Câmera/luz estão instaladas.

F6 cria interface e instala subtração, B.x=0, consulta XY=(0,0) e use_collision=false. O controlador substitui esses parâmetros salvos na cena. Não há personagem, gravidade ou movimento automático. R restaura; A/D movem B.x em passos 0,25; 1/2/3 escolhem subtração/união/interseção; C centraliza, P separa B em X=4. Use V ou o botão para consultar um raio físico. Atalhos dependem de a interface não consumir a tecla; repetição/modificadores ignorados. Sem InputMap obrigatório.

## Geometria e física são verificações diferentes

O navegador mostra apenas a seção XY em Z=0 das mesmas caixas. Áreas A=12, B=4. Centralizadas, resultados sub/união/inter=8/12/4. Em B.x=1,5: sobreposição=3, resultados=9/13/3. Em B.x=4: sobreposição zero, resultados=12/16/0. Tangência B.x=3 tem área de interseção zero; não serve para provar tolerância/topologia do CSG real. O navegador mantém a grade nas regiões removidas, permite consulta de interior e trata pontos sobre limites separadamente. Sem física, importação, bake ou benchmark.

Na Godot, a consulta física vai de (X,Y,+4) a (X,Y,-4), corpos na camada 1. Com use_collision=false, não deve atingir o CSG. Ative a opção e consulte: em subtração central, XY=(0,0) atravessa a janela; XY=(1,5,0) deve atingir a faixa sólida. Aqui a vírgula decimal significa X=1.5 e Y=0. Em X=-5,Y=0, o cubo visual sem corpo não deve produzir contato. Aguarda process_frame/physics_frame e executa o acesso ao espaço em _physics_process; se parâmetros mudarem nessa espera, pede repetir. Testar no motor e registrar erros/avisos, sem considerar o resultado JS como aprovação.

use_collision comporta-se como corpo estático. Esconder o CSG não desliga sua colisão. Camadas, dimensões, consultas e a geometria completa precisam de conferência. Não usar isso como garantia de movimento de personagem ou corpo dinâmico.

## Importação

exemplos.glb é um fixture local gerado para a aula: quatro instâncias do mesmo cubo de aresta 1 e material simples, em X=-2,0,2,4. Não foi exportado do Blender. Sem imagens externas, rig ou animação. Abra na importação avançada e inspecione numa cena de trabalho, com reconhecimento de sufixos ativo:

- SuporteVisual: visual sem colisão solicitada pelo nome.
- Suporte-col: malha e colisão estática triangular.
- Suporte-convcol: malha e forma convexa, sem criar RigidBody3D por esse sufixo.
- Colisao-colonly: colisão sem malha visual original.

Os nomes podem ser processados pelo importador. -navmesh não é usado no fixture; converte malha em navegação e remove o visual original. Um casco convexo não preserva janela/reentrância. Formas côncavas triangulares destinam-se à geometria estática; corpos dinâmicos exigem configuração própria.

glTF 2.0 suporta .glb e .gltf; neste último, copie também dependências externas quando houver. .blend direto depende de Blender instalado/configurado para conversão. Para sua arte, exporte glTF 2.0 do Blender e confira escala, pivô, materiais e recursos suportados. O fixture não valida esse caminho externo. Evite editar dados gerados em .godot; use fonte/opções de importação e uma cena própria para alterações de jogo.

## Converter CSG

Faça numa cópia de oficina.tscn. Deixe a raiz na identidade e a combinação centralizada. CSG > Bake Mesh Instance cria visual estático como irmão; não esconde automaticamente o original. Bake Collision Shape é outra ação: coloque CollisionShape3D sob StaticBody3D com Transform coerente. Desative use_collision e esconda o original quando usar só a versão convertida. Teste janela/faixa sólida novamente. Esconder não equivale a desativar física. Se mudar a fonte CSG depois, refaça a versão convertida. Não há bake automático neste projeto.

CSG é destinado à prototipagem e reconstruções podem custar CPU. Este projeto não mede esse custo. O guia CSG 4.5 tem aviso de conteúdo em atualização; nomes do menu e fluxo precisam de conferência no editor real.

## Extensão opcional

Abra triangulo.tscn e use F6. triangulo.gd cria uma única face em _ready. Atributos são definidos antes dos vértices, com ordem horária vista de cima (+Y) e normal UP. A cena tem material, câmera/luz. Sem colisão e sem volume fechado: não é malha manifold para CSG. Conferir visibilidade/culling no motor.

