extends Node3D

@onready var csg: CSGCombiner3D = $Combinacao
@onready var recorte: CSGBox3D = $Combinacao/B
var operacao: OptionButton
var deslocamento: HSlider
var ponto_x: HSlider
var ponto_y: HSlider
var colisao: CheckBox
var leitura: Label
var retorno: Label
var ocupada := false
var revisao := 0
var raio_pendente: Dictionary = {}

func _ready() -> void:
    var layer := CanvasLayer.new()
    add_child(layer)
    var box := VBoxContainer.new()
    box.position = Vector2(16, 400)
    box.custom_minimum_size.x = 928
    layer.add_child(box)
    operacao = OptionButton.new()
    operacao.add_item("1: Subtracao A menos B", CSGShape3D.OPERATION_SUBTRACTION)
    operacao.add_item("2: Uniao A ou B", CSGShape3D.OPERATION_UNION)
    operacao.add_item("3: Intersecao A e B", CSGShape3D.OPERATION_INTERSECTION)
    operacao.item_selected.connect(func(_i: int): aplicar())
    box.add_child(operacao)
    var grid := GridContainer.new()
    grid.columns = 3
    box.add_child(grid)
    deslocamento = slider(grid, "Centro X de B", -4, 4, 0)
    ponto_x = slider(grid, "Consulta X", -5, 5, 0)
    ponto_y = slider(grid, "Consulta Y", -2, 2, 0)
    colisao = CheckBox.new()
    colisao.text = "Gerar colisao estatica na raiz CSG (use_collision)"
    colisao.toggled.connect(func(_on: bool): aplicar())
    box.add_child(colisao)
    var row := HBoxContainer.new()
    box.add_child(row)
    botao(row, "C: centralizar B", func(): deslocamento.value = 0)
    botao(row, "P: separar B", func(): deslocamento.value = 4)
    botao(row, "R: restaurar", restaurar)
    botao(row, "V: consultar raio fisico", consultar_raio)
    leitura = Label.new()
    leitura.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
    box.add_child(leitura)
    retorno = Label.new()
    retorno.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
    box.add_child(retorno)
    $Camera3D.position = Vector3(0, 1, 12)
    $Camera3D.look_at(Vector3(0, -2, 0), Vector3.UP)
    restaurar()

func slider(parent: Node, titulo: String, minimo: float, maximo: float, inicial: float) -> HSlider:
    var box := VBoxContainer.new()
    box.custom_minimum_size.x = 300
    parent.add_child(box)
    var label := Label.new()
    label.text = titulo
    box.add_child(label)
    var controle := HSlider.new()
    controle.min_value = minimo
    controle.max_value = maximo
    controle.step = 0.25
    controle.value = inicial
    controle.value_changed.connect(func(_v: float): aplicar())
    box.add_child(controle)
    return controle

func botao(parent: Node, texto: String, acao: Callable) -> void:
    var button := Button.new()
    button.text = texto
    button.pressed.connect(acao)
    parent.add_child(button)

func restaurar() -> void:
    operacao.select(0)
    deslocamento.set_value_no_signal(0)
    ponto_x.set_value_no_signal(0)
    ponto_y.set_value_no_signal(0)
    colisao.set_pressed_no_signal(false)
    aplicar()

func aplicar() -> void:
    if not is_instance_valid(leitura):
        return
    revisao += 1
    recorte.operation = operacao.get_selected_id()
    recorte.position.x = deslocamento.value
    csg.use_collision = colisao.button_pressed
    leitura.text = "A=4x3x1, B=2x2x1.4 | B.x=%.2f | consulta XY=(%.2f, %.2f) | colisao=%s" % [deslocamento.value, ponto_x.value, ponto_y.value, csg.use_collision]
    retorno.text = "Valores alterados: consulte novamente. Raio em Z de +4 a -4; camada 1. Sem personagem."

func consultar_raio() -> void:
    if ocupada:
        return
    ocupada = true
    var revisao_consultada := revisao
    # CSG atualiza dados de forma adiada; consultar depois da atualização visual/física.
    await get_tree().process_frame
    await get_tree().physics_frame
    if revisao_consultada != revisao:
        retorno.text = "Parametros mudaram durante a espera; consulte novamente."
        ocupada = false
        return
    var de := Vector3(ponto_x.value, ponto_y.value, 4)
    var ate := Vector3(ponto_x.value, ponto_y.value, -4)
    raio_pendente = {"de": de, "ate": ate, "revisao": revisao_consultada}

func _physics_process(_delta: float) -> void:
    if raio_pendente.is_empty():
        return
    var pedido := raio_pendente
    raio_pendente = {}
    if pedido.revisao != revisao:
        retorno.text = "Parametros mudaram antes da consulta; consulte novamente."
        ocupada = false
        return
    # Acesso ao espaço físico apenas no callback de física.
    var query := PhysicsRayQueryParameters3D.create(pedido.de, pedido.ate, 1)
    query.collide_with_bodies = true
    query.collide_with_areas = false
    var hit := get_world_3d().direct_space_state.intersect_ray(query)
    retorno.text = "Raio fisico: sem contato nesta consulta." if hit.is_empty() else "Raio fisico atingiu: %s em %s" % [hit.collider.name, hit.position]
    ocupada = false

func _unhandled_key_input(event: InputEvent) -> void:
    if not event is InputEventKey or not event.pressed or event.echo:
        return
    if event.ctrl_pressed or event.alt_pressed or event.meta_pressed:
        return
    match event.keycode:
        KEY_A: deslocamento.value -= 0.25
        KEY_D: deslocamento.value += 0.25
        KEY_1: operacao.select(0); aplicar()
        KEY_2: operacao.select(1); aplicar()
        KEY_3: operacao.select(2); aplicar()
        KEY_C: deslocamento.value = 0
        KEY_P: deslocamento.value = 4
        KEY_R: restaurar()
        KEY_V: consultar_raio()
        _: return
    get_viewport().set_input_as_handled()
