# Oficina — visibilidade, detalhe, agrupamento e medição

Referência Godot4.5/Forward+/desktop. Nove arquivos, malha própria peca.gltf com buffer embutido, sem assets externos. Compilação/importação/runtime ainda pendentes.

1. Importe project.godot. Selecione peca.gltf e confira geração de LOD no Import; reimporte se necessário. Mesh LOD nativo depende dessa importação, não é o corte manual do browser.
2. Execute oficina.tscn. Doze peças usam posições fixas. Câmera, parede visual, occluder e agrupamento são separados.
3. Mantenha câmera/resolução e compare12nós,3grupos e1grupo. O conjunto pode ficar visível por seu AABB mesmo com muitas peças fora da vista. Não espere o mesmo total de primitivas/calls que o modelo2D.
4. Compare Sem LOD, Mesh LOD e HLOD manual. O primeiro usa a esfera-fonte; o segundo usa índices gerados no import; o terceiro troca esfera por caixa nas faixas. Margens0/fade disabled são a referência, não uma promessa de transição imperceptível. Estude histerese e fades em extensão controlada.
5. O checkbox do occluder remove só a forma de oclusão. A parede permanece desenhada e o depth test ainda pode esconder sua parte traseira na imagem, mesmo com mais geometria enviada. O sistema de occlusion culling continua habilitado no projeto; custo global on/off exige outro teste/reinício.
6. Use alcance20u e observe que alcance de visibilidade não pausa física/scripts. No exemplo só há visual, sem física/IA individual.
7. Registre métricas após estabilizar, com mesma câmera, build, resolução e condições. O painel lê a cena inteira, incluindo piso/parede/UI. Process/física não são tempo GPU e FPS pode estar limitado por VSync. Use também profiler/visual profiler e o dispositivo alvo.

R restaura parâmetros; há sliders e botões. O browser também oferece A/D/W/S para o modelo; esses movimentos não são um controlador físico no projeto. Veja roteiro-testes.md. Não há benchmark de multidão, servidor, streaming ou orçamento aprovado.
