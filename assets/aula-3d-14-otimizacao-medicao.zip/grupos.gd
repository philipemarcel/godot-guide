extends RefCounted

static func criar(mesh: Mesh, pontos: Array, separado: bool) -> GeometryInstance3D:
    var centro := Vector3.ZERO
    for p in pontos:
        centro += p
    centro /= pontos.size()
    if separado:
        var no := MeshInstance3D.new()
        no.mesh = mesh
        no.position = centro
        return no
    var mm := MultiMesh.new()
    mm.transform_format = MultiMesh.TRANSFORM_3D # Antes de alocar instâncias.
    mm.mesh = mesh
    mm.instance_count = pontos.size()
    var limites := AABB(pontos[0] - centro - Vector3.ONE * 0.45, Vector3.ONE * 0.9)
    for i in range(pontos.size()):
        var local: Vector3 = pontos[i] - centro
        mm.set_instance_transform(i, Transform3D(Basis.IDENTITY, local))
        limites = limites.merge(AABB(local - Vector3.ONE * 0.45, Vector3.ONE * 0.9))
    mm.custom_aabb = limites
    var grupo := MultiMeshInstance3D.new()
    grupo.multimesh = mm
    grupo.position = centro
    return grupo

static func faixas(no: GeometryInstance3D, inicio: float, fim: float) -> void:
    no.visibility_range_begin = inicio
    no.visibility_range_end = fim
    no.visibility_range_begin_margin = 0.0
    no.visibility_range_end_margin = 0.0
    no.visibility_range_fade_mode = GeometryInstance3D.VISIBILITY_RANGE_FADE_DISABLED
    # Referência de corte seco. Estude histerese/margens antes de adotar no jogo.
