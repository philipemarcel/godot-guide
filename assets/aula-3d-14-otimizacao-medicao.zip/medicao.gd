extends RefCounted

static func ler() -> String:
    var fps := Performance.get_monitor(Performance.TIME_FPS)
    var processo_ms := Performance.get_monitor(Performance.TIME_PROCESS) * 1000.0
    var fisica_ms := Performance.get_monitor(Performance.TIME_PHYSICS_PROCESS) * 1000.0
    var chamadas := Performance.get_monitor(Performance.RENDER_TOTAL_DRAW_CALLS_IN_FRAME)
    var primitivas := Performance.get_monitor(Performance.RENDER_TOTAL_PRIMITIVES_IN_FRAME)
    var memoria_mib := Performance.get_monitor(Performance.RENDER_VIDEO_MEM_USED) / 1048576.0
    return "FPS %.0f | process %.2f ms | física %.2f ms\nDraw calls/frame %.0f | índices/vértices reportados %.0f | memória reportada %.1f MiB\nMétricas da cena inteira, incluindo piso/parede/UI; não apenas as 12 peças.\nAlguns monitores atrasam até 1 s ou não estão disponíveis em todo build.\nProcess/física não são tempo GPU; usar profiler e hardware alvo." % [fps, processo_ms, fisica_ms, chamadas, primitivas, memoria_mib]
