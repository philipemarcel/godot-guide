# Homologação pendente — registrar ambiente e evidências

- [ ] Importar glTF e compilar os três scripts; mesh fonte2208triângulos, normais/índices válidos.
- [ ] Conferir Generate LODs/reimport, índices simplificados e comportamento de mesh_lod_threshold0/1.
- [ ] Cena inicial/câmera e12peças nas posições corretas; sliders/R preservam referência.
- [ ] Occluder menor que a parede; testar formas/arestas, objeto parcialmente visível e root setting.
- [ ] Comparar recurso occluder removido versus sistema desligado/reiniciado; não confundir CPU overhead.
- [ ] Grupos12/3/1 com transform_format antes da alocação, AABB completo e nenhuma instância perdida.
- [ ] MultiMesh global pode enviar geometria desnecessária; medir tradeoff sem prometer1call em todos os passes.
- [ ] HLOD perto/longe, alcance20 e fronteiras; depois testar histerese e custo/compatibilidade de fade.
- [ ] Painel0.5s/monitores: valores podem atrasar ou faltar no build; zero não comprova custo nulo.
- [ ] Comparações CPU/GPU, VSync, warm-up, resolução, export debug/release e tempo por frame.
- [ ] Console, foco, interface e repetição de trocas/R sem nós/ciclos antigos.
- [ ] Validar qualidade visual: silhueta/popping/sombras/aberturas; otimização não é aprovada só por reduzir um contador.

Aprofundamentos candidatos: HLOD hierárquico/dependências, instancing com materiais/passes, streaming espacial, profiler avançado e orçamento por plataforma. Não são recursos prontos deste apoio.
