extends Node3D
const GRUPOS = preload("res://grupos.gd")
const MEDICAO = preload("res://medicao.gd")
var mesh_alta: Mesh
var mesh_baixa: BoxMesh
var camera: Camera3D
var colecao: Node3D
var bloqueador: OccluderInstance3D
var caixa_oclusao: BoxOccluder3D
var painel: VBoxContainer
var giro: HSlider
var posicao: HSlider
var agrupamento: OptionButton
var detalhe: OptionButton
var alcance: CheckButton
var oclusao: CheckButton
var leitura: Label

func slider(texto: String, minimo: float, maximo: float, passo: float, valor: float) -> HSlider:
    var l := Label.new()
    l.text = texto
    painel.add_child(l)
    var s := HSlider.new()
    s.min_value = minimo
    s.max_value = maximo
    s.step = passo
    s.value = valor
    painel.add_child(s)
    s.value_changed.connect(func(_v: float): atualizar_camera())
    return s

func caixa(nome: String, tamanho: Vector3, pos: Vector3) -> void:
    var m := MeshInstance3D.new()
    m.name = nome
    var box := BoxMesh.new()
    box.size = tamanho
    m.mesh = box
    m.position = pos
    add_child(m)

func _ready() -> void:
    var importada: PackedScene = load("res://peca.gltf")
    var instancia := importada.instantiate()
    var meshes := instancia.find_children("*", "MeshInstance3D", true, false)
    if instancia is MeshInstance3D:
        mesh_alta = instancia.mesh
    elif not meshes.is_empty():
        mesh_alta = (meshes[0] as MeshInstance3D).mesh
    instancia.free()
    if mesh_alta == null:
        push_error("Mesh importada não encontrada; confira peca.gltf e Import/Generate LODs.")
        return
    mesh_baixa = BoxMesh.new()
    mesh_baixa.size = Vector3.ONE * 0.9
    colecao = Node3D.new()
    colecao.name = "Grupos"
    add_child(colecao)
    caixa("ParedeVisual", Vector3(0.4, 3, 6), Vector3(10, 1.5, 0))
    caixa("Piso", Vector3(28, 0.2, 18), Vector3(12, -0.1, 0))
    bloqueador = OccluderInstance3D.new()
    bloqueador.position = Vector3(10, 1.5, 0)
    caixa_oclusao = BoxOccluder3D.new()
    caixa_oclusao.size = Vector3(0.35, 2.9, 5.9)
    bloqueador.occluder = caixa_oclusao
    add_child(bloqueador)
    camera = Camera3D.new()
    camera.keep_aspect = Camera3D.KEEP_WIDTH
    camera.fov = 70
    camera.near = 1
    camera.far = 26
    camera.current = true
    add_child(camera)
    var luz := DirectionalLight3D.new()
    luz.rotation_degrees = Vector3(-45, -30, 0)
    luz.shadow_enabled = false # Sombras adicionariam outros passes à comparação.
    add_child(luz)
    var mundo := WorldEnvironment.new()
    var e := Environment.new()
    e.background_mode = Environment.BG_COLOR
    e.background_color = Color(0.04, 0.03, 0.02)
    e.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
    e.ambient_light_color = Color.WHITE
    e.ambient_light_energy = 0.35
    mundo.environment = e
    add_child(mundo)
    interface()
    restaurar()
    var relogio := Timer.new()
    relogio.wait_time = 0.5
    relogio.timeout.connect(func(): leitura.text = MEDICAO.ler())
    add_child(relogio)
    relogio.start()

func interface() -> void:
    var layer := CanvasLayer.new()
    add_child(layer)
    var fundo := PanelContainer.new()
    fundo.position = Vector2(20, 550)
    layer.add_child(fundo)
    painel = VBoxContainer.new()
    painel.custom_minimum_size.x = 690
    fundo.add_child(painel)
    giro = slider("Giro da câmera em graus", -60, 60, 5, 0)
    posicao = slider("Posição X da câmera", 0, 4, 0.5, 0)
    agrupamento = OptionButton.new()
    for texto in ["12 nós separados", "3 MultiMeshes por coluna", "1 MultiMesh global"]:
        agrupamento.add_item(texto)
    painel.add_child(agrupamento)
    agrupamento.item_selected.connect(func(_i: int): reconstruir())
    detalhe = OptionButton.new()
    for texto in ["Sem LOD", "Mesh LOD da importação", "HLOD manual: esfera perto/caixa longe"]:
        detalhe.add_item(texto)
    painel.add_child(detalhe)
    detalhe.item_selected.connect(func(_i: int): reconstruir())
    alcance = CheckButton.new()
    alcance.text = "Alcance final 20 u, sem fade (referência)"
    painel.add_child(alcance)
    alcance.toggled.connect(func(_v: bool): reconstruir())
    oclusao = CheckButton.new()
    oclusao.text = "Occluder ativo; parede visual permanece"
    painel.add_child(oclusao)
    oclusao.toggled.connect(func(ativo: bool): bloqueador.occluder = caixa_oclusao if ativo else null)
    var reset := Button.new()
    reset.text = "Restaurar referência · R"
    painel.add_child(reset)
    reset.pressed.connect(restaurar)
    leitura = Label.new()
    painel.add_child(leitura)

func atualizar_camera() -> void:
    if posicao == null or giro == null:
        return
    camera.position = Vector3(posicao.value, 1.5, 0)
    camera.rotation.y = -PI / 2.0 - deg_to_rad(giro.value)

func reconstruir() -> void:
    if alcance == null:
        return
    for filho in colecao.get_children():
        filho.free()
    var limiar := 1.0 if detalhe.selected == 1 else 0.0
    ProjectSettings.set_setting("rendering/mesh_lod/lod_change/threshold_pixels", limiar)
    get_viewport().mesh_lod_threshold = limiar
    var pontos: Array = []
    for x in [8.0, 14.0, 20.0]:
        for z in [-6.0, -2.0, 2.0, 6.0]:
            pontos.append(Vector3(x, 0.45, z))
    var grupos: Array = []
    if agrupamento.selected == 0:
        for p in pontos:
            grupos.append([p])
    elif agrupamento.selected == 1:
        for i in range(3):
            grupos.append(pontos.slice(i * 4, i * 4 + 4))
    else:
        grupos.append(pontos)
    var material := StandardMaterial3D.new()
    material.albedo_color = Color(0.65, 0.38, 0.13)
    for grupo in grupos:
        var alta := GRUPOS.criar(mesh_alta, grupo, agrupamento.selected == 0)
        alta.material_override = material
        colecao.add_child(alta)
        var limite := 20.0 if alcance.button_pressed else 0.0
        GRUPOS.faixas(alta, 0.0, 16.0 if detalhe.selected == 2 else limite)
        if detalhe.selected == 2:
            var baixa := GRUPOS.criar(mesh_baixa, grupo, agrupamento.selected == 0)
            baixa.material_override = material
            colecao.add_child(baixa)
            GRUPOS.faixas(baixa, 16.0, limite)
    # Recriação só ao trocar estratégia. Aguarde estabilizar antes de registrar métricas.

func restaurar() -> void:
    giro.set_value_no_signal(0)
    posicao.set_value_no_signal(0)
    agrupamento.select(0)
    detalhe.select(1)
    alcance.set_pressed_no_signal(false)
    oclusao.set_pressed_no_signal(true)
    bloqueador.occluder = caixa_oclusao
    atualizar_camera()
    reconstruir()

func _unhandled_key_input(event: InputEvent) -> void:
    if event is InputEventKey and event.pressed and not event.echo and not event.ctrl_pressed and not event.alt_pressed and not event.meta_pressed:
        if event.keycode == KEY_R:
            restaurar()
