# Aula 15 — duas salas, o mesmo jogador

Referência: Godot 4.5, Compatibility. Projeto revisado documentalmente; ainda não executado no motor neste ambiente. Importe project.godot e execute oficina.tscn com F6. Os nós persistentes e a interface são criados por oficina.gd; as salas são cenas passivas sem scripts.

L solicita; A aplica; D desiste da troca; C ganha 1 moeda; R restaura sala A e 10 moedas. Há botões equivalentes, sem InputMap. A e B têm Marker2D Entrada em posições diferentes. Anote ID do jogador e moedas antes de trocar; ambos devem persistir. Não há movimento ou física nesta prática.

Use Sem Entrada e Raiz incompatível para rejeição após instantiate. Gradiente é um Resource que não é PackedScene. Caminho ausente aponta deliberadamente a inexistente.tscn, arquivo que não deve ser criado: a recusa pode ocorrer no pedido ou como status de falha. Em todos esses casos a sala atual deve ser preservada.

100% se refere ao recurso, não à instalação. Arquivos pequenos ou em cache podem terminar imediatamente. Não adicione busy waits para mostrar uma barra lenta. Instanciar e adicionar nós ainda pode causar engasgos no thread principal. O marcador giratório não mede FPS.

Desistir durante carregamento apenas marca abandono: o carregador acompanha o pedido até terminar e descarta o resultado. Não cancela a tarefa. Novo pedido e reinício aguardam o estado terminal. Desistir quando preparado apenas solta a referência. Não use threads para manipular indiscriminadamente a árvore ativa.

O jogador é irmão de ContainerSala, não filho da sala. Sua persistência não depende de Autoload nesta arquitetura. A troca valida tipo do recurso, tipo de raiz e caminho direto Entrada antes de remover a sala antiga; não é uma transação que desfaz efeitos arbitrários de _init ou _ready. Faça testes extras se adicionar scripts às salas.

Extensão opcional: ao fim de _ready em oficina.gd, crie e instale o medidor em linhas separadas:

```gdscript
var meter = preload("res://medidor.gd").new()
meter.position = Vector2(16, 650)
add_child(meter)
meter.configurar(player)
```

Compare configurar(player) com procurar_por_grupo(). Para o segundo, remova o grupo do jogador ou adicione um segundo Node2D ao grupo antes da procura. O método exige exatamente um candidato Node2D e recusa zero/duplicados. O medidor não é instalado por padrão. Ele precisa de nova configuração se a identidade do jogador mudar.

Checklist no motor, ainda pendente: importar sem erros; rodar A/B; preservar ID e moedas; repetir; testar quatro destinos inválidos; desistir preparado; testar abandono durante pedido se observável; restaurar; testar medidor com zero/um/dois candidatos. O modelo JS do site não comprova esses resultados no motor.
