extends Label
# Extensão opcional; configure uma referência explícita antes de usar.
var alvo: Node2D

func configurar(node: Node2D) -> void:
    alvo = node

func procurar_por_grupo() -> bool:
    var matches := get_tree().get_nodes_in_group("jogador")
    if matches.size() != 1 or not matches[0] is Node2D:
        alvo = null
        text = "Esperado exatamente um Node2D no grupo jogador."
        return false
    configurar(matches[0] as Node2D)
    return true

func _process(_delta: float) -> void:
    if not is_instance_valid(alvo):
        text = "Sem referência válida. Configure ou faça a busca explicitamente."
        return
    text = "ID observado: %d | posição global: %s" % [alvo.get_instance_id(), str(alvo.global_position)]
