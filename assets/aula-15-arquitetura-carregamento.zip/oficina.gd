extends Node2D

const LOADER = preload("res://carregador.gd")
const INITIAL = preload("res://sala_a.tscn")
const TARGETS := {
    "Sala A": "res://sala_a.tscn", "Sala B": "res://sala_b.tscn",
    "Sem Entrada": "res://sala_sem_entrada.tscn",
    "Raiz incompatível": "res://raiz_control.tscn",
    "Recurso não é cena": "res://gradiente.tres",
    "Caminho ausente": "res://inexistente.tscn"
}
var loader: CarregadorSala
var world: Node2D
var player: Node2D
var room: Node2D
var pending: PackedScene
var choices: OptionButton
var bar: ProgressBar
var message: Label
var stats: Label
var load_button: Button
var apply_button: Button
var discard_button: Button
var reset_button: Button
var coins: int = 10
var spin: float = 0.0

func _ready() -> void:
    world = Node2D.new()
    world.name = "ContainerSala"
    add_child(world)
    player = Node2D.new()
    player.name = "Jogador"
    player.add_to_group("jogador")
    var art := Polygon2D.new()
    art.polygon = PackedVector2Array([Vector2(0,-14), Vector2(14,0), Vector2(0,14), Vector2(-14,0)])
    art.color = Color("5ce1e6")
    player.add_child(art)
    add_child(player)
    loader = LOADER.new()
    add_child(loader)
    loader.progresso_alterado.connect(func(ratio: float): bar.value = ratio * 100.0)
    loader.preparado.connect(_preparado)
    loader.falhou.connect(_falhou)
    loader.descartado.connect(func(): message.text = "Resultado descartado. Você pode solicitar outra sala.")
    criar_interface()
    pending = INITIAL
    aplicar()

func criar_interface() -> void:
    var layer := CanvasLayer.new()
    add_child(layer)
    var box := VBoxContainer.new()
    box.position = Vector2(16, 315)
    box.custom_minimum_size.x = 608
    layer.add_child(box)
    choices = OptionButton.new()
    for label in TARGETS:
        choices.add_item(label)
        choices.set_item_metadata(choices.item_count - 1, TARGETS[label])
    choices.select(1)
    box.add_child(choices)
    load_button = botao(box, "L · Solicitar carregamento", solicitar)
    apply_button = botao(box, "A · Aplicar sala preparada", aplicar)
    discard_button = botao(box, "D · Desistir da troca", desistir)
    botao(box, "C · Ganhar 1 moeda", ganhar_moeda)
    reset_button = botao(box, "R · Reiniciar experimento", reiniciar)
    bar = ProgressBar.new()
    bar.max_value = 100
    box.add_child(bar)
    message = Label.new()
    message.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
    box.add_child(message)
    stats = Label.new()
    stats.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
    box.add_child(stats)

func botao(parent: Node, text: String, action: Callable) -> Button:
    var button := Button.new()
    button.text = text
    button.pressed.connect(action)
    parent.add_child(button)
    return button

func _process(delta: float) -> void:
    spin += delta * 2.0
    queue_redraw()
    var busy := loader.ocupado
    load_button.disabled = busy or pending != null
    apply_button.disabled = busy or pending == null
    discard_button.disabled = (not busy and pending == null) or loader.abandonado
    reset_button.disabled = busy
    choices.disabled = busy or pending != null
    stats.text = "Moedas: %d | ID do jogador: %d | sala: %s" % [coins, player.get_instance_id(), room.name]

func _draw() -> void:
    var center := Vector2(600, 28)
    draw_circle(center, 12, Color("5b3f22"))
    draw_line(center, center + Vector2.from_angle(spin) * 11, Color("f4d088"), 3)

func solicitar() -> void:
    if loader.ocupado or pending != null:
        return
    bar.value = 0
    var path := str(choices.get_item_metadata(choices.selected))
    var error := loader.solicitar(path)
    message.text = "Carregando o recurso..." if error == OK else "Pedido recusado: " + error_string(error)

func _preparado(scene: PackedScene) -> void:
    pending = scene
    message.text = "Recurso carregado (100%). Ainda falta instanciar e aplicar a sala."

func _falhou(text: String) -> void:
    pending = null
    message.text = text

func desistir() -> void:
    if loader.ocupado:
        loader.desistir_da_troca()
        message.text = "Troca abandonada; aguardando a tarefa terminar para descartar o resultado."
    elif pending != null:
        pending = null
        message.text = "Cena preparada descartada. Sala atual preservada."

func aplicar() -> void:
    if loader.ocupado or pending == null:
        return
    var candidate := pending.instantiate()
    pending = null
    if not candidate is Node2D:
        if candidate != null:
            candidate.free()
        message.text = "A raiz precisa ser Node2D. Sala atual preservada."
        return
    var entry := candidate.get_node_or_null("Entrada") as Marker2D
    if entry == null:
        candidate.free()
        message.text = "Falta Marker2D Entrada. Sala atual preservada."
        return
    # Estes fixtures são passivos; não executam efeitos de _ready na validação.
    if is_instance_valid(room):
        world.remove_child(room)
        room.queue_free()
    room = candidate as Node2D
    world.add_child(room)
    player.global_position = entry.global_position
    message.text = "Sala aplicada; o mesmo jogador e suas moedas foram preservados."

func ganhar_moeda() -> void:
    coins = mini(999, coins + 1)

func reiniciar() -> void:
    if loader.ocupado:
        message.text = "Desista e aguarde a tarefa terminar antes de reiniciar."
        return
    coins = 10
    pending = INITIAL
    aplicar()
    bar.value = 0

func _unhandled_key_input(event: InputEvent) -> void:
    if not event is InputEventKey or not event.pressed or event.echo:
        return
    if event.ctrl_pressed or event.alt_pressed or event.meta_pressed:
        return
    match event.keycode:
        KEY_L: solicitar()
        KEY_A: aplicar()
        KEY_D: desistir()
        KEY_C: ganhar_moeda()
        KEY_R: reiniciar()
