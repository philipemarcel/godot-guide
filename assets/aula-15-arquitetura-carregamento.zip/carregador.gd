class_name CarregadorSala
extends Node

signal progresso_alterado(ratio: float)
signal preparado(scene: PackedScene)
signal falhou(message: String)
signal descartado

var ocupado: bool = false
var abandonado: bool = false
var caminho: String = ""

func solicitar(path: String) -> Error:
    if ocupado:
        return ERR_BUSY
    var error := ResourceLoader.load_threaded_request(path)
    if error != OK:
        return error
    caminho = path
    ocupado = true
    abandonado = false
    progresso_alterado.emit(0.0)
    return OK

func desistir_da_troca() -> void:
    # Não cancela a thread: continuamos consultando até um estado terminal.
    if ocupado:
        abandonado = true

func _process(_delta: float) -> void:
    if not ocupado:
        return
    var progress: Array = []
    var status := ResourceLoader.load_threaded_get_status(caminho, progress)
    match status:
        ResourceLoader.THREAD_LOAD_IN_PROGRESS:
            if not progress.is_empty():
                progresso_alterado.emit(clampf(float(progress[0]), 0.0, 1.0))
        ResourceLoader.THREAD_LOAD_LOADED:
            # Só fazemos get depois de LOADED para evitar esperar pela thread aqui.
            var resource := ResourceLoader.load_threaded_get(caminho)
            ocupado = false
            caminho = ""
            if abandonado:
                abandonado = false
                descartado.emit()
            elif resource is PackedScene:
                progresso_alterado.emit(1.0)
                preparado.emit(resource)
            else:
                falhou.emit("O recurso carregado não é PackedScene.")
        ResourceLoader.THREAD_LOAD_FAILED, ResourceLoader.THREAD_LOAD_INVALID_RESOURCE:
            ocupado = false
            caminho = ""
            abandonado = false
            falhou.emit("Falha ou requisição inválida. Sala atual preservada.")
