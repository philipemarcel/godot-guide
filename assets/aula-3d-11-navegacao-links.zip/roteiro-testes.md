# Validação real pendente

Registrar versão, renderizador, mensagens, esperado/observado e evidência em cada item. Não preencher sem executar.

- [ ] Importar/compilar os três scripts, sem erros de tipo, enum, propriedade ou path.
- [ ] Confirmar duas ilhas no bake; parsing só dos pisos, células compatíveis e polígonos >0.
- [ ] Conferir bake_finished e sincronização antes da primeira consulta; sem resultado vazio transitório tratado como chegada.
- [ ] R: uma atribuição do destino por comando; seguir XZ com gravidade Y; chegar sem oscilação.
- [ ] Link bidirecional/executor: receber owner/entry/exit, suspender seguidor, percorrer arco e retomar. Sem consulta recursiva no sinal.
- [ ] Link off: parar no fim alcançável e não declarar alvo alcançado.
- [ ] One-way: permitir esquerda→direita e negar direita→esquerda.
- [ ] Link on/executor off: parar na entrada sem andar sobre o fosso.
- [ ] C/R durante seguir/travessia e após chegada; repetir dez vezes sem estado anterior reaparecer.
- [ ] B com raios0,2/0,4/1,2: confirmar nova malha/custo e distância ponta-polígono. Não tomar o retângulo web por resultado Recast.
- [ ] Alterações rápidas durante bake/sincronização: opções visíveis iguais às aplicadas; impedir concorrência e corrigir divergências.
- [ ] Colisor extra na travessia: abortar com mensagem; queda abaixo de-5 e recuperação por C/R.
- [ ] Confirmar que raio avoidance não muda bake/cápsula; RVO permanece desligado.
- [ ] Teclado sem capturar opções/sliders, texto legível, foco e janela estreita.
- [ ] Medir parsing/bake em cena maior antes de prometer fluidez; este cenário não mede desempenho.

Pendências de aprofundamento para avaliação curricular final: ramps/escadas e limites do controlador, avoidance com velocity_computed e múltiplos agentes, destino móvel com limiar/cadência, bake por setores, elevadores, salto balístico e recuperação de links dinâmicos. Não são recursos implementados aqui.
