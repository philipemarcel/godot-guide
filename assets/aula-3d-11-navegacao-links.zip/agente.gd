extends CharacterBody3D
var nav: NavigationAgent3D
var estado := "parado"
var executor := true
var pendente: Dictionary = {}
var inicio := Vector3.ZERO
var fim := Vector3.ZERO
var tempo := 0.0
var mensagem := "Aguardando mapa."
const VELOCIDADE := 2.0
const DURACAO := 1.2

func _ready() -> void:
    nav = NavigationAgent3D.new()
    nav.name = "NavigationAgent3D"
    nav.navigation_layers = 1
    nav.path_desired_distance = 0.2
    nav.target_desired_distance = 0.2
    nav.path_max_distance = 3.0
    nav.path_metadata_flags = NavigationPathQueryParameters3D.PATH_METADATA_INCLUDE_ALL
    nav.avoidance_enabled = false
    nav.radius = 0.3 # Apenas avoidance; NÃO muda o bake nem a cápsula.
    nav.debug_enabled = true
    add_child(nav)
    nav.link_reached.connect(_link_reached)
    var col := CollisionShape3D.new()
    var shape := CapsuleShape3D.new()
    shape.radius = 0.3
    shape.height = 1.6
    col.shape = shape
    col.position.y = 0.8
    add_child(col)
    var mesh := MeshInstance3D.new()
    var capsule := CapsuleMesh.new()
    capsule.radius = 0.3
    capsule.height = 1.6
    mesh.mesh = capsule
    mesh.position.y = 0.8
    add_child(mesh)

func preparar(origem: Vector3, alvo: Vector3, com_executor: bool) -> void:
    estado = "parado"
    pendente.clear()
    global_position = origem
    velocity = Vector3.ZERO
    executor = com_executor
    tempo = 0.0
    nav.target_position = alvo # Uma atribuição por comando, não por frame.
    mensagem = "Pronto. Iniciar/repetir libera o movimento."

func _link_reached(detalhes: Dictionary) -> void:
    # Só guarda metadados. Não consultar caminho dentro do callback.
    pendente = detalhes.duplicate()

func _physics_process(delta: float) -> void:
    if estado == "travessia":
        tempo = minf(DURACAO, tempo + delta)
        var u := tempo / DURACAO
        var desejado := inicio.lerp(fim, u) + Vector3.UP * (1.2 * sin(PI * u))
        var colisao := move_and_collide(desejado - global_position)
        if colisao != null:
            estado = "parado"
            mensagem = "Travessia bloqueada por colisão; reinicie e inspecione."
        elif u >= 1.0:
            estado = "seguir"
            velocity = Vector3.ZERO
        return
    velocity.x = 0.0
    velocity.z = 0.0
    if not is_on_floor():
        velocity += get_gravity() * delta
    if estado == "seguir":
        var mapa := nav.get_navigation_map()
        if NavigationServer3D.map_get_iteration_id(mapa) == 0:
            mensagem = "Mapa ainda não sincronizado."
        elif nav.is_navigation_finished():
            estado = "parado"
            mensagem = "Alvo alcançado." if nav.is_target_reached() else "Fim alcançável; alvo não alcançado."
        else:
            var proximo := nav.get_next_path_position() # Uma consulta por passo físico ativo.
            if not pendente.is_empty():
                if not executor:
                    estado = "parado"
                    mensagem = "Link encontrado; sem executor de travessia."
                elif pendente.has("link_exit_position"):
                    inicio = global_position
                    fim = pendente["link_exit_position"]
                    # Os pisos desta oficina têm superfície y=0; só este cenário é suportado.
                    fim.y = 0.0
                    tempo = 0.0
                    velocity = Vector3.ZERO
                    estado = "travessia"
                    mensagem = "Controlador executando arco; não é impulso balístico."
                else:
                    estado = "parado"
                    mensagem = "Metadados de saída ausentes; conferir owner/flags."
                pendente.clear()
                return
            var diferenca := proximo - global_position
            diferenca.y = 0.0
            var direcao := diferenca.normalized()
            var rapidez := minf(VELOCIDADE, diferenca.length() / maxf(delta, 0.0001))
            velocity.x = direcao.x * rapidez
            velocity.z = direcao.z * rapidez
            mensagem = "Seguindo caminho; gravidade separada do plano XZ."
    move_and_slide() # Também parado ou sem caminho: gravidade não fica suspensa.
    if global_position.y < -5.0:
        estado = "parado"
        mensagem = "Queda detectada; reinicie e confira bake/colisão/travessia."
