extends RefCounted

static func caixa(pai: Node3D, nome: String, centro: Vector3, tamanho: Vector3) -> void:
    var corpo := StaticBody3D.new()
    corpo.name = nome
    corpo.position = centro
    corpo.collision_layer = 1
    pai.add_child(corpo)
    var forma := CollisionShape3D.new()
    var box := BoxShape3D.new()
    box.size = tamanho
    forma.shape = box
    corpo.add_child(forma)
    var visual := MeshInstance3D.new()
    var malha := BoxMesh.new()
    malha.size = tamanho
    visual.mesh = malha
    var material := StandardMaterial3D.new()
    material.albedo_color = Color(0.35, 0.25, 0.12)
    visual.material_override = material
    corpo.add_child(visual)

static func criar(pai: Node3D) -> NavigationRegion3D:
    var regiao := NavigationRegion3D.new()
    regiao.name = "Regiao"
    regiao.navigation_layers = 1
    var malha := NavigationMesh.new()
    malha.cell_size = 0.1
    malha.cell_height = 0.1
    malha.agent_radius = 0.4
    malha.agent_height = 1.8
    malha.agent_max_climb = 0.25
    malha.agent_max_slope = 45.0
    malha.geometry_parsed_geometry_type = NavigationMesh.PARSED_GEOMETRY_STATIC_COLLIDERS
    malha.geometry_collision_mask = 1
    malha.region_min_size = 0.0
    regiao.navigation_mesh = malha
    pai.add_child(regiao)
    caixa(regiao, "PisoEsquerdo", Vector3(-3.5, -0.25, 0), Vector3(5, 0.5, 4))
    caixa(regiao, "PisoDireito", Vector3(3.5, -0.25, 0), Vector3(5, 0.5, 4))
    return regiao
