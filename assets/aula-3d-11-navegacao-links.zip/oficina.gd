extends Node3D
const CENARIO = preload("res://cenario.gd")
const AGENTE = preload("res://agente.gd")
var regiao: NavigationRegion3D
var ator
var link: NavigationLink3D
var painel: VBoxContainer
var leitura: Label
var raio: HSlider
var modo: OptionButton
var sentido: CheckButton
var executor: CheckButton
var sincronizando := false
var iteracao_anterior := 0
var tempo_espera := 0.0
var pronto := false

func botao(texto: String, acao: Callable) -> void:
    var b := Button.new()
    b.text = texto
    painel.add_child(b)
    b.pressed.connect(acao)

func _ready() -> void:
    regiao = CENARIO.criar(self)
    regiao.bake_finished.connect(_bake_finished)
    link = NavigationLink3D.new()
    link.name = "Travessia"
    link.start_position = Vector3(-2, 0, 0)
    link.end_position = Vector3(2, 0, 0)
    link.navigation_layers = 1
    add_child(link)
    ator = CharacterBody3D.new()
    ator.name = "Automato"
    ator.position = Vector3(-4, 0, 0)
    ator.set_script(AGENTE)
    add_child(ator)
    var camera := Camera3D.new()
    camera.position = Vector3(0, 12, 12)
    add_child(camera)
    camera.look_at(Vector3.ZERO)
    camera.make_current()
    var luz := DirectionalLight3D.new()
    luz.rotation_degrees = Vector3(-55, -25, 0)
    add_child(luz)
    var mundo := WorldEnvironment.new()
    var ambiente := Environment.new()
    ambiente.background_mode = Environment.BG_COLOR
    ambiente.background_color = Color(0.04, 0.03, 0.02)
    ambiente.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
    ambiente.ambient_light_color = Color.WHITE
    ambiente.ambient_light_energy = 0.4
    mundo.environment = ambiente
    add_child(mundo)
    interface()
    call_deferred("assar")

func interface() -> void:
    var layer := CanvasLayer.new()
    add_child(layer)
    var fundo := PanelContainer.new()
    fundo.position = Vector2(24, 24)
    layer.add_child(fundo)
    painel = VBoxContainer.new()
    painel.custom_minimum_size.x = 460
    fundo.add_child(painel)
    var titulo := Label.new()
    titulo.text = "ROTA, LINK E TRAVESSIA — GODOT 4.5"
    painel.add_child(titulo)
    var ajuda := Label.new()
    ajuda.text = "Raio solicitado: aplicar exige bake; 0,4 é a referência.\nMudanças de link/sentido/executor param e sincronizam.\nB: bake · R: iniciar/repetir · C: parar e restaurar posição"
    painel.add_child(ajuda)
    raio = HSlider.new()
    raio.min_value = 0.2
    raio.max_value = 1.2
    raio.step = 0.1
    raio.value = 0.4
    painel.add_child(raio)
    modo = OptionButton.new()
    for nome in ["Link bidirecional", "Só esquerda → direita", "Link desligado"]:
        modo.add_item(nome)
    painel.add_child(modo)
    modo.item_selected.connect(func(_i: int): atualizar_link())
    sentido = CheckButton.new()
    sentido.text = "Inverter origem/destino"
    painel.add_child(sentido)
    sentido.toggled.connect(func(_v: bool): atualizar_link())
    executor = CheckButton.new()
    executor.text = "Executor de travessia presente"
    executor.button_pressed = true
    painel.add_child(executor)
    executor.toggled.connect(func(_v: bool): atualizar_link())
    botao("Aplicar raio e fazer bake · B", assar)
    botao("Iniciar / repetir percurso · R", iniciar)
    botao("Parar e restaurar posição · C", restaurar)
    leitura = Label.new()
    leitura.custom_minimum_size.x = 460
    leitura.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
    painel.add_child(leitura)

func assar() -> void:
    if regiao.is_baking() or sincronizando:
        return
    pronto = false
    ator.estado = "parado"
    iteracao_anterior = NavigationServer3D.map_get_iteration_id(ator.nav.get_navigation_map())
    regiao.navigation_mesh.agent_radius = raio.value
    ator.mensagem = "Bake solicitado; aguarde sinal e sincronização."
    regiao.bake_navigation_mesh(true)

func _bake_finished() -> void:
    aguardar_mapa()

func aguardar_mapa() -> void:
    pronto = false
    ator.estado = "parado"
    tempo_espera = 0.0
    sincronizando = true

func atualizar_link() -> void:
    if regiao.is_baking() or sincronizando:
        ator.mensagem = "Aguarde terminar e reaplique a opção."
        return
    var habilitado := modo.selected != 2
    var duplo := modo.selected == 0
    if link.enabled != habilitado or link.bidirectional != duplo:
        iteracao_anterior = NavigationServer3D.map_get_iteration_id(ator.nav.get_navigation_map())
        link.enabled = habilitado
        link.bidirectional = duplo
        aguardar_mapa()
    else:
        restaurar() # Sentido/executor não alteram o mapa.

func restaurar() -> void:
    if not pronto:
        return
    var sinal := -1.0 if sentido.button_pressed else 1.0
    ator.preparar(Vector3(-4 * sinal, 0, 0), Vector3(4 * sinal, 0, 0), executor.button_pressed)

func iniciar() -> void:
    if pronto:
        restaurar()
        ator.estado = "seguir"

func _physics_process(delta: float) -> void:
    if sincronizando:
        tempo_espera += delta
        var atual := NavigationServer3D.map_get_iteration_id(ator.nav.get_navigation_map())
        if atual != 0 and atual != iteracao_anterior:
            sincronizando = false
            pronto = regiao.navigation_mesh.get_polygon_count() > 0
            if pronto:
                restaurar()
            else:
                ator.mensagem = "Bake sem polígonos; confira fontes e parâmetros."
        elif tempo_espera > 5.0:
            ator.mensagem = "Sincronização ainda pendente; inspecione o mapa e os avisos."
    var ocupado := regiao.is_baking() or sincronizando
    modo.disabled = ocupado
    sentido.disabled = ocupado
    executor.disabled = ocupado
    raio.editable = not ocupado
    if leitura != null:
        leitura.text = "Pedido %.1f / recurso %.1f | polígonos %d\n%s\nEstado: %s | posição %s\nMudança de raio só vale após novo bake. Sem avoidance/RVO." % [raio.value, regiao.navigation_mesh.agent_radius, regiao.navigation_mesh.get_polygon_count(), ator.mensagem, ator.estado, ator.global_position]

func _unhandled_key_input(event: InputEvent) -> void:
    if event is InputEventKey and event.pressed and not event.echo and not event.ctrl_pressed and not event.alt_pressed and not event.meta_pressed:
        if event.keycode == KEY_B:
            assar()
        elif event.keycode == KEY_R:
            iniciar()
        elif event.keycode == KEY_C:
            restaurar()
