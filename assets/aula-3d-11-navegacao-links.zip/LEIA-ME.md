# Oficina — navegação 3D, link e executor

Referência: Godot 4.5, Compatibility, desktop. Oito arquivos locais, sem assets externos. O código foi revisado documentalmente; importação, compilação e execução no motor continuam pendentes. Consulte roteiro-testes.md antes de considerar o apoio homologado.

1. Extraia, importe project.godot, abra oficina.tscn e execute.
2. Aguarde bake/sincronização e polígonos >0. Ative Debug → Visible Navigation para inspecionar a malha; a câmera é fixa.
3. Com raio0,4, link bidirecional e executor presente, R inicia/reinicia o percurso. O agente não anda sozinho ao abrir.
4. Compare link desligado e sentido único com origem invertida. O último ponto alcançável pode ser atingido sem alcançar o alvo solicitado.
5. Com link ativo, retire o executor. O agente para na entrada: o link descreve uma possibilidade, não produz salto.
6. C restaura a posição mantendo as opções. O percurso pode ser repetido após chegar ou durante a ação.
7. Alterar raio exige B e nova sincronização. Compare0,2/0,4/1,2 com navegação visível: voxelização e busca das pontas podem alterar o resultado; não exigir coordenadas idênticas ao modelo web.

O executor usa um arco controlado entre pisos coplanares e faz teste de movimento contra colisores. Não é solução geral de salto físico: não calcula alcance balístico, não valida qualquer obstáculo/altura, nem implementa plataforma móvel. Não transfira a interpolação para outra cena sem rever o contrato.

Arquivos: cenario.gd cria pisos/região; agente.gd separa seguir/travessia/parado; oficina.gd cria interface e serializa bake/comandos. Os nós são criados em runtime e aparecem na árvore Remote, não como filhos salvos da cena.

Mudar NavigationMesh.agent_radius afeta o próximo bake; NavigationAgent3D.radius afeta avoidance; CapsuleShape3D.radius afeta colisão física. Avoidance está desligado. NavigationObstacle3D pode participar do bake conforme propriedades ou de avoidance, mas não altera automaticamente a topologia a cada movimento.
