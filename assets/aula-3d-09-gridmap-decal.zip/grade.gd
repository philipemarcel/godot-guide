extends RefCounted

static func configurar(grid: GridMap, biblioteca: MeshLibrary) -> void:
    grid.mesh_library = biblioteca
    grid.cell_size = Vector3(2, 2, 2)
    grid.cell_scale = 1.0
    grid.cell_center_x = true
    grid.cell_center_y = true
    grid.cell_center_z = true
    grid.collision_layer = 1
    grid.collision_mask = 1
    grid.bake_navigation = false

static func colocar(grid: GridMap, celula: Vector3i, id: int, quartos: int) -> bool:
    if grid.mesh_library == null or not grid.mesh_library.get_item_list().has(id):
        return false
    var basis := Basis(Vector3.UP, posmod(quartos, 4) * PI / 2.0)
    var orientacao := grid.get_orthogonal_index_from_basis(basis)
    grid.set_cell_item(celula, id, orientacao)
    return true

static func remover(grid: GridMap, celula: Vector3i) -> void:
    grid.set_cell_item(celula, GridMap.INVALID_CELL_ITEM)

static func centro_global(grid: GridMap, celula: Vector3i) -> Vector3:
    return grid.to_global(grid.map_to_local(celula))

static func celula_global(grid: GridMap, ponto: Vector3) -> Vector3i:
    return grid.local_to_map(grid.to_local(ponto))

# Extensão opcional para resultado de raycast; a interface principal edita por célula.
# O ponto e a normal devem estar em coordenadas globais e o collider ser este GridMap.
static func editar_impacto(grid: GridMap, hit: Dictionary, adicionar: bool,
        id: int = 0, quartos: int = 0) -> bool:
    if hit.is_empty() or hit.get("collider") != grid:
        return false
    if not hit.has("position") or not hit.has("normal"):
        return false
    var normal: Vector3 = hit["normal"]
    if normal.is_zero_approx():
        return false
    # Nesta prática, escala global unitária e células de 2 u.
    var epsilon := grid.cell_size[grid.cell_size.min_axis_index()] * 0.001
    var ponto: Vector3 = hit["position"]
    ponto += normal.normalized() * epsilon * (1.0 if adicionar else -1.0)
    var celula := celula_global(grid, ponto)
    if adicionar:
        return colocar(grid, celula, id, quartos)
    remover(grid, celula)
    return true
