# Roteiro pendente — Godot 4.5

Registrar versão, método/driver atual, hardware, esperado/observado e erros/avisos.

- [ ] Importar/compilar e executar; conferir cena Remota, caminhos e quatro scripts.
- [ ] Conferir 25 células base mais um módulo em Y=1; IDs0/7, tamanhos e formas na biblioteca. Centros XYZ e cell_size2.
- [ ] Converter centro da célula(0,0,0): local(1,1,1), global(11,1,-5); converter de volta. Comparar ponto negativo−0,01 no referencial local, que pertence a célula−1.
- [ ] Colocar/remover nas camadas0/1/2; repetir na mesma célula; preservar as demais. Trocar item inteiro/estreito e yaw0/90/180/270; ler índice ortogonal real, sem supor que iguala graus.
- [ ] Após atualização, consultar física: testar coluna com peça acima, remover a superior e consultar novamente; depois remover toda a coluna e conferir ausência. Verificar orientação da forma estreita.
- [ ] Extensão editar_impacto: testar ponto±normal×epsilon em face, borda e canto; validar collider e caso sem hit. Não concluir adjacência correta para qualquer cenário sem esses ensaios.
- [ ] Forward+/Mobile quando disponíveis: Decal presente com textura RGBA; testar volume em alturas distintas e máscara1/2/3/0 sobre GridMap e objeto separado.
- [ ] Conferir centro transparente do anel, projeção em mais de um receptor e ausência de geometria/colisão novas.
- [ ] Compatibility: grade funciona e UI informa ausência do Decal; não aceitar decal simulado por outro desenho como prova de suporte.
- [ ] Repetir fade antes do prazo, após desaparecer e durante alteração dos controles; nenhum Tween antigo deve apagar a marca reiniciada. R cancela e restaura.
- [ ] Verificar que alfa afeta albedo e não atribuir comportamento de emissão ausente à cena. Ajustar energia separada se adicionar emissão em uma extensão.
- [ ] UI/scroll/foco/atalhos, extremos e chamadas repetidas; evitar ações do painel enquanto texto/controle tem foco.
- [ ] Alternativa do editor, se adotada: montar estrutura suportada, materiais nas malhas, colisão explícita e exportar MeshLibrary; importar/reabrir recurso e conferir IDs.
- [ ] Corrigir divergências, repetir regressões afetadas e atualizar relatório, guia e índice de pendências antes de homologar.
