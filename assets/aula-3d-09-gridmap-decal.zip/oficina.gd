extends Node3D
const BIBLIOTECA = preload("res://biblioteca.gd")
const GRADE = preload("res://grade.gd")
const MARCA = preload("res://marca.gd")
var grid: GridMap
var marca: MARCA
var objeto: MeshInstance3D
var selecao: MeshInstance3D
var painel: VBoxContainer
var leitura: Label
var resultado_fisico: Label
var sx: HSlider
var sy: HSlider
var sz: HSlider
var giro: HSlider
var dx: HSlider
var dy: HSlider
var profundidade: HSlider
var item: OptionButton
var mascara: OptionButton
var repetir_btn: Button
var consultar := false

func celula() -> Vector3i:
    return Vector3i(int(sx.value), int(sy.value), int(sz.value))

func slider(titulo: String, minimo: float, maximo: float,
        passo: float, valor: float) -> HSlider:
    var texto := Label.new()
    texto.text = titulo
    painel.add_child(texto)
    var s := HSlider.new()
    s.min_value = minimo
    s.max_value = maximo
    s.step = passo
    s.value = valor
    s.custom_minimum_size.x = 340
    painel.add_child(s)
    s.value_changed.connect(func(_v: float): atualizar())
    return s

func botao(texto: String, acao: Callable) -> Button:
    var b := Button.new()
    b.text = texto
    painel.add_child(b)
    b.pressed.connect(acao)
    return b

func _ready() -> void:
    grid = GridMap.new()
    grid.name = "Grade"
    grid.position = Vector3(10, 0, -4)
    grid.rotation.y = PI / 2.0
    add_child(grid)
    GRADE.configurar(grid, BIBLIOTECA.criar())
    marca = MARCA.new()
    marca.name = "Marca"
    grid.add_child(marca) # Transformações da grade afetam a marca também.
    objeto = MeshInstance3D.new()
    objeto.name = "ObjetoLayer2"
    var mesh := BoxMesh.new()
    mesh.size = Vector3.ONE
    objeto.mesh = mesh
    objeto.layers = 2 # Visual, independente de collision_layer.
    objeto.position = grid.to_global(Vector3(1, 2, 1))
    var mat := StandardMaterial3D.new()
    mat.albedo_color = Color(0.6, 0.6, 0.6)
    mat.roughness = 0.7
    objeto.material_override = mat
    add_child(objeto)
    selecao = MeshInstance3D.new()
    selecao.name = "SelecaoSemColisao"
    var esfera := SphereMesh.new()
    esfera.radius = 0.12
    esfera.height = 0.24
    selecao.mesh = esfera
    var destaque := StandardMaterial3D.new()
    destaque.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
    destaque.albedo_color = Color(1, 0.75, 0.2)
    selecao.material_override = destaque
    selecao.layers = 4 # Não participa das máscaras 1/2/3 do painel.
    add_child(selecao)
    var camera := Camera3D.new()
    camera.position = grid.to_global(Vector3(12, 12, 16))
    add_child(camera)
    camera.look_at(grid.to_global(Vector3(1, 1, 1)), Vector3.UP)
    camera.make_current()
    var luz := DirectionalLight3D.new()
    luz.rotation_degrees = Vector3(-50, -25, 0)
    luz.shadow_enabled = true
    add_child(luz)
    var mundo := WorldEnvironment.new()
    var e := Environment.new()
    e.background_mode = Environment.BG_COLOR
    e.background_color = Color(0.04, 0.03, 0.02)
    e.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
    e.ambient_light_color = Color(0.7, 0.75, 0.8)
    e.ambient_light_energy = 0.3
    e.ambient_light_sky_contribution = 0.0
    mundo.environment = e
    add_child(mundo)
    criar_interface()
    restaurar()

func criar_interface() -> void:
    var layer := CanvasLayer.new()
    add_child(layer)
    var scroll := ScrollContainer.new()
    scroll.position = Vector2(16, 16)
    scroll.size = Vector2(430, 900)
    layer.add_child(scroll)
    var fundo := PanelContainer.new()
    scroll.add_child(fundo)
    painel = VBoxContainer.new()
    painel.add_theme_constant_override("separation", 8)
    fundo.add_child(painel)
    leitura = Label.new()
    leitura.custom_minimum_size.x = 370
    leitura.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
    painel.add_child(leitura)
    sx = slider("Célula X", -2, 2, 1, 0)
    sy = slider("Camada Y", 0, 2, 1, 0)
    sz = slider("Célula Z", -2, 2, 1, 0)
    item = OptionButton.new()
    item.add_item("ID 7 — estreito", 7)
    item.add_item("ID 0 — inteiro", 0)
    painel.add_child(item)
    item.item_selected.connect(func(_v: int): atualizar())
    giro = slider("Yaw da peça (quartos de volta)", 0, 3, 1, 0)
    botao("Colocar — P", colocar)
    botao("Remover célula — X", remover)
    dx = slider("Centro local X do projetor", -3, 5, 0.5, 1)
    dy = slider("Centro local Y do projetor", 1, 5, 0.5, 2)
    profundidade = slider("Profundidade Y do volume", 0.5, 6, 0.5, 2)
    mascara = OptionButton.new()
    mascara.add_item("1 — GridMap", 1)
    mascara.add_item("2 — objeto separado", 2)
    mascara.add_item("3 — ambos", 3)
    mascara.add_item("0 — nenhum", 0)
    painel.add_child(mascara)
    mascara.item_selected.connect(func(_v: int): atualizar())
    repetir_btn = botao("Repetir marca: 2 s + fade 1 s — F", repetir)
    botao("Consultar física após edição", func(): consultar = true)
    resultado_fisico = Label.new()
    resultado_fisico.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
    painel.add_child(resultado_fisico)
    botao("Restaurar cena — R", restaurar)

func atualizar() -> void:
    if not is_instance_valid(repetir_btn):
        return
    var c := celula()
    var local := grid.map_to_local(c)
    var global := GRADE.centro_global(grid, c)
    selecao.global_position = grid.to_global(local + Vector3(0, 1.2, 0))
    marca.position = Vector3(dx.value, dy.value, 1)
    marca.size = Vector3(4, profundidade.value, 4)
    marca.cull_mask = mascara.get_selected_id()
    var metodo := RenderingServer.get_current_rendering_method()
    var suportado := metodo != "gl_compatibility"
    marca.visible = suportado
    repetir_btn.disabled = not suportado
    leitura.text = ("Método: %s\nCélula %s | item %d | orientação %d\n"
            + "Centro local %s\nCentro global %s\nO desenho não altera colisões por si.\n"
            + "Decal: %s | máscara %d\nCentro X %.1f Y %.1f | volume Y %.1f\n"
            + "Sem locomoção ou navegação. Restaure antes de repetir testes.") % [
            metodo, c, grid.get_cell_item(c), grid.get_cell_item_orientation(c),
            local, global, "disponível" if suportado else "indisponível em Compatibility",
            marca.cull_mask, dx.value, dy.value, profundidade.value]

func colocar() -> void:
    GRADE.colocar(grid, celula(), item.get_selected_id(), int(giro.value))
    resultado_fisico.text = "Edição solicitada. Aguarde atualização e consulte a física."
    atualizar()

func remover() -> void:
    GRADE.remover(grid, celula())
    resultado_fisico.text = "Remoção solicitada. A sincronização física não é comprovada por este texto."
    atualizar()

func repetir() -> void:
    if not repetir_btn.disabled:
        marca.repetir()

func restaurar() -> void:
    consultar = false
    grid.clear()
    for x in range(-2, 3):
        for z in range(-2, 3):
            GRADE.colocar(grid, Vector3i(x, 0, z), 0, 0)
    GRADE.colocar(grid, Vector3i(0, 1, 0), 7, 0)
    sx.set_value_no_signal(0)
    sy.set_value_no_signal(0)
    sz.set_value_no_signal(0)
    giro.set_value_no_signal(0)
    dx.set_value_no_signal(1)
    dy.set_value_no_signal(2)
    profundidade.set_value_no_signal(2)
    item.select(0)
    mascara.select(0)
    marca.restaurar()
    resultado_fisico.text = "Cena restaurada. Consulta física ainda não realizada."
    atualizar()

func _physics_process(_delta: float) -> void:
    if not consultar:
        return
    consultar = false
    var c := celula()
    var p := grid.map_to_local(c)
    var de := grid.to_global(Vector3(p.x, 8, p.z))
    var ate := grid.to_global(Vector3(p.x, -2, p.z))
    var query := PhysicsRayQueryParameters3D.create(de, ate, 1)
    var hit := get_world_3d().direct_space_state.intersect_ray(query)
    if hit.is_empty():
        resultado_fisico.text = "Raio: sem hit; apenas layer física 1."
    else:
        var pos: Vector3 = hit["position"]
        var normal: Vector3 = hit["normal"]
        var atingida := GRADE.celula_global(grid, pos - normal * 0.002)
        resultado_fisico.text = "Primeira superfície: célula %s, ponto %s. Pode haver peça acima da seleção." % [atingida, pos]

func _unhandled_key_input(event: InputEvent) -> void:
    if not event is InputEventKey or not event.pressed or event.echo:
        return
    if event.ctrl_pressed or event.alt_pressed or event.meta_pressed:
        return
    match event.keycode:
        KEY_P: colocar()
        KEY_X: remover()
        KEY_F: repetir()
        KEY_R: restaurar()
        _: return
    get_viewport().set_input_as_handled()
