# Oficina de módulos e marcas projetadas

Extraia os nove arquivos juntos, importe `project.godot` na Godot 4.5 e execute `oficina.tscn`. O controlador cria a cena em runtime. O projeto começa em Forward+; confirme o método atual no painel. Em Compatibility a grade continua disponível, mas o Decal é ocultado e seu botão de repetição fica indisponível.

`biblioteca.gd` cria os itens 0 (cubo inteiro) e 7 (módulo estreito). As formas físicas são explicitamente adicionadas à MeshLibrary, com dimensões correspondentes à malha. `grade.gd` separa célula, centro local/global, ID e orientação ortogonal. A orientação é obtida de uma Basis; o número 90 não é passado como índice. A grade tem translação e yaw para tornar visível a diferença local/global.

Comece no Inspector Remoto: veja cell_size, centros, referência à biblioteca e formas. A base possui 25 células na camada Y=0 e um módulo na Y=1. A seleção não é personagem; a pequena esfera amarela indica um centro elevado e não recebe a marca. Os IDs não são layers e não definem navegação.

Selecione X/Y/Z, item e quartos de volta; clique Colocar. Remover limpa apenas a célula selecionada. Volte à camada anterior para conferir preservação. A consulta de física é um comando separado: após aguardar atualização, ele agenda um raio vertical. O resultado é a primeira peça na coluna, mesmo que esteja acima da seleção. O objeto separado não tem corpo e não participa desse raio. Nenhum texto de sucesso da edição comprova sincronização física instantânea.

O Decal é filho da grade e projeta por seu −Y local. Seu volume tem largura/profundidade X/Z de 4; centro Z=1. Ajuste X, Y e tamanho Y. O anel tem centro transparente: uma superfície dentro do volume pode ficar sem cor num texel transparente. O volume não é um raio que para no primeiro objeto; mais de um receptor pode receber a projeção. Compare mask1, mask2, mask3 e zero. O GridMap usa a primeira layer de renderização; o objeto cinza separado usa a segunda. Não tentar atribuir layer visual por célula.

Pressione F ou Repetir: mantém albedo por dois segundos e apaga em um. Pressionar de novo reinicia o prazo, cancelando Tween anterior. R cancela a animação e restaura a cena. Sem texto de emissão: animar modulate.a não apaga emissão de um Decal que a utilize. Na extensão com emissão seria necessário animar sua energia também. Não há liberação de nós nem pooling prometidos nesta prática reutilizável.

No navegador, o laboratório tem referencial local e tempo MANUAL. O desenho/telemetria demonstram geometria e filtros, sem executar GridMap, física ou Decal Godot. Normal/depth fades, sombra, oclusão e custos reais não são reproduzidos. O objeto da segunda amostra não oculta a grade na vista do modelo; não é uma câmera de renderização real.

Para criar MeshLibrary pelo editor em vez de código, use cena com Node3D raiz, MeshInstance3D filhos e materiais nos recursos de malha. Colisão exige StaticBody3D/CollisionShape3D na estrutura suportada. Exporte por Scene > Export As > MeshLibrary. Essa alternativa é um roteiro separado; o projeto entregue usa a biblioteca procedural e não comprova que a exportação no editor foi executada.

Execute o roteiro de testes antes de homologar. Scripts, física e renderização ainda não foram compilados/executados no motor neste ambiente.
