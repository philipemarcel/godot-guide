extends RefCounted

static func criar() -> MeshLibrary:
    var biblioteca := MeshLibrary.new()
    # Os IDs 0 e 7 são chaves, não índices sequenciais de um array.
    for id: int in [0, 7]:
        biblioteca.create_item(id)
        biblioteca.set_item_name(id, "Inteiro" if id == 0 else "Estreito")
        var mesh := BoxMesh.new()
        mesh.size = Vector3(2, 2, 2) if id == 0 else Vector3(2, 2, 1)
        var material := StandardMaterial3D.new()
        material.albedo_color = Color(0.5, 0.3, 0.12) if id == 0 else Color(0.1, 0.4, 0.45)
        material.roughness = 0.7
        mesh.material = material # Material pertence à malha da biblioteca.
        biblioteca.set_item_mesh(id, mesh)
        biblioteca.set_item_mesh_transform(id, Transform3D.IDENTITY)
        var forma := BoxShape3D.new()
        forma.size = mesh.size
        # Array alterna Shape3D e sua transformação local.
        biblioteca.set_item_shapes(id, [forma, Transform3D.IDENTITY])
    return biblioteca
