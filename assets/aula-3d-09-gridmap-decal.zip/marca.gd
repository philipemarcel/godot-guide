extends Decal
var animacao: Tween

func textura_anel() -> Texture2D:
    var imagem := Image.create(128, 128, false, Image.FORMAT_RGBA8)
    for y in range(128):
        for x in range(128):
            var raio := (Vector2(x, y) + Vector2(0.5, 0.5) - Vector2(64, 64)).length() / 32.0
            var alfa := 1.0 if raio >= 1.0 and raio <= 1.5 else 0.0
            imagem.set_pixel(x, y, Color(0.2, 0.9, 1.0, alfa))
    return ImageTexture.create_from_image(imagem)

func _ready() -> void:
    texture_albedo = textura_anel()
    # Só albedo nesta prática: alfa de modulate não apaga emissão.
    upper_fade = 0.0
    lower_fade = 0.0
    normal_fade = 0.0
    distance_fade_enabled = false
    restaurar()

func restaurar() -> void:
    if animacao != null and animacao.is_valid():
        animacao.kill()
    animacao = null
    modulate = Color.WHITE

func repetir() -> void:
    restaurar() # Cancela a animação anterior antes de iniciar outra.
    animacao = create_tween()
    animacao.tween_interval(2.0)
    animacao.tween_property(self, "modulate:a", 0.0, 1.0)
    # A marca é reutilizada, não liberada; F pode repetir após desaparecer.
