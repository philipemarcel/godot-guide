# Atlas de tubos — Match Sides

Cada peça tem 32 × 32. Atlas sem margem/separação. Coluna e linha começam em zero.
Terrain Set 0: Match Sides; terreno Tubo = 0. Centro de todas as peças: terreno 0. Nos lados indicados, pinte terreno 0; nos outros, mantenha vazio (-1). Nenhum canto é usado neste modo.

| Máscara didática | Atlas (coluna, linha) | Lados com terreno 0 |
| --- | --- | --- |
| 0 | (0, 0) | nenhum |
| 1 | (1, 0) | cima |
| 2 | (2, 0) | direita |
| 3 | (3, 0) | cima, direita |
| 4 | (0, 1) | baixo |
| 5 | (1, 1) | cima, baixo |
| 6 | (2, 1) | direita, baixo |
| 7 | (3, 1) | cima, direita, baixo |
| 8 | (0, 2) | esquerda |
| 9 | (1, 2) | cima, esquerda |
| 10 | (2, 2) | direita, esquerda |
| 11 | (3, 2) | cima, direita, esquerda |
| 12 | (0, 3) | baixo, esquerda |
| 13 | (1, 3) | cima, baixo, esquerda |
| 14 | (2, 3) | direita, baixo, esquerda |
| 15 | (3, 3) | cima, direita, baixo, esquerda |

A máscara é apenas uma legenda de quatro direções deste guia, não um ID de terreno da Godot. O atlas contém todas as 16 combinações de lados. Exemplo: máscara 10 tem direita e esquerda e ocupa (2, 2).

Teste com as células (0,0), (1,0), (2,0), (2,1), (2,2). Esperado: ponta direita em (0,0), reta horizontal em (1,0), curva esquerda/baixo em (2,0), reta vertical em (2,1), ponta cima em (2,2).

No editor, use a pintura de terrenos Connect. No código da aula, ignore_empty_terrains=false inclui os vazios na escolha das pontas. Se houver diferenças, verifique peering bits e modo; não basta adicionar a textura.