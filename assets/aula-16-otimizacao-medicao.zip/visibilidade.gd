extends Node2D

func _ready() -> void:
    $Camera2D.position = Vector2(320, 300)

func _unhandled_key_input(event: InputEvent) -> void:
    if event is InputEventKey and (event.ctrl_pressed or event.alt_pressed or event.meta_pressed):
        return
    if event is InputEventKey and event.pressed and not event.echo and event.keycode == KEY_C:
        $Camera2D.position.x = 1000 if $Camera2D.position.x < 500 else 320

# O controlador e a câmera ficam fora do alvo desativado.
# C afasta e aproxima a câmera; o Enabler controla só Rotor.
