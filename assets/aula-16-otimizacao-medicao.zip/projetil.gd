class_name ProjetilOficina
extends Node2D

var ativo: bool = false
var nascimento: float = 0.0
var origem := Vector2.ZERO
var velocidade := Vector2.ZERO
var vida: float = 2.0
var usos: int = 0

func ativar(pos: Vector2, vel: Vector2, instante: float, duracao: float) -> void:
    # Todo estado transitório deste projétil visual é restaurado aqui.
    origem = pos
    position = pos
    velocidade = vel
    nascimento = instante
    vida = duracao
    usos += 1
    ativo = true
    show()

func atualizar(instante: float) -> void:
    position = origem + velocidade * (instante - nascimento)

func desativar() -> void:
    ativo = false
    velocidade = Vector2.ZERO
    hide()

func _draw() -> void:
    draw_circle(Vector2.ZERO, 4, Color("5ce1e6"))

# Não há colisão, Timer, Tween ou sinais por tiro neste fixture.
# Se acrescentá-los, amplie ativar/desativar e teste também o estado físico.
