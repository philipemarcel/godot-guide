extends Node2D

var item: RID

func _ready() -> void:
    item = RenderingServer.canvas_item_create()
    RenderingServer.canvas_item_set_parent(item, get_canvas_item())
    RenderingServer.canvas_item_add_rect(item, Rect2(-16, -16, 32, 32), Color("5ce1e6"))
    RenderingServer.canvas_item_set_transform(item, Transform2D(0.25, Vector2(420, 140)))

func _exit_tree() -> void:
    # Só libera o RID criado por este script. Não libera get_canvas_item().
    if item.is_valid():
        RenderingServer.free_rid(item)
        item = RID()

# Este exemplo é visual: não cria corpo, shape ou area do PhysicsServer2D.
