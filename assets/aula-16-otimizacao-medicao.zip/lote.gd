extends MultiMeshInstance2D

func _ready() -> void:
    var quad := QuadMesh.new()
    quad.size = Vector2(18, 18)
    var batch := MultiMesh.new()
    batch.transform_format = MultiMesh.TRANSFORM_2D
    batch.use_colors = true # Antes de alocar instance_count.
    batch.mesh = quad
    batch.instance_count = 64
    for i in 64:
        var pos := Vector2(40 + (i % 8) * 32, 45 + floori(float(i) / 8.0) * 32)
        batch.set_instance_transform_2d(i, Transform2D(0.0, pos))
        batch.set_instance_color(i, Color("d4a359"))
    batch.visible_instance_count = 64
    multimesh = batch

func _unhandled_key_input(event: InputEvent) -> void:
    if event is InputEventKey and (event.ctrl_pressed or event.alt_pressed or event.meta_pressed):
        return
    if event is InputEventKey and event.pressed and not event.echo and event.keycode == KEY_V:
        multimesh.visible_instance_count = 16 if multimesh.visible_instance_count == 64 else 64

# V alterna o prefixo de 16/64 índices; não escolhe automaticamente os mais próximos.
# Não cria Area2D, colisão, IA ou um nó por instância.
