# Aula 16 — medir antes de otimizar

Referência: Godot 4.5, GDScript, Compatibility. Revisado estruturalmente/documentalmente; não executado no motor neste ambiente. O laboratório JS não valida estes scripts.

## 1. Oficina de ciclo de vida

Importe project.godot, abra oficina.tscn e execute com F6. L inicia/reinicia, B pede rajada de 8 durante emissão, R limpa. Botões equivalentes. Sem InputMap ou arte externa. Escolha modo e capacidade antes de Iniciar; escolhas valem no próximo ciclo. O controlador atualiza posições dos projéteis ativos; livres ficam ocultos. Não há Area2D, física, dano, Timer ou Tween.

Taxa fixa 8/s, vida 2 s, emissão 4 s. Primeiro pedido em 0,125 s; último em 4 s; término das vidas em 6 s. A expiração ocorre antes do pedido se ambos têm o mesmo instante. Sem rajadas: 32 pedidos. Criar/destruir: 32 criações e 32 liberações solicitadas. queue_free libera ao final do quadro. Pool 16: 16 criações iniciais, 32 atendidos, 16 reativações, 0 recusas, 16 livres ao fim. Pool 4: 8 atendidos e 24 recusas. Isso é previsão algorítmica, ainda a confirmar no motor.

O pool fixo não cresce nem rouba objetos. O início/limpeza remove os nós antigos e agenda liberação; o custo desse reset não é uma devolução normal. Todos os contadores são zerados. Não interprete quantidade criada como bytes ou FPS. O estado transitório do fixture é restaurado em ativar; usos permanece como histórico para contar reativações.

Se adicionar colisão, trate explicitamente monitoramento, shapes, filtros e eventos; process_mode ou hide não provam desativação física. Teste devolução repetida, estado residual e o momento seguro de mudanças durante callbacks da física.

## 2. Coleta real, ainda pendente

Abra Debugger → Profiler, inicie a coleta e compare ambos os modos com mesmos pedidos atendidos, taxa, vida, câmera, dispositivo e build. Separe preparação da reserva, emissão e esvaziamento. Repita e registre variação. Use os monitores para contagens relevantes; tempo de script não mostra sozinho todo custo de GPU. Anote condições de editor/V-Sync/exportação. Não desligue configurações do usuário para produzir um número conveniente.

Preencha medicoes.csv: os campos temporais começam vazios porque não existem medições reais neste pacote. Escolha e descreva a métrica (tempo total, média por quadro, pico etc.) antes de preencher. Compare também exportação no hardware-alvo. Um fixture pequeno pode não mostrar diferença relevante: esse é um resultado válido. UI e profiler introduzem custo. Memória reservada pelo pool é um tradeoff.

## 3. Visibilidade, separada do pool

Pare a oficina, abra visibilidade.tscn e execute com F6. C afasta/aproxima Camera2D. Alvo/Enabler usa enable_node_path=../Rotor. Só o Rotor é desativado; controlador e câmera permanecem ativos. O contador deve parar longe e continuar ao voltar. Notifier apenas emite sinais. Enabler usa process_mode, não é uma promessa de remover colisões. Visibilidade é avaliada pela renderização; não confunda com distância física. Não esconda o CanvasItem do detector esperando reativação automática. Este teste ainda precisa de execução na Godot.

## 4. Extensões visuais

Abra extensoes.tscn com F6. lote.gd desenha 64 QuadMesh; V alterna 16/64 índices. Transform format e use_colors vêm antes de instance_count. A contagem visível é um prefixo, não uma seleção dos mais próximos da câmera. Não cria nós, colisão ou IA para cada instância. Lotes espalhados podem exigir divisão por regiões, pois o culling não é individual por instância.

item_servidor.gd cria um item de RenderingServer, associa ao CanvasItem do pai, desenha retângulo e libera o RID próprio em _exit_tree. Não libera o RID do pai. A referência a Texture2D teria de ser mantida se a extensão passasse a usar textura; aqui há só uma primitiva. PhysicsServer2D não foi implementado: requer espaço, formas, corpos/áreas, filtros e liberação próprios. Trocar APIs não resolve automaticamente uma GPU saturada.

## Checklist no motor

- [ ] Importar, compilar e executar sem erros.
- [ ] Confirmar contagens regulares nos dois modos e capacidades 16/4.
- [ ] Repetir, rajada, reset e verificar ativos/livres disjuntos sem estado residual.
- [ ] Confirmar que reset remove todos os nós antigos; conferir liberação ao fim do quadro.
- [ ] Rodar visibilidade: afastar/voltar, contador para/retoma e controlador continua ativo.
- [ ] Rodar extensões: 16/64 índices e peça ciano visível; liberar RID ao sair.
- [ ] Preencher medições no mesmo cenário, depois validar no hardware-alvo.
