extends Node2D

const BULLET = preload("res://projetil.tscn")
var ativos: Array[ProjetilOficina] = []
var livres: Array[ProjetilOficina] = []
var modo_pool: bool = true
var rodando: bool = false
var tempo: float = 0.0
var proximo: int = 1
var taxa: int = 8
var capacidade: int = 16
var vida: float = 2.0
var duracao: float = 4.0
var pedidos: int = 0
var atendidos: int = 0
var criados: int = 0
var destruicoes: int = 0
var reusos: int = 0
var recusas: int = 0
var escolha: OptionButton
var limite: SpinBox
var status: Label
var mundo: Node2D

func _ready() -> void:
    mundo = Node2D.new()
    add_child(mundo)
    var layer := CanvasLayer.new()
    add_child(layer)
    var box := VBoxContainer.new()
    box.position = Vector2(16, 330)
    box.custom_minimum_size.x = 608
    layer.add_child(box)
    escolha = OptionButton.new()
    escolha.add_item("Pool fixo")
    escolha.add_item("Criar e destruir")
    box.add_child(escolha)
    var label := Label.new()
    label.text = "Capacidade do pool (aplicada ao iniciar):"
    box.add_child(label)
    limite = SpinBox.new()
    limite.min_value = 4
    limite.max_value = 64
    limite.step = 4
    limite.value = 16
    box.add_child(limite)
    botao(box, "L · Iniciar / repetir", iniciar)
    botao(box, "B · Rajada de 8 pedidos", rajada)
    botao(box, "R · Limpar experimento", limpar)
    status = Label.new()
    status.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
    box.add_child(status)

func botao(parent: Node, text: String, action: Callable) -> void:
    var button := Button.new()
    button.text = text
    button.pressed.connect(action)
    parent.add_child(button)

func limpar() -> void:
    rodando = false
    # Durante limpeza explícita, todos os objetos são liberados.
    # A remoção imediata evita somar nós antigos ao próximo experimento.
    for child in mundo.get_children():
        mundo.remove_child(child)
        child.queue_free()
    ativos.clear()
    livres.clear()
    tempo = 0.0
    proximo = 1
    pedidos = 0
    atendidos = 0
    criados = 0
    destruicoes = 0
    reusos = 0
    recusas = 0

func criar() -> ProjetilOficina:
    var p := BULLET.instantiate() as ProjetilOficina
    mundo.add_child(p)
    p.desativar()
    criados += 1
    return p

func iniciar() -> void:
    limpar()
    modo_pool = escolha.selected == 0
    capacidade = int(limite.value)
    if modo_pool:
        for _i in capacidade:
            livres.push_back(criar())
    rodando = true

func emitir() -> void:
    pedidos += 1
    var p: ProjetilOficina
    if modo_pool:
        if livres.is_empty():
            recusas += 1 # Política deliberada: não cresce nem rouba tiro ativo.
            return
        p = livres.pop_back()
        if p.usos > 0:
            reusos += 1
    else:
        p = criar()
    atendidos += 1
    p.ativar(Vector2(40, 80 + (pedidos % 5) * 38), Vector2(240, 0), tempo, vida)
    ativos.push_back(p)

func rajada() -> void:
    if rodando and tempo < duracao:
        for _i in 8:
            emitir()

func expirar_e_mover(instante: float) -> void:
    # Varredura reversa permite remover sem pular o próximo elemento.
    for i in range(ativos.size() - 1, -1, -1):
        var p := ativos[i]
        if p.nascimento + p.vida <= instante + 0.000000001:
            ativos.remove_at(i)
            p.desativar()
            if modo_pool:
                livres.push_back(p)
            else:
                mundo.remove_child(p)
                p.queue_free()
                destruicoes += 1
        else:
            p.atualizar(instante)

func _physics_process(delta: float) -> void:
    if rodando:
        var fim := minf(tempo + delta, duracao + vida)
        # Expirar antes de emitir define o desempate no mesmo instante.
        while float(proximo) / taxa <= minf(fim, duracao) + 0.000000001:
            tempo = float(proximo) / taxa
            expirar_e_mover(tempo)
            emitir()
            proximo += 1
        tempo = fim
        expirar_e_mover(tempo)
        if tempo >= duracao + vida - 0.000000001:
            rodando = false
    status.text = ("Tempo: %.2f s | pedidos: %d | atendidos: %d\n" +
        "Criados: %d | liberações solicitadas: %d | reativações: %d\n" +
        "Ativos: %d | livres: %d | recusas: %d\n" +
        "Modelo visual sem colisão. Contagens não são medidas de FPS.") % [
        tempo, pedidos, atendidos, criados, destruicoes, reusos,
        ativos.size(), livres.size(), recusas]

func _unhandled_key_input(event: InputEvent) -> void:
    if not event is InputEventKey or not event.pressed or event.echo:
        return
    if event.ctrl_pressed or event.alt_pressed or event.meta_pressed:
        return
    match event.keycode:
        KEY_L: iniciar()
        KEY_B: rajada()
        KEY_R: limpar()
