extends Node2D

var segundos: float = 0.0

func _process(delta: float) -> void:
    segundos += delta
    $Arte.rotation += delta
    $Leitura.text = "Processado: %.2f s" % segundos
