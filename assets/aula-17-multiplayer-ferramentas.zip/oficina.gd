extends Node2D

const PLAYER = preload("res://jogador.tscn")
const PORTA: int = 7000
var modo: String = "offline"
var sequencia_local: int = 0
var ultimo_pedido: Array = []
var regras: Dictionary = {}
var aceitos: int = 0
var recusados: int = 0
var jogadores: Node2D
var spawner: MultiplayerSpawner
var leitura: Label
var mensagem: Label

func _ready() -> void:
    jogadores = Node2D.new()
    jogadores.name = "Jogadores"
    add_child(jogadores)
    spawner = MultiplayerSpawner.new()
    spawner.name = "Spawner"
    spawner.spawn_path = NodePath("../Jogadores")
    spawner.spawn_function = criar_jogador
    add_child(spawner)
    multiplayer.peer_connected.connect(peer_entrou)
    multiplayer.peer_disconnected.connect(peer_saiu)
    multiplayer.connected_to_server.connect(conectou)
    multiplayer.connection_failed.connect(falhou)
    multiplayer.server_disconnected.connect(servidor_saiu)
    criar_interface()

func criar_interface() -> void:
    var layer := CanvasLayer.new()
    add_child(layer)
    var box := VBoxContainer.new()
    box.position = Vector2(16, 330)
    box.custom_minimum_size.x = 608
    layer.add_child(box)
    botao(box, "Hospedar localmente (127.0.0.1:7000)", hospedar)
    botao(box, "Conectar ao host local", entrar)
    botao(box, "Desconectar / limpar", desconectar)
    var row := HBoxContainer.new()
    box.add_child(row)
    botao(row, "← / A", func(): solicitar("mover", -1, 0))
    botao(row, "↑ / W", func(): solicitar("mover", 0, -1))
    botao(row, "↓ / S", func(): solicitar("mover", 0, 1))
    botao(row, "→ / D", func(): solicitar("mover", 1, 0))
    botao(box, "Espaço · Pedir tiro (contador visual)", func(): solicitar("atirar"))
    botao(box, "V · Enviar direção inválida", func(): solicitar("mover", 9, 0))
    botao(box, "P · Reenviar mesmo pedido", reenviar)
    leitura = Label.new()
    leitura.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
    box.add_child(leitura)
    mensagem = Label.new()
    mensagem.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
    mensagem.text = "Abra duas execuções: hospede em uma, conecte na outra."
    box.add_child(mensagem)

func botao(parent: Node, text: String, action: Callable) -> void:
    var button := Button.new()
    button.text = text
    button.pressed.connect(action)
    parent.add_child(button)

func hospedar() -> void:
    if modo != "offline":
        mensagem.text = "Desconecte antes de iniciar outra sessão."
        return
    var peer := ENetMultiplayerPeer.new()
    peer.set_bind_ip("127.0.0.1") # Exercício só nesta máquina.
    var error := peer.create_server(PORTA, 1) # Um cliente, além do host.
    if error != OK:
        mensagem.text = "Falha ao hospedar: " + error_string(error)
        return
    multiplayer.multiplayer_peer = peer
    modo = "host"
    registrar(1)
    mensagem.text = "Host ID 1 pronto. Conecte a segunda execução."

func entrar() -> void:
    if modo != "offline":
        return
    var peer := ENetMultiplayerPeer.new()
    var error := peer.create_client("127.0.0.1", PORTA)
    if error != OK:
        mensagem.text = "Pedido de conexão recusado: " + error_string(error)
        return
    multiplayer.multiplayer_peer = peer
    modo = "conectando"
    mensagem.text = "Conectando... OK no pedido ainda não confirma a conexão."

func conectou() -> void:
    modo = "cliente"
    mensagem.text = "Conectado. Seu ID real é %d; aguarde seu jogador aparecer." % multiplayer.get_unique_id()

func falhou() -> void:
    desconectar()
    mensagem.text = "Conexão falhou. Confira host, porta e segunda execução."

func servidor_saiu() -> void:
    desconectar()
    mensagem.text = "Host desconectou. Estado local limpo; conecte novamente."

func desconectar() -> void:
    modo = "offline"
    if multiplayer.multiplayer_peer != null:
        multiplayer.multiplayer_peer.close()
    multiplayer.multiplayer_peer = OfflineMultiplayerPeer.new()
    for child in jogadores.get_children():
        jogadores.remove_child(child)
        child.queue_free()
    regras.clear()
    sequencia_local = 0
    ultimo_pedido.clear()
    aceitos = 0
    recusados = 0
    mensagem.text = "Sessão encerrada; pode hospedar ou conectar novamente."

func registrar(id: int) -> void:
    if regras.has(id):
        return
    regras[id] = {"seq": 0, "mover": -1000000.0, "atirar": -1000000.0}
    spawner.spawn(id) # A função retorna o nó fora da árvore; Spawner o adiciona.

func peer_entrou(id: int) -> void:
    if modo == "host":
        registrar(id)

func peer_saiu(id: int) -> void:
    if modo != "host":
        return
    regras.erase(id)
    var actor := jogadores.get_node_or_null(str(id))
    if actor != null:
        actor.queue_free() # A autoridade remove; Spawner replica o despawn.

func criar_jogador(data: Variant) -> Node:
    var actor := PLAYER.instantiate() as JogadorRede
    actor.owner_peer = int(data)
    actor.name = str(actor.owner_peer)
    actor.position = Vector2(320, 130 if actor.owner_peer == 1 else 230)
    # Autoridade continua ID 1 em todos os pares. owner_peer é outra função.
    return actor

func solicitar(acao: String, dx: int = 0, dy: int = 0) -> void:
    if modo != "host" and modo != "cliente":
        mensagem.text = "Conecte antes de enviar ações."
        return
    sequencia_local += 1
    ultimo_pedido = [sequencia_local, acao, dx, dy]
    if modo == "host":
        validar(1, sequencia_local, acao, dx, dy) # Host usa a mesma validação.
    else:
        receber_pedido.rpc_id(1, sequencia_local, acao, dx, dy)

func reenviar() -> void:
    if ultimo_pedido.is_empty() or (modo != "host" and modo != "cliente"):
        return
    var seq := int(ultimo_pedido[0])
    var acao := str(ultimo_pedido[1])
    var dx := int(ultimo_pedido[2])
    var dy := int(ultimo_pedido[3])
    if modo == "host":
        validar(1, seq, acao, dx, dy)
    else:
        receber_pedido.rpc_id(1, seq, acao, dx, dy)

@rpc("any_peer", "call_remote", "reliable", 0)
func receber_pedido(seq: int, acao: String, dx: int, dy: int) -> void:
    if modo != "host" or not multiplayer.is_server():
        return
    var remetente := multiplayer.get_remote_sender_id()
    validar(remetente, seq, acao, dx, dy)

func validar(id: int, seq: int, acao: String, dx: int, dy: int) -> void:
    if not regras.has(id):
        return
    var actor := jogadores.get_node_or_null(str(id)) as JogadorRede
    if actor == null:
        responder(id, seq, false, "Jogador ainda não disponível.")
        return
    if seq <= int(regras[id]["seq"]) or seq > 1000000000:
        responder(id, seq, false, "Sequência repetida ou fora do contrato.")
        return
    regras[id]["seq"] = seq # Mesmo um pedido inválido novo consome a sequência.
    if acao != "mover" and acao != "atirar":
        responder(id, seq, false, "Ação desconhecida.")
        return
    if acao == "mover" and not (((dx == -1 or dx == 1) and dy == 0) or ((dy == -1 or dy == 1) and dx == 0)):
        responder(id, seq, false, "Direção inválida: use um eixo por pedido.")
        return
    var agora := Time.get_ticks_msec() / 1000.0
    var espera: float = 0.1 if acao == "mover" else 0.5
    if agora - float(regras[id][acao]) < espera:
        responder(id, seq, false, "Ação em cooldown no servidor.")
        return
    regras[id][acao] = agora
    if acao == "mover":
        actor.position += Vector2(dx, dy) * 40
        actor.position.x = clampf(actor.position.x, 80, 560)
        actor.position.y = clampf(actor.position.y, 100, 260)
    else:
        actor.tiros += 1 # Contador, não um projétil/dano de jogo completo.
    responder(id, seq, true, "Estado autorizado; Synchronizer replica as propriedades configuradas.")

func responder(id: int, seq: int, ok: bool, text: String) -> void:
    if ok:
        aceitos += 1
    else:
        recusados += 1
    if id == 1:
        exibir_resultado(seq, ok, text)
    elif id in multiplayer.get_peers():
        resultado.rpc_id(id, seq, ok, text)

@rpc("authority", "call_remote", "reliable", 0)
func resultado(seq: int, ok: bool, text: String) -> void:
    exibir_resultado(seq, ok, text)

func exibir_resultado(seq: int, ok: bool, text: String) -> void:
    mensagem.text = "Pedido %d: %s. %s" % [seq, "aceito" if ok else "recusado", text]

func _process(_delta: float) -> void:
    leitura.text = "Modo: %s | ID local: %d | jogadores: %d\nNo host: aceitos %d / recusados %d" % [
        modo, multiplayer.get_unique_id(), jogadores.get_child_count(), aceitos, recusados]

func _unhandled_key_input(event: InputEvent) -> void:
    if not event is InputEventKey or not event.pressed or event.echo:
        return
    if event.ctrl_pressed or event.alt_pressed or event.meta_pressed:
        return
    match event.keycode:
        KEY_A, KEY_LEFT: solicitar("mover", -1, 0)
        KEY_D, KEY_RIGHT: solicitar("mover", 1, 0)
        KEY_W, KEY_UP: solicitar("mover", 0, -1)
        KEY_S, KEY_DOWN: solicitar("mover", 0, 1)
        KEY_SPACE: solicitar("atirar")
        KEY_V: solicitar("mover", 9, 0)
        KEY_P: reenviar()
