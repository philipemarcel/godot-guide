# Aula 17 — rede local e prévia de editor

Godot 4.5, GDScript, Compatibility, desktop. Revisado estruturalmente/documentalmente; ainda não executado no motor neste ambiente. Importar este projeto ou testar o JS do site não comprova que a rede funciona na Godot. Consulte roteiro-testes.md para a validação pendente.

## Sessão com duas execuções

Importe project.godot e abra oficina.tscn. Abra duas execuções do mesmo projeto, pelo recurso de múltiplas instâncias do editor ou por outro processo Godot executando a mesma pasta. Use as mesmas versões de scripts e cenas. A raiz precisa se chamar Oficina nas duas execuções: as RPCs dependem de NodePath correspondente.

Na primeira, clique Hospedar localmente. O servidor faz bind apenas em 127.0.0.1, UDP 7000, aceitando um cliente além do host. Na segunda, Conectar. Não há conexão automática, portas de roteador ou implantação na internet. Hospedar duas vezes na mesma porta deve retornar erro. create_client OK só inicia tentativa; o sinal connected_to_server confirma a sessão.

Cada janela envia intenções do participante local. WASD/setas: um passo cardinal de 40 unidades por toque, ignorando auto-repetição. Espaço: pedir aumento do contador de tiros. V: direção inválida. P: reenviar o último pedido com a mesma sequência (deve ser recusado). Há botões equivalentes. Desconectar / limpar permite repetir sem reiniciar o projeto. O tiro é um contador visual; não há projétil, colisão, dano ou animação de ataque.

O host tem ID 1. O cliente real não precisa ter ID 2. Todos os jogadores permanecem com autoridade do servidor; owner_peer indica o participante que envia intenções e não transfere autoridade. Não use name.to_int para conceder autoridade sem projetar o contrato. O servidor associa o remetente real da RPC ao jogador, exige sequência nova até 1e9, ação conhecida e direção cardinal, e aplica cooldown: movimento 0,1 s; tiro 0,5 s. O host chama a mesma validação diretamente. Mesmo uma ação nova inválida consome sua sequência. Esses controles são didáticos e não constituem autenticação/proteção de produção.

Spawner é configurado por oficina.gd com spawn_path=../Jogadores e spawn_function=criar_jogador. Só a autoridade chama spawn. O callback retorna o nó fora da árvore; não usa add_child. Ao desconectar, a autoridade libera o jogador e replica despawn. A cena jogador.tscn tem Synchronizer, root_path=.., e SceneReplicationConfig para .:owner_peer (ON_CHANGE), .:position (ALWAYS) e .:tiros (ON_CHANGE), todas com spawn=true. Posição tem replication_interval=0.1. ALWAYS usa atualização não confiável; ON_CHANGE usa envio confiável quando muda. Não é seleção automática de propriedades, interpolação, rollback ou previsão local.

Pedidos usam @rpc(any_peer, call_remote, reliable, 0), enviados só ao peer 1. any_peer não autoriza regras de jogo. O retorno resultado é uma RPC de autoridade para o remetente. Reliable tenta reenviar/preservar ordem enquanto existe conexão; não elimina latência nem garante completar sessão desconectada. Não sincronize Resources, RIDs ou instance IDs locais como se fossem dados portáteis.

## Extensão @tool separada

Pare a execução e abra previa.tscn no editor. Selecione Previa, altere raio e observe redraw. Zero deve produzir aviso de configuração; restaure 140. Execute essa cena: o círculo de editor não aparece e Arte faz pequena oscilação. O script não remove nós nem grava arquivos. O círculo não é detecção física. @tool pode executar no editor e no jogo; Engine.is_editor_hint delimita cada parte. Se o editor ainda não atualizar após anexar o script, salve e reabra a cena e verifique o painel de erros.

## Limites do laboratório do site

Canvas/JS, sem ENet, socket, @tool ou Synchronizer real. IDs fixos 1/2 são simplificação. RTT simétrico e constante por mensagem, sem perdas/jitter/retransmissão. Cada nova mensagem captura seu atraso base atual; alterar RTT não muda prazos já enfileirados. Pedidos preservam sua ordem e podem aguardar um pedido anterior. O modelo envia um snapshot após comando aceito, diferente da configuração de replicação real da cena. Suavização exponencial própria não é função automática de Synchronizer. P envia de novo a mesma sequência de aplicação, não duplica um pacote interno do ENet. Desconectar descarta fila e invalida valores antigos; reconectar começa nova sessão com estado inicial. Não mede desempenho ou RTT reais.
