# Validação na Godot 4.5 — pendente

Registre versão exata, renderizador, sistema, duas execuções e mensagens do depurador. Não marque itens só porque o navegador passou.

- [ ] Importar e compilar três scripts e três cenas sem erros relevantes.
- [ ] Duas execuções com raiz Oficina e mesmos arquivos; hospedar e conectar.
- [ ] Host ID 1; cliente com ID real; dois jogadores replicados e autoridade 1.
- [ ] Passos em quatro direções: só o jogador do remetente; limites 80–560 e 100–260.
- [ ] Cooldown de movimento 0,1 s e de tiro 0,5 s aplicados no host e cliente.
- [ ] V rejeita direção sem mudar estado; P rejeita sequência repetida.
- [ ] Configuração de spawn/ON_CHANGE/ALWAYS corresponde à cena e valores chegam.
- [ ] Desconectar cliente remove jogador; reconectar recria sem duplicatas.
- [ ] Desconectar host limpa cliente; tentativa sem host falha e permite outra tentativa.
- [ ] Segundo host na porta ocupada retorna erro, sem substituir peer válido.
- [ ] Desconectar / limpar libera nós e zera sessão; sem sinais conectados em duplicidade.
- [ ] Editor: mudar raio redesenha, zero avisa, 140 restaura.
- [ ] Runtime de previa.tscn: sem círculo de editor, Arte oscila, sem remoção de nós.

| Caso | Ação/ambiente | Resultado real | Erro/ajuste necessário |
| --- | --- | --- | --- |
| Rede local | Preencher após executar | Pendente | Pendente |
| Replicação e desconexão | Preencher após executar | Pendente | Pendente |
| Prévia de editor | Preencher após executar | Pendente | Pendente |
