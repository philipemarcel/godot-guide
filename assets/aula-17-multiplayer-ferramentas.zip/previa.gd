@tool
extends Node2D

@export_range(0, 300, 1) var raio: float = 140.0:
    set(value):
        raio = clampf(value, 0, 300)
        queue_redraw()
        if is_inside_tree():
            update_configuration_warnings()

var tempo: float = 0.0

func _ready() -> void:
    update_configuration_warnings()
    queue_redraw()

func _get_configuration_warnings() -> PackedStringArray:
    if raio <= 0:
        return PackedStringArray(["Defina raio maior que zero para enxergar o alcance."])
    return PackedStringArray()

func _draw() -> void:
    if Engine.is_editor_hint() and raio > 0:
        draw_circle(Vector2.ZERO, raio, Color(0.36, 0.88, 0.90, 0.12))
        draw_arc(Vector2.ZERO, raio, 0, TAU, 64, Color("5ce1e6"), 2)

func _process(delta: float) -> void:
    if Engine.is_editor_hint():
        return
    tempo += delta
    $Arte.rotation = sin(tempo) * 0.1

# Prévia só desenha: não remove nós nem grava arquivos da cena editada.
# O círculo é um auxílio visual, não uma Area2D ou detecção de inimigos.
