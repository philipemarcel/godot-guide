class_name JogadorRede
extends Node2D

@export var owner_peer: int = 0
@export var tiros: int = 0

func _process(_delta: float) -> void:
    $Leitura.global_position = Vector2(clampf(global_position.x - 150, 8, 328), global_position.y + 24)
    $Leitura.text = "Controle: peer %d | autoridade: %d | tiros: %d" % [
        owner_peer, get_multiplayer_authority(), tiros]

func _draw() -> void:
    draw_circle(Vector2.ZERO, 16, Color("5ce1e6"))
    draw_line(Vector2.ZERO, Vector2(24, 0), Color("d4a359"), 6)

# A posição e o contador são alterados pelo servidor, não por este _process.
# O Synchronizer da cena replica as propriedades configuradas; não interpola.
