extends Node3D

const PASSO = preload("res://passo.gd")
@onready var base: Node3D = $Base
@onready var peca: Node3D = $Base/Peca
@onready var camera: Camera3D = $Camera3D
var modo: OptionButton
var leitura: Label
var mensagem: Label
var ultimo_delta := Vector3.ZERO
var azimute: float = 45.0

func _ready() -> void:
    var layer := CanvasLayer.new()
    add_child(layer)
    var box := VBoxContainer.new()
    box.position = Vector2(16, 405)
    box.custom_minimum_size.x = 928
    layer.add_child(box)
    var row := HBoxContainer.new()
    box.add_child(row)
    botao(row, "A · X −0,5", func(): coordenada(Vector3(-0.5, 0, 0)))
    botao(row, "D · X +0,5", func(): coordenada(Vector3(0.5, 0, 0)))
    botao(row, "E · Y +0,5", func(): coordenada(Vector3(0, 0.5, 0)))
    botao(row, "Q · Y −0,5", func(): coordenada(Vector3(0, -0.5, 0)))
    botao(row, "W · Z −0,5", func(): coordenada(Vector3(0, 0, -0.5)))
    botao(row, "S · Z +0,5", func(): coordenada(Vector3(0, 0, 0.5)))
    modo = OptionButton.new()
    modo.add_item("F: frente −Z da peça, 1 unidade global")
    modo.add_item("F: −Z fixo do mundo, 1 unidade global")
    box.add_child(modo)
    row = HBoxContainer.new()
    box.add_child(row)
    botao(row, "F · Avançar", avancar)
    botao(row, "P · Exemplo pai 90°", exemplo)
    botao(row, "O · Peça +45°", girar_peca)
    botao(row, "T · Escala 1/2", escalar_pai)
    botao(row, "C · Girar vista", girar_camera)
    botao(row, "R · Restaurar", restaurar)
    leitura = Label.new()
    leitura.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
    box.add_child(leitura)
    mensagem = Label.new()
    mensagem.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
    box.add_child(mensagem)
    atualizar_camera()
    mensagem.text = "Valores da cena preservados. R restaura a bancada de referência."

func botao(parent: Node, text: String, action: Callable) -> void:
    var button := Button.new()
    button.text = text
    button.pressed.connect(action)
    parent.add_child(button)

func restaurar() -> void:
    base.position = Vector3(2, 0, 1)
    base.rotation_degrees = Vector3.ZERO
    base.scale = Vector3.ONE
    peca.position = Vector3(0, 0.5, -2)
    peca.rotation_degrees = Vector3.ZERO
    peca.scale = Vector3.ONE
    ultimo_delta = Vector3.ZERO
    azimute = 45
    modo.select(0)
    atualizar_camera()
    mensagem.text = "Coordenadas nos eixos do pai; frente da peça é outra direção. Sem física ou colisão."

func aplicar(no_pai: Vector3) -> void:
    if absf(no_pai.x) > 4.000001 or absf(no_pai.z) > 4.000001 or no_pai.y < 0.499999 or no_pai.y > 3.000001:
        ultimo_delta = Vector3.ZERO
        mensagem.text = "Limite didático local: X/Z entre −4 e 4; Y entre 0,5 e 3. R restaura."
        return
    var antes := peca.global_position
    peca.position = no_pai
    ultimo_delta = peca.global_position - antes
    mensagem.text = "Passo aplicado. Compare posição no pai, no mundo e distância percorrida."

func coordenada(offset: Vector3) -> void:
    aplicar(peca.position + offset)

func avancar() -> void:
    var delta_global: Vector3 = PASSO.deslocamento(peca, modo.selected == 0)
    var destino := peca.global_position + delta_global
    aplicar(base.to_local(destino))

func exemplo() -> void:
    restaurar()
    base.rotation_degrees.y = 90
    mensagem.text = "Pai Y=90°: local (0, 0.5, −2) → global (0, 0.5, 1)."

func girar_peca() -> void:
    peca.rotation_degrees.y = wrapf(peca.rotation_degrees.y + 45, -180, 180)
    ultimo_delta = Vector3.ZERO

func escalar_pai() -> void:
    base.scale = Vector3.ONE * (2.0 if base.scale.x < 1.5 else 1.0)
    ultimo_delta = Vector3.ZERO

func girar_camera() -> void:
    azimute = fmod(azimute + 90.0, 360.0)
    atualizar_camera()

func atualizar_camera() -> void:
    var a := deg_to_rad(azimute)
    var b := deg_to_rad(35)
    var centro := Vector3(0, -3, 0)
    camera.position = centro + Vector3(sin(a) * cos(b), sin(b), cos(a) * cos(b)) * 18
    camera.look_at(centro, Vector3.UP)
    camera.make_current()

func _process(_delta: float) -> void:
    if leitura == null:
        return
    var frente := (-peca.global_transform.basis.z).normalized()
    leitura.text = ("Position (no pai): %s | global_position: %s\n" +
        "Pai: %s | Y do pai: %.0f° | Y da peça: %.0f° | escala do pai: %.1f\n" +
        "Frente da peça no mundo: %s\n" +
        "Último delta global: %s | distância: %.3f u\n" +
        "Convenção do projeto: 1 u = 1 m. Node3D não aplica gravidade.") % [
        str(peca.position), str(peca.global_position), str(base.position),
        base.rotation_degrees.y, peca.rotation_degrees.y, base.scale.x,
        str(frente), str(ultimo_delta), ultimo_delta.length()]

func _unhandled_key_input(event: InputEvent) -> void:
    if not event is InputEventKey or not event.pressed or event.echo:
        return
    if event.ctrl_pressed or event.alt_pressed or event.meta_pressed:
        return
    match event.keycode:
        KEY_A, KEY_LEFT: coordenada(Vector3(-0.5, 0, 0))
        KEY_D, KEY_RIGHT: coordenada(Vector3(0.5, 0, 0))
        KEY_W, KEY_UP: coordenada(Vector3(0, 0, -0.5))
        KEY_S, KEY_DOWN: coordenada(Vector3(0, 0, 0.5))
        KEY_Q: coordenada(Vector3(0, -0.5, 0))
        KEY_E: coordenada(Vector3(0, 0.5, 0))
        KEY_F: avancar()
        KEY_P: exemplo()
        KEY_O: girar_peca()
        KEY_T: escalar_pai()
        KEY_C: girar_camera()
        KEY_R: restaurar()
