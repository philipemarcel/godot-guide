# Testes na Godot 4.5 — pendentes

- [ ] Importar/compilar e abrir oficina.tscn; conferir câmera, luz, cubo e rótulos.
- [ ] Inspector: Base=(2,0,1), Peca=(0,0.5,−2), escala 1 e top_level=false.
- [ ] Runtime: global inicial=(2,0.5,−1); R restaura valores/controles.
- [ ] P: pai Y=90°, global=(0,0.5,1), local preservado.
- [ ] P seguido de T: escala 2, global=(−2,1,1), aresta global 2.
- [ ] P/F frente: destino=(−1,0.5,1), distância 1.
- [ ] P/F mundo: destino=(0,0.5,0), distância 1.
- [ ] Sob escala 2, F continua com distância global 1.
- [ ] O muda orientação sem mover a origem; C não muda coordenadas da peça.
- [ ] WASD/setas/Q/E e botões coerentes; limite recusa passo inteiro.
- [ ] consulta.gd instalado no Node extra mostra conversão e inversa corretas.
- [ ] Confirmar que não há queda/colisão e Marker3D não é a malha visível.
- [ ] Conferir legibilidade, enquadramento e todos os erros/avisos no motor.

Registre versão, renderizador e resultado real antes de marcar. Esta lista não é aprovada pelos testes do navegador.
