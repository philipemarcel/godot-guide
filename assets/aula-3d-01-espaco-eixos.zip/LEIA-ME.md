# 3D 1 — espaço, eixos e coordenadas

Referência: Godot 4.5, GDScript, Compatibility. Revisado estruturalmente/documentalmente; não executado no motor neste ambiente. Os testes JS não homologam os scripts ou a cena.

## Primeiro, sem programar

Importe project.godot e abra oficina.tscn no editor 3D. A cena já tem piso, eixos nomeados, cubo 1×1×1, nariz ciano em −Z, Marker3D Frente, câmera e luz. Selecione Base e Peca e altere Transform no Inspector para fazer as previsões da aula. Não é preciso copiar os scripts para isso. Node3D sozinho não desenha uma malha nem tem gravidade. Marker3D tem gizmo de editor, não forma visível no jogo.

Pai Base: position=(2,0,1). Peca: position=(0,0.5,−2), rotação zero e escala 1. Inicial global previsto=(2,0.5,−1). Pai Y=+90° dá global=(0,0.5,1). Com o mesmo pai e escala 2, global=(−2,1,1). São previsões matemáticas ainda a confirmar no motor. O projeto adota 1 unidade como 1 metro, não pixels nem medição física de um objeto real.

## Bancada em runtime

F6 executa a cena e oficina.gd cria botões/leituras. A/D ou setas horizontais mudam X no pai; W/S ou setas verticais mudam Z; Q/E mudam Y. Cada toque aplica 0,5 unidade no pai. F avança uma unidade global pela direção selecionada (frente da peça ou −Z do mundo). P restaura e instala pai Y=90°. O gira a própria peça em +45° sem mudar sua origem. T alterna escala uniforme 1/2 do pai. C gira a câmera. R restaura tudo. Há botões equivalentes. Repetição automática e modificadores são ignorados; não exige InputMap.

Direções de objeto e coordenadas no pai não são sinônimos. F normaliza −global_transform.basis.z, obtém destino no mundo, converte com Base.to_local e aplica o limite: X/Z locais −4…4, Y local 0,5…3. Se sair do limite, o passo é recusado inteiro. Não há colisão, corpo físico, queda, animação automática da peça ou integração de velocidade. Um passo local de 0,5 sob escala 2 pode medir 1 unidade global; F sempre pede 1 unidade global. O controlador pressupõe peça válida e escalas uniformes positivas.

Editor e runtime têm câmeras distintas: orbitar a vista do editor não modifica a Camera3D da cena. C modifica a Camera3D em runtime, mantendo as coordenadas da peça. A câmera é ortográfica e enquadra a bancada; extremos da prática e a interface precisam de conferência visual no motor. A prévia de luz do editor não substitui o nó DirectionalLight3D do jogo.

## Consultas opcionais

consulta.gd: adicione um Node filho extra de Oficina, anexe o script e arraste Base/Peca ao campo peca. Ao executar, o Output mostra posição no pai, global, conversão pai.to_global(peca.position) e inversa. Não substitua o script principal. Usar peca.to_global(peca.position) misturaria o sistema do pai com o da própria peça.

passo.gd é chamado pelo controlador e não é instalado como script em Node3D. Ele só calcula um deslocamento unitário; oficina.gd aplica o destino e os limites. A Basis pode incluir escala; a normalização evita multiplicar o comprimento do passo pela escala herdada. Escalas singulares, negativas, não uniformes e rotações compostas ficam fora deste exercício.

## Limites do navegador

Diagrama Canvas/JS estático, sem Godot/WebGL/física. Vista ortográfica matemática e planta XZ; planta omite altura no desenho e informa Y na leitura. Rotação só em Y, escala uniforme positiva e pai em (2,0,1). Enquadramento automático; distância em pixels não mede unidades do mundo. Faces são desenhadas como esquema e não homologam iluminação/oclusão do motor. Pausa não bloqueia parâmetros e passos, pois não há relógio de movimento. Sliders de coordenada aceitam frações para representar a conversão após F; leituras arredondam três casas.
