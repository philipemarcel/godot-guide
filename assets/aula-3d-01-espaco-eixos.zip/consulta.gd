extends Node

@export var peca: Node3D

func _ready() -> void:
    if not is_instance_valid(peca):
        push_warning("Arraste Base/Peca para o campo peca deste exemplo opcional.")
        return
    var pai := peca.get_parent_node_3d()
    if pai == null:
        push_warning("Esta consulta pressupõe um pai Node3D.")
        return
    print("No pai: ", peca.position)
    print("No mundo: ", peca.global_position)
    print("Convertido pelo pai: ", pai.to_global(peca.position))
    print("Retorno ao pai: ", pai.to_local(peca.global_position))

# Node3D guarda transformação; MeshInstance3D fornece a forma visível.
