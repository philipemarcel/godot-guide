extends RefCounted

# Pré-condição da bancada: peça válida na árvore, escala uniforme positiva.
static func deslocamento(peca: Node3D, pela_frente: bool) -> Vector3:
    if pela_frente:
        # A coluna contém escala; normalize para o passo medir 1 unidade global.
        return (-peca.global_transform.basis.z).normalized()
    return Vector3.FORWARD
