class_name JogadorDaOficina3D
extends CharacterBody3D

@export var velocidade: float = 2.0
@export var velocidade_salto: float = 5.0
var pausado := false
var revalidando_contato := true
var salto_pedido := false
var entrada_virtual := Vector2.ZERO
var tempo_virtual := 0.0
var tempo := 0.0

func restaurar(destino: Vector3) -> void:
    global_position = destino
    rotation = Vector3.ZERO
    velocity = Vector3.ZERO
    salto_pedido = false
    entrada_virtual = Vector2.ZERO
    tempo_virtual = 0.0
    tempo = 0.0
    revalidando_contato = true

func andar_por_botao(entrada: Vector2) -> void:
    entrada_virtual = entrada.limit_length(1.0)
    tempo_virtual = 0.25

func pedir_salto() -> void:
    salto_pedido = true

func _physics_process(delta: float) -> void:
    if pausado:
        return
    tempo += delta
    # is_on_floor descreve o Ãºltimo move_and_slide, nÃ£o uma consulta nova.
    var apoiado := is_on_floor() and not revalidando_contato
    var interface_em_foco := get_viewport().gui_get_focus_owner() != null
    var entrada := Vector2.ZERO
    if not interface_em_foco:
        entrada = Input.get_vector("mover_esquerda", "mover_direita", "mover_frente", "mover_tras")
    if tempo_virtual > 0.000001:
        entrada = entrada_virtual
        tempo_virtual = maxf(0.0, tempo_virtual - delta)
    # Corpo e ancestrais com escala 1; corpo gira somente em Y.
    var direcao := global_transform.basis * Vector3(entrada.x, 0, entrada.y)
    direcao.y = 0
    direcao = direcao.limit_length(1.0)
    velocity.x = direcao.x * velocidade
    velocity.z = direcao.z * velocidade
    if not apoiado:
        velocity += get_gravity() * delta
    var teclado_pediu := not interface_em_foco and Input.is_action_just_pressed("pular")
    if (salto_pedido or teclado_pediu) and apoiado:
        velocity.y = velocidade_salto
    # Pedido Ã© consumido no tick; sem buffer/coyote e sem salto duplo.
    salto_pedido = false
    # velocity estÃ¡ em unidades/s; move_and_slide aplica o passo de tempo.
    move_and_slide()
    revalidando_contato = false

