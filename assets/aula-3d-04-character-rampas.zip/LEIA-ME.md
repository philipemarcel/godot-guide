# Aula 3D 4 — CharacterBody3D, salto e rampas

Referência Godot 4.5, GDScript, Compatibility, desktop. Revisão documental, sem execução/compilação do motor neste ambiente. Testes JS não homologam CharacterBody3D ou cenas.

## Cena e controles

Importe project.godot, abra oficina.tscn e execute F6. Pista física com planos, subida/patamar/descida e faixa de três degraus em Z=6. Cada StaticBody3D tem BoxMesh e BoxShape3D separados, recursos independentes e escala 1. Rampa ajustável. Jogador é CharacterBody3D com origem nos pés; CollisionShape3D em Y=0.9, cápsula radius=0.3,height=1.8 e visual correspondente. Cenário layer=1/mask=2; jogador layer=2/mask=1.

WASD/setas sustentadas andam no motor; soltar para. Espaço pede salto. Botões andam 0.25 s e há botão de salto. Q gira yaw do corpo 90°. Direção relativa ao corpo, não à câmera fixa. InputMap é criado por oficina.gd se ações não existirem; copiar só jogador.gd exige configurar ações descritas em configuracao.txt. Sliders com foco suspendem teclado de jogo; Esc libera foco. Botões usam clique sem tomar foco do jogo.

R reposiciona no início, zera velocidade/entrada/tempo e revalida contato, mantendo parâmetros. P vai ao patamar, T à pista de degraus. Restaurar tudo repõe rampa30/limite45/snap0.1/salto5 sem recarregar. Alterar parâmetros reinicia posição para evitar deslocar a geometria sob o corpo. Pausa é do controlador do personagem, não da árvore inteira; leituras continuam mostrando o último movimento. O estado de pausa é preservado nos resets.

Não há caminhada automática; a queda inicial de 0.06 u para a pista é calculada pelo script. Se cair fora da pista, R reposiciona; não há respawn automático. Não há step-up, buffer/coyote, empurrão customizado ou RigidBody. infinite_inertia não é propriedade de CharacterBody3D na Godot 4.

## Fluxo físico

O controlador pede velocidade horizontal de até2u/s no plano. velocity em unidades/s; nesta prática 1u=1m. +Y é cima, gravidade do projeto9.8 em -Y. O script integra get_gravity()*delta quando não apoiado, não assume vetor constante como regra universal. Salto atribui velocity.y=5; não é impulso RigidBody. A referência UP e o movimento horizontal desta implementação não suportam gravidade arbitrária.

_physics_process lê contato da chamada anterior, monta direção global por yaw do corpo, atualiza velocity e chama move_and_slide sem delta extra. Consulta atualizada vem depois. Após teleporte, não permite salto usando o contato antigo. Há parada horizontal imediata, sem aceleração/frenagem suave. A entrada é limitada para não ganhar velocidade diagonal.

floor_max_angle recebe radianos. floor_constant_speed e floor_stop_on_slope estão ativos na cena. floor_snap_length ajuda a manter contato descendente dentro do alcance, mas snap automático não atua durante velocidade ascendente. get_floor_angle só é lido com chão válido. get_real_velocity difere da solicitação ao subir/descer. Contagem de slide registra colisões que mudaram direção, não todos os contatos.

No plano, salto5/g9.8 prevê altura contínua≈1.28 e retorno≈1.02s. Conferir discretização/collision no motor, sem exigir igualdade exata. Rampa30 com limite45 é um ensaio de chão; rampa55 com limite45 pode ser classificada como parede. O resultado não é uma regra universal de escorregar. Compare contatos/movimento real. Snap0 versus0.1 na descida depende das condições; não exigir diferença em todo frame.

Degraus: cada elevação é0.3u, sem algoritmo que eleve o corpo automaticamente. Cápsula não garante subir quinas. Teste aproximação e salto na pistaT e registre o resultado real. Um step-up exigiria consultas e validações próprias.

## Laboratório web

Modelo pontual em seção XY, não resolvedor Godot. Pista sobe de X0 a3, patamar3 a5, desce5 a8; limites horizontais -3 a11. Pés iniciais(-1.5,0). A/D/setas andam a2u/s por0.25s por toque, S para, Espaço salta, P inicia emX4.8 no alto, R restaura parâmetros/posição. Atalhos só com foco no desenho e repetição ignorada. Mudanças de parâmetros reiniciam o ensaio. Pausa permite preparar comando e avançar0.10s.

Integração fixa1/120s; queda balística exata por passo. Na continuação de apoio, gap descendente até snap conserva o ponto no chão. Sem snap pode perder apoio antes de pousar. Na subida íngreme, barreira didática; contato íngreme em queda encerra o ensaio e pede reset/preset. Isso evita fingir resolução de escorregamento. vy de voo é separado da taxa medida de Y (delta de posição por passo), pois apoio/snap também mudam a altura. O desenho de cápsula é ilustração; contato usa ponto nos pés, sem largura, paredes/tetos ou varredura. Não reproduz floor_constant_speed, margens/solver, step-up ou desempenho do motor.

Sem comando fica parado. No salto parado inicial, após0.10s:y0.451 e vy4.020; apoio false. Novo salto só após pouso. Classificar o ângulo do chão potencial não cria contato durante voo. Testes matemáticos e DOM não validam GDScript, física ou câmera/UI do projeto.

