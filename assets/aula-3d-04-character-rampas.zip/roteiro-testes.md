# Godot 4.5 — testes pendentes

Registrar versão/renderizador/passos de física e resultados reais. Não marcar com base no JS.

- [ ] Importar/compilar classe JogadorDaOficina3D, scripts e cena; registrar erros/avisos.
- [ ] Câmera/UI, pista principal e faixa de degraus visíveis; cápsula/colisões coerentes.
- [ ] Escalas1; cápsula0.3×1.8 emY0.9; camadas/máscaras e BoxShape3D separados.
- [ ] InputMap criado; WASD/setas e botões0.25s; diagonal sem ganho de velocidade.
- [ ] Sem comando não caminha; queda inicial por código e chão confirmado após movimento.
- [ ] Salto único, sem repetição aérea; leitura chão false em voo, true após pouso.
- [ ] R/P/T resetam velocidade, entrada e contato; sem salto aceito por flag velha.
- [ ] Q gira corpo em yaw; entrada relativa ao corpo, câmera fixa.
- [ ] Sliders suspendem teclado de jogo; Esc libera foco; botões operam por clique.
- [ ] Rampa30/limite45: parada, subida, descida e ângulo válido após move_and_slide.
- [ ] Rampa55/limite45: observar classificação parede/chão e resposta real, sem presumir escorregamento universal.
- [ ] Snap0/0.1, constante de velocidade e perdas de contato na descida; snap não cola salto ascendente.
- [ ] Comparar velocity e get_real_velocity; get_floor_angle só com chão válido.
- [ ] T: face vertical e degraus; sem promessa de step-up; testar salto e contatos.
- [ ] Pausa preserva último movimento; Restaurar tudo repõe parâmetros sem recarregar.
- [ ] Extremos de rampa/salto e queda fora da pista; R permite retomar sem respawn automático.
- [ ] Executar roteiro completo, corrigir divergências e homologar no motor.
