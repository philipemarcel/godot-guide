extends Node3D

@onready var jogador: JogadorDaOficina3D = $Jogador
var leitura: Label
var rampa: HSlider
var limite: HSlider
var snap: HSlider
var salto: HSlider
var pausa: Button

func _ready() -> void:
    registrar_acao("mover_esquerda", [KEY_A, KEY_LEFT])
    registrar_acao("mover_direita", [KEY_D, KEY_RIGHT])
    registrar_acao("mover_frente", [KEY_W, KEY_UP])
    registrar_acao("mover_tras", [KEY_S, KEY_DOWN])
    registrar_acao("pular", [KEY_SPACE])
    var layer := CanvasLayer.new()
    add_child(layer)
    var box := VBoxContainer.new()
    box.position = Vector2(16, 405)
    box.custom_minimum_size.x = 1048
    layer.add_child(box)
    var grid := GridContainer.new()
    grid.columns = 4
    box.add_child(grid)
    rampa = slider(grid, "Rampa: graus", 10, 60, 5, 30)
    limite = slider(grid, "Chao: graus", 15, 60, 5, 45)
    snap = slider(grid, "Snap: unidades", 0, 0.3, 0.05, 0.1)
    salto = slider(grid, "Salto: unidades/s", 4, 7, 0.5, 5)
    var row := HBoxContainer.new()
    box.add_child(row)
    botao(row, "A: esquerda 0,25 s", func(): jogador.andar_por_botao(Vector2.LEFT))
    botao(row, "D: direita 0,25 s", func(): jogador.andar_por_botao(Vector2.RIGHT))
    botao(row, "W: frente 0,25 s", func(): jogador.andar_por_botao(Vector2.UP))
    botao(row, "S: tras 0,25 s", func(): jogador.andar_por_botao(Vector2.DOWN))
    botao(row, "Espaco: salto", jogador.pedir_salto)
    row = HBoxContainer.new()
    box.add_child(row)
    botao(row, "R: inicio", reiniciar)
    botao(row, "P: alto", func(): posicionar(Vector3(4, altura() + 0.06, 0)))
    botao(row, "T: degraus", func(): posicionar(Vector3(-2, 0.06, 6)))
    botao(row, "Q: girar corpo 90 graus", func(): jogador.rotate_y(PI / 2))
    pausa = botao(row, "Pausar personagem", alternar_pausa)
    botao(row, "Restaurar tudo", restaurar_tudo)
    leitura = Label.new()
    leitura.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
    box.add_child(leitura)
    var ajuda := Label.new()
    ajuda.text = "WASD/setas: segure para andar. Espaco salta. Esc libera foco da interface. R/P/T/Q: presets/giro. Sem subida automatica de escadas."
    ajuda.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
    box.add_child(ajuda)
    $Camera3D.position = Vector3(5, 9, 18)
    $Camera3D.look_at(Vector3(3, -2, 2), Vector3.UP)
    atualizar()

func registrar_acao(nome: String, teclas: Array) -> void:
    if InputMap.has_action(nome):
        return
    InputMap.add_action(nome)
    for tecla in teclas:
        var evento := InputEventKey.new()
        evento.physical_keycode = tecla
        InputMap.action_add_event(nome, evento)

func slider(parent: Node, titulo: String, minimo: float, maximo: float, passo: float, inicial: float) -> HSlider:
    var box := VBoxContainer.new()
    box.custom_minimum_size.x = 250
    parent.add_child(box)
    var label := Label.new()
    label.text = titulo
    box.add_child(label)
    var control := HSlider.new()
    control.min_value = minimo
    control.max_value = maximo
    control.step = passo
    control.value = inicial
    control.value_changed.connect(func(_v: float): atualizar())
    box.add_child(control)
    return control

func botao(parent: Node, texto: String, acao: Callable) -> Button:
    var button := Button.new()
    button.text = texto
    button.focus_mode = Control.FOCUS_NONE
    button.pressed.connect(acao)
    parent.add_child(button)
    return button

func altura() -> float:
    return 3.0 * tan(deg_to_rad(rampa.value))

func caixa(nome: String, tamanho: Vector3, centro: Vector3, giro: float) -> void:
    var corpo: StaticBody3D = get_node(nome)
    corpo.position = centro
    corpo.rotation.z = giro
    var visual: MeshInstance3D = corpo.get_node("Visual")
    var colisao: CollisionShape3D = corpo.get_node("Colisao")
    var malha: BoxMesh = visual.mesh
    var forma: BoxShape3D = colisao.shape
    malha.size = tamanho
    forma.size = tamanho

func atualizar() -> void:
    if not is_instance_valid(salto):
        return
    var angulo := deg_to_rad(rampa.value)
    var h := altura()
    caixa("Subida", Vector3(3 / cos(angulo), 0.3, 4), Vector3(1.5 + sin(angulo) * 0.15, h / 2 - cos(angulo) * 0.15, 0), angulo)
    caixa("Topo", Vector3(2, 0.3, 4), Vector3(4, h - 0.15, 0), 0)
    caixa("Descida", Vector3(3 / cos(angulo), 0.3, 4), Vector3(6.5 - sin(angulo) * 0.15, h / 2 - cos(angulo) * 0.15, 0), -angulo)
    jogador.floor_max_angle = deg_to_rad(limite.value)
    jogador.floor_snap_length = snap.value
    jogador.velocidade_salto = salto.value
    # Alterar a geometria reinicia o ensaio; sem mover a rampa sob o personagem.
    reiniciar()

func posicionar(ponto: Vector3) -> void:
    jogador.restaurar(ponto)

func reiniciar() -> void:
    posicionar(Vector3(-2, 0.06, 0))

func restaurar_tudo() -> void:
    rampa.set_value_no_signal(30)
    limite.set_value_no_signal(45)
    snap.set_value_no_signal(0.1)
    salto.set_value_no_signal(5)
    atualizar()

func alternar_pausa() -> void:
    jogador.pausado = not jogador.pausado
    pausa.text = "Retomar personagem" if jogador.pausado else "Pausar personagem"

func _process(_delta: float) -> void:
    if not is_instance_valid(leitura):
        return
    var piso := is_instance_valid(jogador) and jogador.is_on_floor() and not jogador.revalidando_contato
    var angulo := "%.2f graus" % rad_to_deg(jogador.get_floor_angle()) if piso else "sem chao valido"
    leitura.text = "Ultimo move_and_slide: chao=%s parede=%s angulo=%s colisoes com mudanca=%d\nposition=%s | velocity=%s | real_velocity=%s\nRampa=%.0f limite=%.0f snap=%.2f salto=%.1f | %.2f s | pausado=%s" % [piso, jogador.is_on_wall(), angulo, jogador.get_slide_collision_count(), jogador.global_position, jogador.velocity, jogador.get_real_velocity(), rampa.value, limite.value, snap.value, salto.value, jogador.tempo, jogador.pausado]

func _unhandled_key_input(event: InputEvent) -> void:
    if not event is InputEventKey or not event.pressed or event.echo or event.ctrl_pressed or event.alt_pressed or event.meta_pressed:
        return
    if event.keycode == KEY_ESCAPE:
        var foco := get_viewport().gui_get_focus_owner()
        if foco != null:
            foco.release_focus()
    elif get_viewport().gui_get_focus_owner() == null:
        match event.keycode:
            KEY_R: reiniciar()
            KEY_P: posicionar(Vector3(4, altura() + 0.06, 0))
            KEY_T: posicionar(Vector3(-2, 0.06, 6))
            KEY_Q: jogador.rotate_y(PI / 2)
            _: return
    else:
        return
    get_viewport().set_input_as_handled()
