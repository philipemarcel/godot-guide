# Aula 13 — catálogo, inventário e persistência

Referência: Godot 4.5. Projeto revisado documentalmente, ainda não executado no motor neste ambiente.

Importe project.godot e execute oficina.tscn com F6. A interface é criada por oficina.gd; cofre.gd valida e grava. Os .tres de itens usam dados_item.gd. Não são necessárias texturas, ações de InputMap ou Autoloads.

Adicione martelo duas vezes, melhore uma vez: ×2, nível 2, dano/unidade 77. Salve. Melhore, remova uma unidade e ganhe 10 de ouro. Carregue: deve recuperar ×2, nível 2 e ouro 50. Reiniciar inventário preserva o arquivo; encerrar o jogo não carrega automaticamente.

Arquivo: user://oficina_aula13.json. Abra a pasta pelo menu Projeto da Godot. Use uma cópia antes de testar JSON inválido, ID desconhecido ou nível 11. Em falha, o estado atual deve ser preservado. A escrita direta não é atômica e pode perder um arquivo anterior em falha; este projeto não implementa backup, migração ou autenticação.

Extensão ConfigFile: no fim de _ready, acrescente print(OpcoesOficina.salvar(0.6, false)) e print(OpcoesOficina.carregar()). Depois remova a gravação para testar a leitura existente. A extensão não aplica volume nem muda a janela.

O laboratório no site guarda somente texto em memória; não acessa este arquivo nem executa Godot. Consulte a aula para o roteiro e os limites completos.
