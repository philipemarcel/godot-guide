class_name OpcoesOficina
extends RefCounted
# Extensão opcional. Não controla volume real nem modo de janela.
const PATH := "user://opcoes_aula13.cfg"

static func salvar(volume: float, tela_cheia: bool) -> Error:
    if not is_finite(volume) or volume < 0.0 or volume > 1.0:
        return ERR_INVALID_DATA
    var cfg := ConfigFile.new()
    cfg.set_value("audio", "volume", volume)
    cfg.set_value("video", "tela_cheia", tela_cheia)
    return cfg.save(PATH)

static func carregar() -> Dictionary:
    var defaults := {"ok": true, "volume": 0.8, "tela_cheia": false, "message": "Padrões do primeiro uso."}
    if not FileAccess.file_exists(PATH):
        return defaults
    var cfg := ConfigFile.new()
    var error := cfg.load(PATH)
    if error != OK:
        return {"ok": false, "message": "Erro ao ler opções: " + error_string(error)}
    var volume: Variant = cfg.get_value("audio", "volume", 0.8)
    var full: Variant = cfg.get_value("video", "tela_cheia", false)
    if (typeof(volume) != TYPE_INT and typeof(volume) != TYPE_FLOAT) or not full is bool:
        return {"ok": false, "message": "Tipos inválidos nas opções."}
    var number := float(volume)
    if not is_finite(number) or number < 0.0 or number > 1.0:
        return {"ok": false, "message": "Volume fora de 0 a 1."}
    return {"ok": true, "volume": number, "tela_cheia": full, "message": "Opções lidas."}
