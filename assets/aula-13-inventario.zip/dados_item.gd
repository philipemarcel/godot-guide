class_name DadosItem
extends Resource

@export var id: String = ""
@export var nome: String = ""
@export var dano_base: int = 0
@export var custo_vapor: int = 0

func dano_no_nivel(nivel: int) -> int:
    return dano_base + 12 * (nivel - 1)
