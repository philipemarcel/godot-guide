class_name CofreOficina
extends RefCounted

const PATH := "user://oficina_aula13.json"
const MAX_BYTES := 16384

static func falha(message: String) -> Dictionary:
    return {"ok": false, "message": message}

static func inteiro_entre(value: Variant, low: int, high: int) -> bool:
    if typeof(value) != TYPE_INT and typeof(value) != TYPE_FLOAT:
        return false
    var number := float(value)
    return is_finite(number) and number == floor(number) and number >= low and number <= high

static func validar(value: Variant, catalog: Dictionary) -> Dictionary:
    if not value is Dictionary:
        return falha("Raiz precisa ser um objeto.")
    if not inteiro_entre(value.get("version"), 1, 1):
        return falha("Versão não suportada; este exemplo só lê a versão 1.")
    if not inteiro_entre(value.get("gold"), 0, 999):
        return falha("Ouro deve ser inteiro entre 0 e 999.")
    var entries: Variant = value.get("inventory")
    if not entries is Array or entries.size() > 3:
        return falha("Inventário deve ser uma lista com até três tipos.")
    var clean: Array = []
    var seen: Dictionary = {}
    for entry in entries:
        if not entry is Dictionary:
            return falha("Entrada do inventário deve ser um objeto.")
        var id: Variant = entry.get("id")
        if not id is String or not catalog.has(id) or seen.has(id):
            return falha("ID desconhecido ou repetido.")
        if not inteiro_entre(entry.get("quantity"), 1, 99):
            return falha("Quantidade deve estar entre 1 e 99.")
        if not inteiro_entre(entry.get("level"), 1, 10):
            return falha("Nível deve estar entre 1 e 10.")
        seen[id] = true
        clean.append({"id": id, "quantity": int(entry["quantity"]), "level": int(entry["level"])})
    return {"ok": true, "message": "Dados validados.", "state": {
        "version": 1, "gold": int(value["gold"]), "inventory": clean}}

static func ler_texto(text: String, catalog: Dictionary) -> Dictionary:
    if text.to_utf8_buffer().size() > MAX_BYTES:
        return falha("Texto excede 16 KiB.")
    var parser := JSON.new()
    if parser.parse(text) != OK:
        return falha("JSON inválido na linha %d: %s" % [parser.get_error_line(), parser.get_error_message()])
    return validar(parser.data, catalog)

static func salvar(value: Dictionary, catalog: Dictionary) -> Dictionary:
    var result := validar(value, catalog)
    if not result["ok"]:
        return result
    var text := JSON.stringify(result["state"], "  ")
    var file := FileAccess.open(PATH, FileAccess.WRITE)
    if file == null:
        return falha("Falha ao abrir para escrita: %s" % error_string(FileAccess.get_open_error()))
    var written := file.store_string(text)
    file.flush()
    var error := file.get_error()
    file.close()
    if not written or error != OK:
        return falha("Falha na escrita; confira o arquivo antes de continuar.")
    return {"ok": true, "message": "Gravado em " + PATH}

static func carregar(catalog: Dictionary) -> Dictionary:
    if not FileAccess.file_exists(PATH):
        return falha("Ainda não há save. Salve antes de carregar.")
    var file := FileAccess.open(PATH, FileAccess.READ)
    if file == null:
        return falha("Falha ao abrir para leitura: %s" % error_string(FileAccess.get_open_error()))
    if file.get_length() > MAX_BYTES:
        file.close()
        return falha("Arquivo excede 16 KiB.")
    var text := file.get_as_text()
    file.close()
    return ler_texto(text, catalog)
