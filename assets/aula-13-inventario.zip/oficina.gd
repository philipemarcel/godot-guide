extends Control

# Não alteramos os Resources do catálogo para guardar progresso.
const CATALOG := {
    "martelo": preload("res://itens/martelo.tres"),
    "pistola": preload("res://itens/pistola.tres"),
    "lamina": preload("res://itens/lamina.tres")
}
var current: Dictionary = {"version": 1, "gold": 50, "inventory": []}
var choice: OptionButton
var readout: Label
var status: Label

func _ready() -> void:
    var box := VBoxContainer.new()
    box.position = Vector2(24, 24)
    box.custom_minimum_size.x = 580
    add_child(box)
    choice = OptionButton.new()
    for id in CATALOG:
        var item: DadosItem = CATALOG[id]
        choice.add_item(item.nome)
        choice.set_item_metadata(choice.item_count - 1, id)
    box.add_child(choice)
    for spec in [
        ["Adicionar unidade", adicionar], ["Melhorar pilha", melhorar],
        ["Remover unidade", remover], ["Ganhar 10 de ouro", ganhar_ouro],
        ["Salvar no disco", salvar], ["Carregar do disco", carregar],
        ["Reiniciar inventário (preserva save)", reiniciar]
    ]:
        var button := Button.new()
        button.text = spec[0]
        button.pressed.connect(spec[1])
        box.add_child(button)
    readout = Label.new()
    box.add_child(readout)
    status = Label.new()
    status.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
    box.add_child(status)
    mostrar("Escolha um item. O catálogo não muda ao melhorar a pilha.")

func escolhido() -> String:
    return str(choice.get_item_metadata(choice.selected))

func indice() -> int:
    for i in range(current["inventory"].size()):
        if current["inventory"][i]["id"] == escolhido():
            return i
    return -1

func adicionar() -> void:
    var i := indice()
    if i < 0:
        current["inventory"].append({"id": escolhido(), "quantity": 1, "level": 1})
    elif current["inventory"][i]["quantity"] < 99:
        current["inventory"][i]["quantity"] += 1
    else:
        mostrar("Limite: 99 unidades por pilha.")
        return
    mostrar("Unidade adicionada.")

func melhorar() -> void:
    var i := indice()
    if i < 0:
        mostrar("Adicione o item antes de melhorar.")
        return
    if current["inventory"][i]["level"] >= 10:
        mostrar("Nível máximo: 10.")
        return
    current["inventory"][i]["level"] += 1
    mostrar("Nível da pilha aumentado; catálogo preservado.")

func remover() -> void:
    var i := indice()
    if i < 0:
        mostrar("Item ausente.")
        return
    current["inventory"][i]["quantity"] -= 1
    if current["inventory"][i]["quantity"] == 0:
        current["inventory"].remove_at(i)
    mostrar("Unidade removida.")

func ganhar_ouro() -> void:
    current["gold"] = mini(999, current["gold"] + 10)
    mostrar("Ouro atualizado.")

func salvar() -> void:
    var result := CofreOficina.salvar(current, CATALOG)
    mostrar(result["message"])

func carregar() -> void:
    var result := CofreOficina.carregar(CATALOG)
    if result["ok"]:
        current = result["state"]
    mostrar(result["message"] + " Estado anterior preservado em caso de erro.")

func reiniciar() -> void:
    current = {"version": 1, "gold": 50, "inventory": []}
    mostrar("Inventário reiniciado. O arquivo salvo foi preservado.")

func mostrar(message: String) -> void:
    var lines := PackedStringArray(["Ouro: %d" % current["gold"]])
    for entry in current["inventory"]:
        var item: DadosItem = CATALOG[entry["id"]]
        lines.append("%s ×%d | nível %d | dano %d" % [
            item.nome, entry["quantity"], entry["level"], item.dano_no_nivel(entry["level"])])
    readout.text = "\n".join(lines)
    status.text = message
