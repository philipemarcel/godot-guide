# Aula 11 — estados e componentes

Referência: Godot 4.5. Este pacote não é um projeto pronto nem foi executado no motor neste ambiente.

Monte a árvore e siga a prática da aula. Extraia automato.svg e alvo.svg para res://arte e os cinco scripts principais para res://scripts. Configure atacar = Espaço. Setas movem, Esc interrompe.

Hitbox: Layer apenas caixa 3 (bitmask 4), Mask vazia, Monitoring off, Monitorable on; forma inicialmente Disabled. Hurtbox: Layer vazia, Mask caixa 3 (4), Monitoring on, Monitorable off.

Na Hurtbox arraste Alvo/Health para Health e Alvo para Receiver. Team do golpe = 1, Team do alvo = 2. Damage 25, vida 100.

A extensão usa passo.gd e maquina.gd em outra cena, com filhos Parado e Trabalho. Não a instale junto do controlador principal. Consulte o roteiro completo da aula para posições, formas e resultados esperados.
