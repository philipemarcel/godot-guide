class_name Aula11Hitbox
extends Area2D
# hitbox.gd: anexe a Automato/Hitbox.
@export var damage: float = 25.0
@export var team: int = 1
var source_actor: Node
var active: bool = false
var victims: Dictionary = {}
@onready var shape: CollisionShape2D = $CollisionShape2D

func begin_attack() -> void:
    set_active(false)
    victims.clear()

func set_active(value: bool) -> void:
    active = value
    # O teste lógico é imediato; a mudança física é adiada com segurança.
    shape.set_deferred("disabled", not value)

func try_hit(health: Aula11Health, receiver: Node, receiver_team: int) -> void:
    if not active or receiver == source_actor or receiver_team == team:
        return
    var key := health.get_instance_id()
    if victims.has(key):
        return
    victims[key] = true
    var applied := health.take_damage(damage)
    if applied > 0.0:
        print("Dano aplicado: ", applied)
