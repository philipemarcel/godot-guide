extends CharacterBody2D
# automato.gd: anexe a Automato. Exemplo principal, sem gravidade.
enum Estado { PARADO, ANDANDO, ATACANDO }
var estado: Estado = Estado.PARADO
var tempo: float = 0.0
@onready var golpe: Aula11Hitbox = $Hitbox

func _ready() -> void:
    motion_mode = CharacterBody2D.MOTION_MODE_FLOATING
    golpe.source_actor = self
    golpe.set_active(false)

func mudar_estado(novo: Estado) -> void:
    if novo == estado:
        return
    # Saída: encerra os efeitos que pertencem ao estado anterior.
    if estado == Estado.ATACANDO:
        golpe.set_active(false)
    estado = novo
    tempo = 0.0
    # Entrada: prepara um golpe novo, sem reaproveitar os alvos anteriores.
    if estado == Estado.ATACANDO:
        velocity = Vector2.ZERO
        golpe.begin_attack()

func _physics_process(delta: float) -> void:
    if Input.is_action_just_pressed("ui_cancel"):
        mudar_estado(Estado.PARADO)
        velocity = Vector2.ZERO
        return
    if estado != Estado.ATACANDO and Input.is_action_just_pressed("atacar"):
        mudar_estado(Estado.ATACANDO)
    if estado == Estado.ATACANDO:
        tempo += delta
        golpe.set_active(tempo >= 0.15 and tempo < 0.40)
        if tempo >= 0.60:
            mudar_estado(Estado.PARADO)
        return
    var eixo := Input.get_axis("ui_left", "ui_right")
    mudar_estado(Estado.ANDANDO if eixo != 0.0 else Estado.PARADO)
    velocity = Vector2(eixo * 80.0, 0.0)
    move_and_slide()
    position.x = clampf(position.x, 48.0, 560.0)
