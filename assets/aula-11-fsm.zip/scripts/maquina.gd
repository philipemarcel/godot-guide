extends Node
@export var initial: Aula11Passo
var current: Aula11Passo
var states: Dictionary = {}
var changing: bool = false

func _ready() -> void:
    for child in get_children():
        if child is Aula11Passo:
            states[StringName(child.name)] = child
            child.requested.connect(_request)
    assert(initial != null and initial.get_parent() == self)
    current = initial
    current.enter()

func _request(origin: Aula11Passo, next: StringName) -> void:
    if origin != current or changing or not states.has(next):
        return
    var target: Aula11Passo = states[next]
    if target == current:
        return
    changing = true
    current.exit()
    current = target
    current.enter()
    changing = false

func _physics_process(delta: float) -> void:
    if Input.is_action_just_pressed("ui_accept"):
        _request(current, &"Trabalho")
    current.tick(delta)
