class_name Aula11Hurtbox
extends Area2D
# hurtbox.gd: anexe a Alvo/Hurtbox; arraste Health e Alvo aos exports.
@export var health: Aula11Health
@export var receiver: Node
@export var team: int = 2

func _ready() -> void:
    assert(health != null and receiver != null, "Configure Health e Receiver")

func _physics_process(_delta: float) -> void:
    # A lista reflete a atualização física; não é uma consulta imediata.
    # A leitura contínua também cobre um golpe iniciado já dentro da área.
    for area in get_overlapping_areas():
        if area is Aula11Hitbox:
            area.try_hit(health, receiver, team)
