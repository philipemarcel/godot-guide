class_name Aula11Passo
extends Node
signal requested(origin: Aula11Passo, next: StringName)
var elapsed: float = 0.0

func enter() -> void:
    elapsed = 0.0
    print("enter ", name)

func exit() -> void:
    print("exit ", name)

func tick(delta: float) -> void:
    elapsed += delta
    if name == &"Trabalho" and elapsed >= 0.60:
        requested.emit(self, &"Parado")

