class_name Aula11Health
extends Node
# health.gd: no Health do alvo. Não conhece atacante nem geometria.
signal changed(current: float, maximum: float)
signal died
@export_range(1.0, 1000.0) var maximum: float = 100.0
var current: float = 0.0

func _ready() -> void:
    current = maximum

func take_damage(amount: float) -> float:
    if amount <= 0.0 or current <= 0.0:
        return 0.0
    var applied := minf(current, amount)
    current -= applied
    changed.emit(current, maximum)
    if current == 0.0:
        died.emit()
    return applied
