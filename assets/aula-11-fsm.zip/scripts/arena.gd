extends Node2D
# arena.gd: anexe a Arena. Os filhos já passaram por _ready().
@onready var health: Aula11Health = $Alvo/Health
@onready var label: Label = $Leitura

func _ready() -> void:
    health.changed.connect(_on_health_changed)
    health.died.connect(_on_died)
    _on_health_changed(health.current, health.maximum)

func _on_health_changed(value: float, maximum: float) -> void:
    label.text = "Integridade: %.0f / %.0f" % [value, maximum]

func _on_died() -> void:
    print("Alvo esgotado; novos golpes não emitem died novamente.")
